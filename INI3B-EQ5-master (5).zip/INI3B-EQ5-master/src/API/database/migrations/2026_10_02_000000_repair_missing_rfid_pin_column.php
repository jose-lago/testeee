<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('users', 'rfid_pin')) {
            return;
        }

        Schema::table('users', function (Blueprint $table) {
            $table->string('rfid_pin')->nullable();
        });
    }

    public function down(): void
    {
        // The original RFID migration also owns this column; do not drop existing PIN data.
    }
};