<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pedidos', function (Blueprint $table) {
            $table->id();
            
            // Cliente (Obrigatório)
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            
            // Funcionário preparando (Opcional no início)
            $table->foreignId('preparador_id')->nullable()->constrained('users')->nullOnDelete();
            
            // Garantindo segurança também no banco (unsigned e valor >= 0 implicitamente por DECIMAL, mas adicionaremos checagem no Model)
            $table->decimal('valor_total', 8, 2)->default(0.00)->unsigned();
            
            // Controle da fila diária (não pode ser nulo ou negativo)
            $table->integer('senha_diaria')->unsigned();
            
            // Opções: pendente, preparando, pronto, entregue, cancelado
            $table->enum('status', ['pendente', 'preparando', 'pronto', 'entregue', 'cancelado'])->default('pendente');
            
            // Opções: agora, com_almoco
            $table->enum('momento_bebida', ['agora', 'com_almoco'])->default('agora');
            
            $table->integer('posicao_fila')->unsigned()->default(0);
            
            $table->string('codigo_retirada', 4);
            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pedidos');
    }
};
