<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pedido_produto', function (Blueprint $table) {
            $table->id();
            
            $table->foreignId('pedido_id')->constrained('pedidos')->onDelete('cascade');
            $table->foreignId('produto_id')->constrained('produtos')->onDelete('cascade');
            
            // Quantidade e preco também usando "unsigned" (sem sinal/negativo) a nível de BD
            $table->integer('quantidade')->unsigned()->default(1);
            $table->decimal('preco_unitario', 8, 2)->unsigned();
            
            $table->text('observacao')->nullable();
            
            $table->boolean('entregue')->default(false);
            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pedido_produto');
    }
};
