<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_creditos', function (Blueprint $table) {
            $table->id();

            // Relacionamento com o usuário
            $table->foreignId('user_id')
                    ->constrained('users')
                    ->cascadeOnDelete()
                    ->unique();
            // Dados do aluno
            $table->string('cpf', 11)->unique();
            $table->string('ra', 20);
            $table->string('telefone', 20);
            $table->string('email_institucional')->unique(); // o mesmo e-mail não poderá ser usado p/ ativar crédito em duas contas diferentes.
            // PIN (será armazenado como hash)
            $table->string('pin');
            // Controle do crédito
            $table->decimal('limite', 8, 2)->default(50.00);
            $table->decimal('divida_atual', 8, 2)->default(0.00);
            $table->boolean('verificado')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_creditos');
    }
};
