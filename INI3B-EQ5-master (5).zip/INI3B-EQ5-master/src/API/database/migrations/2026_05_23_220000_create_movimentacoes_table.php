<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('movimentacoes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('pedido_id')->nullable()->constrained('pedidos')->nullOnDelete();
            $table->foreignId('admin_id')->nullable()->constrained('users')->nullOnDelete();

            // Positivo = crédito (recarga/estorno), Negativo = débito (pedido)
            $table->decimal('valor', 8, 2);

            // Classificação para facilitar filtros
            $table->enum('tipo', [
                'recarga',
                'pedido',
                'estorno',
                'ajuste',
                'pedido_credito',
                'pagamento_credito'
            ]);

            $table->decimal('saldo_anterior', 8, 2);
            $table->decimal('saldo_posterior', 8, 2);

            $table->string('descricao')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('movimentacoes');
    }
};
