<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('rfid_code')->nullable()->unique();
            $table->boolean('rfid_blocked')->default(false);
            $table->string('rfid_pin')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Drop the unique index and the columns
            $table->dropUnique('users_rfid_code_unique');
            $table->dropColumn(['rfid_code', 'rfid_blocked', 'rfid_pin']);
        });
    }
};
