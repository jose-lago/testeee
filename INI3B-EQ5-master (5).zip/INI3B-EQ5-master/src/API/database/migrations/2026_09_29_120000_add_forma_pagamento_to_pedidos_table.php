<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            // Registra como o pedido foi pago: 'saldo' ou 'credito'.
            // Nullable para manter compatibilidade com pedidos já gravados
            // antes desta coluna existir (esses são tratados como 'saldo').
            $table->string('forma_pagamento')->nullable()->after('valor_total');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('forma_pagamento');
        });
    }
};
