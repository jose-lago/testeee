<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$users = App\Models\User::all(['id', 'name', 'email', 'push_token', 'tipo']);
echo "=== LISTA DE USUARIOS E TOKENS ===\n";
foreach ($users as $u) {
    echo "ID: {$u->id} | Nome: {$u->name} | Email: {$u->email} | PushToken: '{$u->push_token}'\n";
}

$pedidos = App\Models\Pedido::with('user')->orderBy('id', 'desc')->take(5)->get();
echo "\n=== ULTIMOS PEDIDOS ===\n";
foreach ($pedidos as $p) {
    echo "Pedido #{$p->id} | Status: {$p->status} | User: {$p->user_id} ({$p->user?->name}) | User Push: '{$p->user?->push_token}'\n";
}
