<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de senha</title>
</head>
<body style="font-family: Arial, sans-serif; color: #3E2723; background: #FFF8F0; padding: 24px;">
    <main style="max-width: 520px; margin: 0 auto; background: #FFFFFF; padding: 28px; border-radius: 12px;">
        <h1 style="margin-top: 0; color: #FF9430;">Saviore</h1>
        <p>Olá, {{ $nomeAluno }}.</p>
        <p>Use o código abaixo para redefinir a senha da sua conta:</p>
        <p style="font-size: 32px; font-weight: bold; letter-spacing: 8px; text-align: center;">
            {{ $codigoOtp }}
        </p>
        <p>O código expira em 15 minutos e só pode ser usado uma vez.</p>
        <p>Se você não solicitou esta alteração, ignore este e-mail. Sua senha não foi alterada.</p>
    </main>
</body>
</html>
