<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Código de Ativação do Fiado - Saviore</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #f4f6f8;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            color: #333333;
            -webkit-font-smoothing: antialiased;
        }
        .container {
            max-width: 580px;
            margin: 30px auto;
            background-color: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
            border: 1px solid #eef0f3;
        }
        .header {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            padding: 32px 24px;
            text-align: center;
        }
        .header h1 {
            color: #ffffff;
            margin: 0;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: -0.5px;
        }
        .header p {
            color: #94a3b8;
            margin: 6px 0 0 0;
            font-size: 14px;
            font-weight: 400;
        }
        .badge {
            display: inline-block;
            background: rgba(234, 88, 12, 0.2);
            color: #fb923c;
            border: 1px solid rgba(251, 146, 60, 0.3);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .content {
            padding: 36px 32px;
            line-height: 1.6;
        }
        .greeting {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 12px;
        }
        .text {
            font-size: 15px;
            color: #475569;
            margin-bottom: 24px;
        }
        .otp-container {
            background: #f8fafc;
            border: 2px dashed #cbd5e1;
            border-radius: 10px;
            padding: 24px;
            text-align: center;
            margin: 28px 0;
        }
        .otp-label {
            font-size: 12px;
            font-weight: 700;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }
        .otp-code {
            font-size: 38px;
            font-weight: 800;
            color: #ea580c;
            letter-spacing: 8px;
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding-left: 8px;
        }
        .timer-info {
            font-size: 13px;
            color: #64748b;
            margin-top: 10px;
        }
        .steps-box {
            background: #fff7ed;
            border-left: 4px solid #ea580c;
            padding: 16px;
            border-radius: 4px;
            margin-top: 24px;
        }
        .steps-box h4 {
            margin: 0 0 8px 0;
            color: #9a3412;
            font-size: 14px;
        }
        .steps-box ul {
            margin: 0;
            padding-left: 20px;
            font-size: 13px;
            color: #7c2d12;
        }
        .steps-box li {
            margin-bottom: 4px;
        }
        .footer {
            background-color: #f8fafc;
            padding: 20px 32px;
            text-align: center;
            border-top: 1px solid #e2e8f0;
            font-size: 12px;
            color: #94a3b8;
        }
        .footer a {
            color: #ea580c;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- HEADER -->
        <div class="header">
            <h1>Saviore</h1>
            <p>Sistema de Cantina Universitária UNESP</p>
            <div class="badge">💳 Ativação de Fiado / Crédito</div>
        </div>

        <!-- CONTENT -->
        <div class="content">
            <div class="greeting">Olá, {{ $nomeAluno }}!</div>
            <p class="text">
                Recebemos sua solicitação para habilitar o serviço de <strong>Crédito / Fiado Cantina</strong> na sua conta Saviore com seu e-mail institucional UNESP.
            </p>

            <div class="otp-container">
                <div class="otp-label">Seu Código de Verificação (OTP)</div>
                <div class="otp-code">{{ $codigoOtp }}</div>
                <div class="timer-info">⏱️ Este código é válido pelos próximos <strong>15 minutos</strong>.</div>
            </div>

            <div class="steps-box">
                <h4>Próximos passos no aplicativo:</h4>
                <ul>
                    <li>Insira o código de 6 dígitos acima na tela de confirmação do app.</li>
                    <li>Crie o seu <strong>PIN de segurança de 6 dígitos</strong> para autorizar compras futuras.</li>
                    <li>Após a validação, seu limite de R$ 50,00 estará disponível imediatamente!</li>
                </ul>
            </div>

            <p class="text" style="margin-top: 24px; font-size: 13px; color: #94a3b8;">
                ⚠️ Se você não solicitou a ativação do crédito, por favor ignore esta mensagem. Nenhuma alteração foi realizada na sua conta.
            </p>
        </div>

        <!-- FOOTER -->
        <div class="footer">
            <p style="margin: 0 0 6px 0;"><strong>Saviore App &bull; UNESP</strong></p>
            <p style="margin: 0;">Mensagem gerada automaticamente pelo sistema de autenticação segura.</p>
        </div>
    </div>
</body>
</html>
