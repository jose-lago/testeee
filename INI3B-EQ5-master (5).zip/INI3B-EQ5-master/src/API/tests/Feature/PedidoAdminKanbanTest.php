<?php

namespace Tests\Feature;

use App\Models\Movimentacao;
use App\Models\Pedido;
use App\Models\PedidoProduto;
use App\Models\Produto;
use App\Models\User;
use App\Services\ExpoNotificationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class PedidoAdminKanbanTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_cannot_mark_an_order_cancelled_without_the_refund_flow(): void
    {
        $admin = $this->createUser('admin');
        $owner = $this->createUser('aluno', ['saldo' => 20]);
        $pedido = $this->createPedido($owner);

        $this->actingAs($admin)
            ->putJson("/api/pedidos/{$pedido->id}", ['status' => 'cancelado'])
            ->assertUnprocessable()
            ->assertJsonPath('message', 'Use o fluxo de cancelamento para garantir o estorno do pagamento.');

        $this->assertSame('pendente', $pedido->fresh()->status);
        $this->assertSame('20.00', (string) $owner->fresh()->saldo);
        $this->assertDatabaseCount('movimentacoes', 0);
    }

    public function test_admin_can_update_status_and_queue_position_without_changing_other_order_data(): void
    {
        $admin = $this->createUser('admin');
        $owner = $this->createUser('aluno');
        $pedido = $this->createPedido($owner);

        $this->actingAs($admin)
            ->putJson("/api/pedidos/{$pedido->id}", [
                'status' => 'preparando',
                'posicao_fila' => 4,
            ])
            ->assertOk()
            ->assertJsonPath('status', 'preparando')
            ->assertJsonPath('posicao_fila', 4);

        $this->assertSame('10.00', (string) $pedido->fresh()->valor_total);
    }

    public function test_destroy_removes_admin_record_without_refunding_or_changing_movements(): void
    {
        $admin = $this->createUser('admin');
        $owner = $this->createUser('aluno', ['saldo' => 20]);
        $pedido = $this->createPedido($owner);
        $movimentacao = Movimentacao::create([
            'user_id' => $owner->id,
            'pedido_id' => $pedido->id,
            'valor' => -10,
            'tipo' => 'pedido',
            'saldo_anterior' => 30,
            'saldo_posterior' => 20,
            'descricao' => 'Pedido teste',
        ]);

        $this->actingAs($admin)
            ->deleteJson("/api/pedidos/{$pedido->id}")
            ->assertOk()
            ->assertJsonPath('message', 'Pedido excluído.');

        $this->assertDatabaseMissing('pedidos', ['id' => $pedido->id]);
        $this->assertDatabaseMissing('pedido_produto', ['pedido_id' => $pedido->id]);
        $this->assertNull($movimentacao->fresh()->pedido_id);
        $this->assertSame('20.00', (string) $owner->fresh()->saldo);
    }

    public function test_undo_returns_ready_order_to_preparing_and_keeps_preparer(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $pedido = $this->createPedido($owner, [
            'status' => 'pronto',
            'preparador_id' => $staff->id,
        ]);

        $this->actingAs($staff)
            ->postJson("/api/pedidos/{$pedido->id}/desfazer")
            ->assertOk()
            ->assertJsonPath('status', 'preparando')
            ->assertJsonPath('preparador_id', $staff->id);

        $this->assertSame('preparando', $pedido->fresh()->status);
    }

    public function test_undo_rejects_orders_with_no_undoable_action(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $pedido = $this->createPedido($owner, ['status' => 'pendente']);

        $this->actingAs($staff)
            ->postJson("/api/pedidos/{$pedido->id}/desfazer")
            ->assertUnprocessable()
            ->assertJsonPath('message', 'Não há ação para desfazer neste pedido.');

        $this->assertSame('pendente', $pedido->fresh()->status);
    }

    public function test_undoing_delivery_restores_ready_status_and_item_delivery_state(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $pedido = $this->createPedido($owner, ['status' => 'entregue']);
        $pedido->itens()->update(['entregue' => true]);

        $this->actingAs($staff)
            ->postJson("/api/pedidos/{$pedido->id}/desfazer")
            ->assertOk()
            ->assertJsonPath('status', 'pronto');

        $this->assertFalse((bool) $pedido->itens()->first()->fresh()->entregue);
    }

    public function test_deliver_next_requires_a_ready_order_and_confirmation(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $pedido = $this->createPedido($owner, ['status' => 'pendente']);

        $this->actingAs($staff)
            ->postJson("/api/pedidos/{$pedido->id}/entregar-proximo", [
                'codigo_confirmado' => true,
            ])
            ->assertUnprocessable()
            ->assertJsonPath('message', 'Somente pedidos prontos podem ser entregues.');

        $this->assertSame('pendente', $pedido->fresh()->status);
    }

    public function test_deliver_next_marks_current_items_and_claims_the_first_pending_order(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $ready = $this->createPedido($owner, ['status' => 'pronto', 'posicao_fila' => 0]);
        $later = $this->createPedido($owner, ['status' => 'pendente', 'posicao_fila' => 2]);
        $first = $this->createPedido($owner, ['status' => 'pendente', 'posicao_fila' => 1]);
        $nonPending = $this->createPedido($owner, ['status' => 'cancelado', 'posicao_fila' => 0]);

        $notification = \Mockery::mock(ExpoNotificationService::class);
        $notification->shouldReceive('enviarParaUsuario')->once();
        $this->app->instance(ExpoNotificationService::class, $notification);

        $response = $this->actingAs($staff)
            ->postJson("/api/pedidos/{$ready->id}/entregar-proximo", [
                'codigo_confirmado' => true,
                'preparador_id' => $staff->id,
            ]);

        $response->assertOk()
            ->assertJsonPath('entregue.id', $ready->id)
            ->assertJsonPath('entregue.status', 'entregue')
            ->assertJsonPath('proximo.id', $first->id)
            ->assertJsonPath('proximo.status', 'preparando')
            ->assertJsonPath('proximo.preparador_id', $staff->id);

        $this->assertTrue((bool) $ready->itens()->first()->fresh()->entregue);
        $this->assertSame('pendente', $later->fresh()->status);
        $this->assertSame('cancelado', $nonPending->fresh()->status);
    }

    public function test_deliver_next_requires_a_staff_preparer_when_an_order_is_waiting(): void
    {
        $staff = $this->createUser('funcionario');
        $owner = $this->createUser('aluno');
        $ready = $this->createPedido($owner, ['status' => 'pronto']);
        $this->createPedido($owner, ['status' => 'pendente']);

        $this->actingAs($staff)
            ->postJson("/api/pedidos/{$ready->id}/entregar-proximo", [
                'codigo_confirmado' => true,
                'preparador_id' => $owner->id,
            ])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('preparador_id');

        $this->assertSame('pronto', $ready->fresh()->status);
    }

    private function createUser(string $tipo, array $attributes = []): User
    {
        return User::create(array_merge([
            'name' => ucfirst($tipo) . ' Teste',
            'email' => $tipo . '-' . uniqid() . '@example.com',
            'password' => Hash::make('password123'),
            'tipo' => $tipo,
            'saldo' => 0,
            'ativo' => true,
        ], $attributes));
    }

    private function createPedido(User $owner, array $attributes = []): Pedido
    {
        $pedido = Pedido::create(array_merge([
            'user_id' => $owner->id,
            'valor_total' => 10,
            'senha_diaria' => (Pedido::max('senha_diaria') ?? 0) + 1,
            'status' => 'pendente',
            'momento_bebida' => 'agora',
            'posicao_fila' => 0,
            'codigo_retirada' => '0001',
        ], $attributes));

        $produto = Produto::create([
            'nome' => 'Produto ' . uniqid(),
            'descricao' => 'Item de teste',
            'preco_atual' => 10,
            'disponivel' => true,
            'categoria' => 'Bebidas',
        ]);

        PedidoProduto::create([
            'pedido_id' => $pedido->id,
            'produto_id' => $produto->id,
            'quantidade' => 1,
            'preco_unitario' => 10,
            'entregue' => false,
        ]);

        return $pedido;
    }
}
