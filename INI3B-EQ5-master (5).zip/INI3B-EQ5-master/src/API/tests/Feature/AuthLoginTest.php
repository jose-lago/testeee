<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthLoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_accepts_email_with_surrounding_spaces_and_different_case(): void
    {
        $user = User::create([
            'name' => 'Aluno Teste',
            'email' => 'Aluno@Example.com',
            'password' => 'SenhaSegura123',
            'tipo' => 'aluno',
            'saldo' => 0,
            'ativo' => true,
        ]);

        $this->postJson('/api/login', [
            'email' => '  aluno@example.com  ',
            'password' => 'SenhaSegura123',
        ])
            ->assertOk()
            ->assertJsonPath('user.email', $user->email)
            ->assertJsonStructure(['token', 'user']);
    }

    public function test_login_still_rejects_an_incorrect_password(): void
    {
        User::create([
            'name' => 'Aluno Teste',
            'email' => 'aluno@example.com',
            'password' => Hash::make('SenhaSegura123'),
            'tipo' => 'aluno',
            'saldo' => 0,
            'ativo' => true,
        ]);

        $this->postJson('/api/login', [
            'email' => 'aluno@example.com',
            'password' => 'SenhaErrada123',
        ])
            ->assertUnauthorized()
            ->assertJsonPath('message', 'Credenciais incorretas.');
    }
}
