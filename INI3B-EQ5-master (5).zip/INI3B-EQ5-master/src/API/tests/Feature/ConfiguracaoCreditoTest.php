<?php

namespace Tests\Feature;

use App\Models\Configuracao;
use App\Models\Produto;
use App\Models\User;
use App\Models\UserCredito;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class ConfiguracaoCreditoTest extends TestCase
{
    use RefreshDatabase;

    /*
     * =========================================================================
     * Leitura e alteração do crédito/fiado pelo painel admin
     * =========================================================================
     */
    public function test_admin_pode_ler_e_alternar_o_status_do_credito(): void
    {
        $admin = $this->createAdmin();
        Configuracao::setValor('credito_ativo', true);

        $this->actingAs($admin)
            ->getJson('/api/configuracoes/credito')
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('credito_ativo', true);

        $this->actingAs($admin)
            ->postJson('/api/configuracoes/credito', ['ativo' => false])
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('credito_ativo', false);

        $this->assertFalse(Configuracao::isCreditoAtivo());

        $this->actingAs($admin)
            ->postJson('/api/configuracoes/credito', ['ativo' => true])
            ->assertOk()
            ->assertJsonPath('credito_ativo', true);

        $this->assertTrue(Configuracao::isCreditoAtivo());
    }

    public function test_aluno_nao_pode_acessar_configuracoes_de_credito(): void
    {
        $aluno = $this->createAluno();

        $this->actingAs($aluno)
            ->getJson('/api/configuracoes/credito')
            ->assertForbidden();

        $this->actingAs($aluno)
            ->postJson('/api/configuracoes/credito', ['ativo' => false])
            ->assertForbidden();
    }

    public function test_configuracoes_de_credito_exigem_autenticacao(): void
    {
        $this->getJson('/api/configuracoes/credito')->assertUnauthorized();
        $this->postJson('/api/configuracoes/credito', ['ativo' => false])->assertUnauthorized();
    }

    /*
     * =========================================================================
     * Crédito desativado deve bloquear o pagamento por crédito no Totem
     * =========================================================================
     */
    public function test_credito_desativado_bloqueia_pagamento_por_credito_no_totem(): void
    {
        Configuracao::setValor('credito_ativo', false);

        $user = $this->createAluno(['saldo' => 0.00]);
        $this->createCredit($user);

        $produto = Produto::create([
            'nome' => 'Suco',
            'descricao' => 'Bebida',
            'preco_atual' => 10.00,
            'disponivel' => true,
            'categoria' => 'Bebidas',
            'imagem' => null,
        ]);

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', [
                'rfid_code' => $user->rfid_code,
                'forma_pagamento' => 'credito',
                'pin' => '123456',
                'momento_bebida' => 'agora',
                'itens' => [[
                    'produto_id' => $produto->id,
                    'quantidade' => 1,
                ]],
            ])
            ->assertStatus(400)
            ->assertJsonPath(
                'message',
                'A funcionalidade de crédito / fiado está temporariamente desativada pela cantina.'
            );

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame('0.00', (string) $user->fresh()->saldo);
        $this->assertSame('0.00', (string) $user->credito->fresh()->divida_atual);
    }

    private function createAdmin(): User
    {
        return User::create([
            'name' => 'Admin Cantina',
            'email' => 'admin-' . uniqid() . '@example.com',
            'password' => Hash::make('password'),
            'tipo' => 'admin',
            'saldo' => 0.00,
            'ativo' => true,
        ]);
    }

    private function createAluno(array $attributes = []): User
    {
        return User::create(array_merge([
            'name' => 'Aluno Teste',
            'email' => 'aluno-' . uniqid() . '@example.com',
            'password' => Hash::make('password'),
            'tipo' => 'aluno',
            'saldo' => 0.00,
            'ativo' => true,
            'rfid_code' => 'CARD-' . uniqid(),
            'rfid_blocked' => false,
            'rfid_pin' => Hash::make('123456'),
        ], $attributes));
    }

    private function createCredit(User $user, array $attributes = []): UserCredito
    {
        return UserCredito::create(array_merge([
            'user_id' => $user->id,
            'cpf' => '12345678901',
            'ra' => 'RA' . uniqid(),
            'telefone' => '11999999999',
            'email_institucional' => 'aluno-' . uniqid() . '@unesp.br',
            'pin' => Hash::make('123456'),
            'limite' => 50.00,
            'divida_atual' => 0.00,
            'verificado' => true,
        ], $attributes));
    }
}
