<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class CreditoRouteAccessTest extends TestCase
{
    public function test_student_credit_routes_are_registered_only_once(): void
    {
        $routes = collect(Route::getRoutes()->getRoutes())
            ->filter(fn ($route) => in_array('POST', $route->methods()) && $route->uri() === 'api/credito/solicitar')
            ->values();

        $this->assertCount(1, $routes);
    }
}