<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\Pedido;
use App\Models\PedidoProduto;
use App\Models\User;
use App\Models\UserCredito;
use Illuminate\Contracts\Cache\LockProvider;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Hash;
use RuntimeException;
use Tests\TestCase;

class TotemRoutesTest extends TestCase
{
    use RefreshDatabase;

    public function test_totem_routes_require_device_token(): void
    {
        $response = $this->getJson('/api/totem/produtos');

        $response->assertStatus(401);
        $response->assertJsonPath('message', 'Dispositivo não autorizado.');
    }

    public function test_user_can_set_rfid_pin_for_linked_card(): void
    {
        $user = $this->createUser(['rfid_pin' => null]);
        $pin = (string) random_int(100000, 999999);

        $this->actingAs($user)
            ->postJson('/api/me/rfid/pin', [
                'novo_pin' => $pin,
                'novo_pin_confirmation' => $pin,
            ])
            ->assertOk()
            ->assertJsonPath(
                'message',
                'Senha do cartão RFID cadastrada com sucesso. Você já pode usar o totem!'
            );

        $storedHash = $user->fresh()->getRawOriginal('rfid_pin');
        $this->assertTrue(Hash::check($pin, $storedHash));

        $this->actingAs($user)
            ->getJson('/api/me')
            ->assertOk()
            ->assertJsonPath('tem_pin_cadastrado', true)
            ->assertJsonMissingPath('rfid_pin');
    }

    public function test_totem_finalization_requires_device_token(): void
    {
        $this->postJson('/api/totem/pedidos/finalizar', [])
            ->assertUnauthorized()
            ->assertJsonPath('message', 'Dispositivo não autorizado.');
    }

    public function test_totem_user_lookup_accepts_valid_device_token(): void
    {
        $user = User::create([
            'name' => 'Aluno Totem',
            'email' => 'totem-aluno@example.com',
            'password' => Hash::make('secret123'),
            'tipo' => 'aluno',
            'saldo' => 20.00,
            'ativo' => true,
            'rfid_code' => 'CARD-TESTE',
            'rfid_blocked' => false,
        ]);

        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->getJson('/api/totem/usuario/' . urlencode($user->rfid_code));

        $response->assertStatus(200);
        $response->assertJsonPath('id', $user->id);
        $response->assertJsonPath('nome', $user->name);
    }

    public function test_totem_finalization_rejects_invalid_card_pin(): void
    {
        $user = User::create([
            'name' => 'Aluno Crédito',
            'email' => 'credito@example.com',
            'password' => Hash::make('secret123'),
            'tipo' => 'aluno',
            'saldo' => 0.00,
            'ativo' => true,
            'rfid_code' => 'CARD-CREDITO',
            'rfid_blocked' => false,
            'rfid_pin' => Hash::make('123456'),
        ]);

        UserCredito::create([
            'user_id' => $user->id,
            'cpf' => '12345678901',
            'ra' => 'RO1234',
            'telefone' => '11999999999',
            'email_institucional' => 'aluno@unesp.br',
            'pin' => Hash::make('123456'),
            'limite' => 50.00,
            'divida_atual' => 0.00,
            'verificado' => true,
        ]);

        Produto::create([
            'nome' => 'Café',
            'descricao' => 'Bebida',
            'preco_atual' => 12.50,
            'disponivel' => true,
            'categoria' => 'Bebidas',
            'imagem' => null,
        ]);

        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', [
                'rfid_code' => 'CARD-CREDITO',
                'forma_pagamento' => 'credito',
                'pin' => '999999',
                'momento_bebida' => 'agora',
                'itens' => [[
                    'produto_id' => 1,
                    'quantidade' => 1,
                ]],
            ]);

        $response->assertStatus(400);
        $response->assertJsonPath('message', 'Senha do cartão incorreta.');
    }

    public function test_totem_user_lookup_rejects_unknown_blocked_and_inactive_cards(): void
    {
        $blockedUser = $this->createUser([
            'email' => 'blocked@example.com',
            'rfid_code' => 'CARD-BLOCKED',
            'rfid_blocked' => true,
        ]);
        $inactiveUser = $this->createUser([
            'email' => 'inactive@example.com',
            'rfid_code' => 'CARD-INACTIVE',
            'ativo' => false,
        ]);

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->getJson('/api/totem/usuario/UNKNOWN-CARD')
            ->assertNotFound()
            ->assertJsonPath('message', 'Cartão não encontrado.');

        $this->getJson('/api/totem/usuario/' . $blockedUser->rfid_code)
            ->assertForbidden()
            ->assertJsonPath('message', 'Cartão bloqueado.');

        $this->getJson('/api/totem/usuario/' . $inactiveUser->rfid_code)
            ->assertForbidden()
            ->assertJsonPath('message', 'Usuário inativo.');
    }

    public function test_totem_finalization_rejects_unavailable_product_and_invalid_payload(): void
    {
        $user = $this->createUser([
            'email' => 'unavailable@example.com',
            'rfid_code' => 'CARD-UNAVAILABLE',
        ]);
        $product = $this->createProduct(['disponivel' => false]);

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', $this->finalizationPayload($user, $product))
            ->assertStatus(422)
            ->assertJsonPath('message', "Produto '{$product->nome}' indisponível.");

        $this->postJson('/api/totem/pedidos/finalizar', [
            'rfid_code' => $user->rfid_code,
            'forma_pagamento' => 'saldo',
            'itens' => [],
        ])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimentacoes', 0);
        $this->assertSame('20.00', (string) $user->fresh()->saldo);
    }

    public function test_totem_finalization_accepts_a_valid_credit_pin(): void
    {
        $user = $this->createUser([
            'email' => 'valid-pin@example.com',
            'rfid_code' => 'CARD-VALID-PIN',
            'saldo' => 0,
        ]);
        $this->createCredit($user);
        $product = $this->createProduct();

        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', array_merge(
                $this->finalizationPayload($user, $product),
                ['forma_pagamento' => 'credito', 'pin' => '123456']
            ));

        $response->assertCreated();
        $this->assertSame('12.50', (string) UserCredito::where('user_id', $user->id)->value('divida_atual'));
        $this->assertDatabaseCount('pedidos', 1);
        $this->assertDatabaseCount('movimentacoes', 1);
    }

    public function test_totem_finalization_rejects_an_incorrect_six_digit_pin(): void
    {
        $user = $this->createUser([
            'email' => 'invalid-pin@example.com',
            'rfid_code' => 'CARD-INVALID-PIN',
            'saldo' => 0,
        ]);
        $this->createCredit($user);
        $product = $this->createProduct();

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', array_merge(
                $this->finalizationPayload($user, $product),
                ['forma_pagamento' => 'credito', 'pin' => '000000']
            ))
            ->assertStatus(400)
            ->assertJsonPath('message', 'Senha do cartão incorreta.');

        $this->assertSame('0.00', (string) UserCredito::where('user_id', $user->id)->value('divida_atual'));
        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimentacoes', 0);
    }

    public function test_totem_finalization_rejects_an_inactive_user_without_charging(): void
    {
        $user = $this->createUser([
            'email' => 'inactive-checkout@example.com',
            'rfid_code' => 'CARD-INACTIVE-CHECKOUT',
            'ativo' => false,
        ]);
        $product = $this->createProduct();

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', $this->finalizationPayload($user, $product))
            ->assertStatus(400)
            ->assertJsonPath('message', 'Usuário inativo.');

        $this->assertSame('20.00', (string) $user->fresh()->saldo);
        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimentacoes', 0);
    }

    public function test_totem_finalization_rejects_insufficient_balance_and_credit_without_charging(): void
    {
        $balanceUser = $this->createUser([
            'email' => 'low-balance-checkout@example.com',
            'rfid_code' => 'CARD-LOW-BALANCE-CHECKOUT',
            'saldo' => 5.00,
        ]);
        $creditUser = $this->createUser([
            'email' => 'low-credit-checkout@example.com',
            'rfid_code' => 'CARD-LOW-CREDIT-CHECKOUT',
            'saldo' => 0.00,
        ]);
        $this->createCredit($creditUser);
        UserCredito::where('user_id', $creditUser->id)->update(['divida_atual' => 45.00]);
        $product = $this->createProduct();
        $headers = ['X-Totem-Token' => 'totem-dev-token'];

        $this->withHeaders($headers)
            ->postJson('/api/totem/pedidos/finalizar', $this->finalizationPayload($balanceUser, $product))
            ->assertStatus(400)
            ->assertJsonPath('message', 'Saldo insuficiente.');

        $this->postJson('/api/totem/pedidos/finalizar', array_merge(
            $this->finalizationPayload($creditUser, $product),
            ['forma_pagamento' => 'credito', 'pin' => '123456']
        ))
            ->assertStatus(400)
            ->assertJsonPath('message', 'Limite de crédito insuficiente.');

        $this->assertSame('5.00', (string) $balanceUser->fresh()->saldo);
        $this->assertSame('45.00', (string) UserCredito::where('user_id', $creditUser->id)->value('divida_atual'));
        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimentacoes', 0);
    }

    public function test_totem_finalization_uses_next_daily_ticket_after_existing_orders(): void
    {
        $user = $this->createUser([
            'email' => 'daily-ticket@example.com',
            'rfid_code' => 'CARD-DAILY-TICKET',
            'saldo' => 50.00,
        ]);
        $product = $this->createProduct();

        Pedido::create([
            'user_id' => $user->id,
            'valor_total' => 5.00,
            'senha_diaria' => 7,
            'status' => 'pendente',
            'momento_bebida' => 'agora',
            'posicao_fila' => 0,
            'codigo_retirada' => '0007',
        ]);

        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', $this->finalizationPayload($user, $product));

        $response->assertCreated();
        $response->assertJsonPath('senha_diaria', 8);
        $this->assertSame('37.50', (string) $user->fresh()->saldo);
        $this->assertDatabaseCount('pedidos', 2);
        $this->assertDatabaseCount('movimentacoes', 1);
    }

    public function test_totem_finalization_rolls_back_payment_when_order_item_creation_fails(): void
    {
        $user = $this->createUser([
            'email' => 'rollback@example.com',
            'rfid_code' => 'CARD-ROLLBACK',
        ]);
        $product = $this->createProduct();

        Event::listen('eloquent.creating: ' . PedidoProduto::class, function () {
            throw new RuntimeException('Falha simulada ao gravar item.');
        });

        $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', $this->finalizationPayload($user, $product))
            ->assertStatus(400)
            ->assertJsonPath('message', 'Falha simulada ao gravar item.');

        $this->assertSame('20.00', (string) $user->fresh()->saldo);
        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('pedido_produto', 0);
        $this->assertDatabaseCount('movimentacoes', 0);
    }

    public function test_totem_routes_enforce_the_configured_rate_limit(): void
    {
        $this->withHeader('X-Totem-Token', 'totem-dev-token');

        for ($request = 0; $request < 60; $request++) {
            $this->getJson('/api/totem/produtos')->assertOk();
        }

        $this->getJson('/api/totem/produtos')->assertTooManyRequests();
    }

    public function test_daily_order_lock_allows_only_one_concurrent_owner(): void
    {
        $lockStore = Cache::store('database')->getStore();
        $this->assertInstanceOf(LockProvider::class, $lockStore);

        $firstLock = $lockStore->lock('pedido-senha-diaria:test', 120);
        $secondLock = $lockStore->lock('pedido-senha-diaria:test', 120);

        $this->assertTrue($firstLock->get());
        $this->assertFalse($secondLock->get());

        $firstLock->release();
        $this->assertTrue($secondLock->get());
        $secondLock->release();
    }

    private function createUser(array $attributes = []): User
    {
        return User::create(array_merge([
            'name' => 'Aluno Totem',
            'email' => 'totem-' . uniqid() . '@example.com',
            'password' => Hash::make('secret123'),
            'tipo' => 'aluno',
            'saldo' => 20.00,
            'ativo' => true,
            'rfid_code' => 'CARD-' . uniqid(),
            'rfid_blocked' => false,
            'rfid_pin' => Hash::make('123456'),
        ], $attributes));
    }

    private function createProduct(array $attributes = []): Produto
    {
        return Produto::create(array_merge([
            'nome' => 'Café teste',
            'descricao' => 'Bebida de teste',
            'preco_atual' => 12.50,
            'disponivel' => true,
            'categoria' => 'Bebidas',
            'imagem' => null,
        ], $attributes));
    }

    private function createCredit(User $user): UserCredito
    {
        return UserCredito::create([
            'user_id' => $user->id,
            'cpf' => '12345678901',
            'ra' => 'RA1234',
            'telefone' => '11999999999',
            'email_institucional' => 'aluno@unesp.br',
            'pin' => Hash::make('123456'),
            'limite' => 50.00,
            'divida_atual' => 0.00,
            'verificado' => true,
        ]);
    }

    private function finalizationPayload(User $user, Produto $product): array
    {
        return [
            'rfid_code' => $user->rfid_code,
            'forma_pagamento' => 'saldo',
            'pin' => '123456',
            'momento_bebida' => 'agora',
            'itens' => [[
                'produto_id' => $product->id,
                'quantidade' => 1,
            ]],
        ];
    }
}
