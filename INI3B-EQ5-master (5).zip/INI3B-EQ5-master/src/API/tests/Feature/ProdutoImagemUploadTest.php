<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProdutoImagemUploadTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_upload_stores_image_publicly_and_returns_request_host_url(): void
    {
        $admin = $this->createAdmin();
        $caminho = null;

        try {
            $response = $this->withServerVariables([
                'HTTP_HOST' => 'api.saviore.test',
                'HTTPS' => 'on',
                'HTTP_X_FORWARDED_HOST' => 'api.saviore.test',
                'HTTP_X_FORWARDED_PROTO' => 'https',
            ])->actingAs($admin)->post('/api/produtos', [
                'nome' => 'Produto com imagem',
                'descricao' => 'Imagem de teste',
                'preco_atual' => 10,
                'disponivel' => '1',
                'categoria' => 'almoco',
                'imagem' => $this->fakeImage('produto.png'),
            ]);

            $response->assertCreated();

            $caminho = $response->json('imagem');
            $this->assertTrue(Storage::disk('public')->exists($caminho));
            $this->assertStringStartsWith(
                Storage::disk('public')->path('produtos'),
                Storage::disk('public')->path($caminho)
            );
            $this->assertSame(
                "https://api.saviore.test/storage/{$caminho}",
                $response->json('imagem_url')
            );
            $this->assertSame($caminho, Produto::firstOrFail()->imagem);
        } finally {
            if ($caminho) {
                Storage::disk('public')->delete($caminho);
            }
        }
    }

    public function test_replacing_an_image_stores_the_new_file_before_removing_the_old_one(): void
    {
        $admin = $this->createAdmin();
        $imagemAntiga = $this->fakeImage('antiga.png')->store('produtos', 'public');
        $imagemNova = null;
        $produto = Produto::create([
            'nome' => 'Produto com imagem',
            'preco_atual' => 10,
            'disponivel' => true,
            'categoria' => 'almoco',
            'imagem' => $imagemAntiga,
        ]);

        try {
            $response = $this->actingAs($admin)->post("/api/produtos/{$produto->id}", [
                '_method' => 'PUT',
                'imagem' => $this->fakeImage('nova.png'),
            ]);

            $response->assertOk();

            $imagemNova = $response->json('imagem');
            $this->assertNotSame($imagemAntiga, $imagemNova);
            $this->assertTrue(Storage::disk('public')->exists($imagemNova));
            $this->assertFalse(Storage::disk('public')->exists($imagemAntiga));
            $this->assertSame($imagemNova, $produto->fresh()->imagem);
        } finally {
            Storage::disk('public')->delete($imagemAntiga);
            if ($imagemNova) {
                Storage::disk('public')->delete($imagemNova);
            }
        }
    }

    private function createAdmin(): User
    {
        return User::create([
            'name' => 'Admin Teste',
            'email' => 'admin-' . uniqid() . '@example.com',
            'password' => 'password',
            'tipo' => 'admin',
            'saldo' => 0,
            'ativo' => true,
        ]);
    }

    private function fakeImage(string $name): UploadedFile
    {
        return UploadedFile::fake()->createWithContent(
            $name,
            base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADUlEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC')
        );
    }
}
