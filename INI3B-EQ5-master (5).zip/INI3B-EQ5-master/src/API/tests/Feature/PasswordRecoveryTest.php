<?php

namespace Tests\Feature;

use App\Mail\CodigoRecuperacaoSenhaMail;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class PasswordRecoveryTest extends TestCase
{
    use RefreshDatabase;

    public function test_existing_user_receives_a_recovery_code_without_exposing_it_in_the_response(): void
    {
        Mail::fake();
        $user = $this->createUser();

        $response = $this->postJson('/api/password/forgot', ['email' => $user->email]);

        $response->assertOk()
            ->assertJsonPath(
                'message',
                'Se houver uma conta associada a esse e-mail, enviaremos um código de recuperação.'
            )
            ->assertJsonMissingPath('codigo')
            ->assertJsonMissingPath('otp_debug');

        Mail::assertSent(CodigoRecuperacaoSenhaMail::class, function (CodigoRecuperacaoSenhaMail $mail) use ($user) {
            return $mail->hasTo($user->email)
                && strlen($mail->codigoOtp) === 6
                && ctype_digit($mail->codigoOtp);
        });
    }

    public function test_unknown_email_gets_the_same_generic_response_without_sending_mail(): void
    {
        Mail::fake();
        $existing = $this->createUser();

        $existingResponse = $this->postJson('/api/password/forgot', ['email' => $existing->email]);
        $unknownResponse = $this->postJson('/api/password/forgot', ['email' => 'unknown@example.com']);

        $existingResponse->assertOk();
        $unknownResponse->assertOk()
            ->assertExactJson($existingResponse->json());
        Mail::assertSent(CodigoRecuperacaoSenhaMail::class, 1);
    }

    public function test_invalid_recovery_code_does_not_change_the_password(): void
    {
        Mail::fake();
        $user = $this->createUser();
        $this->postJson('/api/password/forgot', ['email' => $user->email])->assertOk();
        $mail = Mail::sent(CodigoRecuperacaoSenhaMail::class)->first();

        $this->postJson('/api/password/reset', $this->resetPayload($user, $this->incorrectCode($mail->codigoOtp)))
            ->assertUnprocessable()
            ->assertJsonPath('message', 'Código inválido ou expirado. Solicite um novo código.');

        $this->assertFalse(Hash::check('Abc123', $user->fresh()->password));
    }

    public function test_expired_recovery_code_cannot_be_used(): void
    {
        Mail::fake();
        $user = $this->createUser();
        $this->postJson('/api/password/forgot', ['email' => $user->email])->assertOk();
        $mail = Mail::sent(CodigoRecuperacaoSenhaMail::class)->first();

        $this->travel(16)->minutes();

        $this->postJson('/api/password/reset', $this->resetPayload($user, $mail->codigoOtp))
            ->assertUnprocessable();

        $this->assertFalse(Hash::check('Abc123', $user->fresh()->password));
    }

    public function test_new_password_must_be_exactly_six_characters_and_match_confirmation(): void
    {
        Mail::fake();
        $user = $this->createUser();
        $this->postJson('/api/password/forgot', ['email' => $user->email])->assertOk();
        $mail = Mail::sent(CodigoRecuperacaoSenhaMail::class)->first();

        $this->postJson('/api/password/reset', [
            'email' => $user->email,
            'codigo' => $mail->codigoOtp,
            'password' => 'Ab123',
            'password_confirmation' => 'Ab123',
        ])->assertUnprocessable()
            ->assertJsonValidationErrors('password');

        $this->postJson('/api/password/reset', [
            'email' => $user->email,
            'codigo' => $mail->codigoOtp,
            'password' => 'Abcd123',
            'password_confirmation' => 'Abcd123',
        ])->assertUnprocessable()
            ->assertJsonValidationErrors('password');

        $this->postJson('/api/password/reset', [
            'email' => $user->email,
            'codigo' => $mail->codigoOtp,
            'password' => 'Abc123',
            'password_confirmation' => 'Abc124',
        ])->assertUnprocessable()
            ->assertJsonValidationErrors('password');

        $this->assertFalse(Hash::check('Abc123', $user->fresh()->password));
    }

    public function test_valid_code_resets_password_and_cannot_be_reused(): void
    {
        Mail::fake();
        $user = $this->createUser();
        $this->postJson('/api/password/forgot', ['email' => $user->email])->assertOk();
        $mail = Mail::sent(CodigoRecuperacaoSenhaMail::class)->first();

        $this->postJson('/api/password/reset', $this->resetPayload($user, $mail->codigoOtp))
            ->assertOk()
            ->assertJsonPath('message', 'Senha redefinida com sucesso. Entre com sua nova senha.');

        $this->assertTrue(Hash::check('Abc123', $user->fresh()->password));

        $this->postJson('/api/password/reset', $this->resetPayload($user, $mail->codigoOtp))
            ->assertUnprocessable();
    }

    private function resetPayload(User $user, string $codigo): array
    {
        return [
            'email' => $user->email,
            'codigo' => $codigo,
            'password' => 'Abc123',
            'password_confirmation' => 'Abc123',
        ];
    }

    private function incorrectCode(string $codigo): string
    {
        return ($codigo[0] === '0' ? '1' : '0') . substr($codigo, 1);
    }

    private function createUser(): User
    {
        return User::create([
            'name' => 'Aluno Teste',
            'email' => 'aluno-' . uniqid() . '@example.com',
            'password' => 'OldPassword123',
            'tipo' => 'aluno',
            'saldo' => 0,
            'ativo' => true,
        ]);
    }
}
