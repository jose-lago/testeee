<?php

namespace Tests\Feature;

use App\Models\Movimentacao;
use App\Models\Pedido;
use App\Models\PedidoProduto;
use App\Models\Produto;
use App\Models\User;
use App\Models\UserCredito;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Hash;
use RuntimeException;
use Tests\TestCase;

class PedidoCancelamentoTest extends TestCase
{
    use RefreshDatabase;

    /*
     * =========================================================================
     * 1. Pedido pago com SALDO
     * =========================================================================
     */
    public function test_cancela_pedido_pago_com_saldo_estornando_apenas_o_saldo(): void
    {
        $user = $this->createUser(['saldo' => 20.00]);
        $credito = $this->createCredit($user, ['divida_atual' => 7.00]);

        $pedido = $this->createPedido($user, [
            'valor_total' => 12.50,
            'forma_pagamento' => 'saldo',
        ]);

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedido->id}/cancelar")
            ->assertOk()
            ->assertJsonPath('message', 'Cancelado')
            ->assertJsonPath('estorno.forma_pagamento', 'saldo');

        // Saldo voltou ao valor original (12.50 devolvidos).
        $this->assertSame('32.50', (string) $user->fresh()->saldo);

        // Crédito NÃO foi tocado.
        $this->assertSame('7.00', (string) $credito->fresh()->divida_atual);

        $this->assertSame('cancelado', $pedido->fresh()->status);

        // Uma única movimentação de estorno, com saldo_anterior/posterior do SALDO.
        $estorno = Movimentacao::where('pedido_id', $pedido->id)
            ->where('tipo', 'estorno')
            ->get();

        $this->assertCount(1, $estorno);
        $this->assertSame('20.00', (string) $estorno->first()->saldo_anterior);
        $this->assertSame('32.50', (string) $estorno->first()->saldo_posterior);
        $this->assertSame('12.50', (string) $estorno->first()->valor);
    }

    /*
     * =========================================================================
     * 2. Pedido pago com CRÉDITO
     * =========================================================================
     */
    public function test_cancela_pedido_pago_com_credito_revertendo_a_divida(): void
    {
        $user = $this->createUser(['saldo' => 20.00]);
        $credito = $this->createCredit($user, ['divida_atual' => 30.00]);

        $pedido = $this->createPedido($user, [
            'valor_total' => 12.50,
            'forma_pagamento' => 'credito',
        ]);

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedido->id}/cancelar")
            ->assertOk()
            ->assertJsonPath('estorno.forma_pagamento', 'credito');

        // Dívida voltou ao valor original (12.50 revertidos).
        $this->assertSame('17.50', (string) $credito->fresh()->divida_atual);

        // Saldo permanece INTOCADO.
        $this->assertSame('20.00', (string) $user->fresh()->saldo);

        $this->assertSame('cancelado', $pedido->fresh()->status);

        $estorno = Movimentacao::where('pedido_id', $pedido->id)
            ->where('tipo', 'estorno')
            ->first();

        $this->assertNotNull($estorno);
        $this->assertSame('30.00', (string) $estorno->saldo_anterior);
        $this->assertSame('17.50', (string) $estorno->saldo_posterior);
    }

    /*
     * =========================================================================
     * 3. CRÉDITO NÃO DEVE DEVOLVER VALOR AO SALDO (regressão do bug)
     * =========================================================================
     */
    public function test_cancelamento_com_credito_nao_credita_o_saldo_do_usuario(): void
    {
        $user = $this->createUser(['saldo' => 5.00]);
        $this->createCredit($user, ['divida_atual' => 12.50]);

        $pedido = $this->createPedido($user, [
            'valor_total' => 12.50,
            'forma_pagamento' => 'credito',
        ]);

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedido->id}/cancelar")
            ->assertOk();

        // Este é o bug original: o saldo subia de 5.00 para 17.50.
        $this->assertSame('5.00', (string) $user->fresh()->saldo);
    }

    /*
     * =========================================================================
     * 4. Compatibilidade: pedido antigo (forma_pagamento NULL) = saldo
     * =========================================================================
     */
    public function test_pedido_antigo_sem_forma_pagamento_e_tratado_como_saldo(): void
    {
        $user = $this->createUser(['saldo' => 20.00]);

        $pedido = $this->createPedido($user, [
            'valor_total' => 10.00,
            'forma_pagamento' => null,
        ]);

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedido->id}/cancelar")
            ->assertOk()
            ->assertJsonPath('estorno.forma_pagamento', 'saldo');

        $this->assertSame('30.00', (string) $user->fresh()->saldo);
    }

    /*
     * =========================================================================
     * 5. IMPEDIR ESTORNO DUPLO
     * =========================================================================
     */
    public function test_impede_o_segundo_cancelamento_e_o_estorno_duplo(): void
    {
        $user = $this->createUser(['saldo' => 20.00]);
        $credito = $this->createCredit($user, ['divida_atual' => 20.00]);

        $pedidoSaldo = $this->createPedido($user, [
            'valor_total' => 10.00,
            'forma_pagamento' => 'saldo',
        ]);

        $pedidoCredito = $this->createPedido($user, [
            'valor_total' => 15.00,
            'forma_pagamento' => 'credito',
        ]);

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoSaldo->id}/cancelar")
            ->assertOk();

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoSaldo->id}/cancelar")
            ->assertStatus(409)
            ->assertJsonPath('message', 'Este pedido já foi cancelado.');

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoCredito->id}/cancelar")
            ->assertOk();

        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoCredito->id}/cancelar")
            ->assertStatus(409);

        // Saldo e dívida foram alterados exatamente UMA vez.
        $this->assertSame('30.00', (string) $user->fresh()->saldo);
        $this->assertSame('5.00', (string) $credito->fresh()->divida_atual);

        // Exatamente 2 movimentações de estorno no total (uma por pedido).
        $this->assertSame(2, Movimentacao::where('tipo', 'estorno')->count());
    }

    /*
     * =========================================================================
     * 6. IMPEDIR QUE OUTRO USUÁRIO CANCELE
     * =========================================================================
     */
    public function test_impede_o_cancelamento_de_pedido_de_outro_usuario(): void
    {
        $dono = $this->createUser(['saldo' => 20.00]);
        $intruso = $this->createUser(['saldo' => 20.00]);

        $pedido = $this->createPedido($dono, [
            'valor_total' => 15.00,
            'forma_pagamento' => 'saldo',
        ]);

        $this->actingAs($intruso)
            ->postJson("/api/pedidos/{$pedido->id}/cancelar")
            ->assertForbidden()
            ->assertJsonPath('message', 'Acesso negado.');

        $this->assertSame('pendente', $pedido->fresh()->status);
        $this->assertSame('20.00', (string) $dono->fresh()->saldo);
        $this->assertSame('20.00', (string) $intruso->fresh()->saldo);
        $this->assertSame(0, Movimentacao::where('tipo', 'estorno')->count());
    }

    /*
     * =========================================================================
     * 7. IMPEDIR CANCELAMENTO DE PEDIDO NÃO PENDENTE
     * =========================================================================
     */
    public function test_impede_o_cancelamento_de_pedido_que_nao_esta_pendente(): void
    {
        foreach (['preparando', 'pronto', 'entregue'] as $status) {
            $user = $this->createUser(['saldo' => 20.00]);
            $pedido = $this->createPedido($user, [
                'valor_total' => 15.00,
                'forma_pagamento' => 'saldo',
                'status' => $status,
            ]);

            $this->actingAs($user)
                ->postJson("/api/pedidos/{$pedido->id}/cancelar")
                ->assertForbidden()
                ->assertJsonPath('message', 'Não é possível cancelar, o pedido já está em preparo.');

            $this->assertSame($status, $pedido->fresh()->status);
            $this->assertSame('20.00', (string) $user->fresh()->saldo);
        }

        $this->assertSame(0, Movimentacao::where('tipo', 'estorno')->count());
    }

    /*
     * =========================================================================
     * 8. ROLLBACK quando a movimentação falha
     * =========================================================================
     */
    public function test_faz_rollback_quando_a_gravacao_da_movimentacao_falha(): void
    {
        $user = $this->createUser(['saldo' => 20.00]);
        $credito = $this->createCredit($user, ['divida_atual' => 30.00]);

        $pedidoSaldo = $this->createPedido($user, [
            'valor_total' => 10.00,
            'forma_pagamento' => 'saldo',
        ]);

        $pedidoCredito = $this->createPedido($user, [
            'valor_total' => 15.00,
            'forma_pagamento' => 'credito',
        ]);

        Event::listen('eloquent.creating: ' . Movimentacao::class, function () {
            throw new RuntimeException('Falha simulada ao gravar movimentação.');
        });

        // Estorno de SALDO deve reverter por completo.
        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoSaldo->id}/cancelar")
            ->assertStatus(500);

        $this->assertSame('pendente', $pedidoSaldo->fresh()->status);
        $this->assertSame('20.00', (string) $user->fresh()->saldo);

        // Estorno de CRÉDITO também deve reverter por completo.
        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoCredito->id}/cancelar")
            ->assertStatus(500);

        $this->assertSame('pendente', $pedidoCredito->fresh()->status);
        $this->assertSame('20.00', (string) $user->fresh()->saldo);
        $this->assertSame('30.00', (string) $credito->fresh()->divida_atual);

        $this->assertSame(0, Movimentacao::count());
    }

    /*
     * =========================================================================
     * 9. FLUXO INTEGRADO: Totem -> crédito -> cancelamento
     * =========================================================================
     */
    public function test_fluxo_totem_com_credito_registra_forma_pagamento_e_estorna_a_divida(): void
    {
        $user = $this->createUser([
            'saldo' => 20.00,
            'rfid_code' => 'CARD-TOTEM-CANCEL',
        ]);

        $this->createCredit($user, ['divida_atual' => 0.00, 'limite' => 50.00]);

        $produto = Produto::create([
            'nome' => 'Café',
            'descricao' => 'Bebida',
            'preco_atual' => 12.50,
            'disponivel' => true,
            'categoria' => 'Bebidas',
            'imagem' => null,
        ]);

        // 1. Pedido criado pelo Totem pagando com CRÉDITO.
        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', [
                'rfid_code' => $user->rfid_code,
                'forma_pagamento' => 'credito',
                'pin' => '123456',
                'momento_bebida' => 'agora',
                'itens' => [[
                    'produto_id' => $produto->id,
                    'quantidade' => 1,
                ]],
            ]);

        $response->assertCreated();
        $pedidoId = $response->json('id');

        // A forma de pagamento foi persistida no pedido.
        $pedido = Pedido::find($pedidoId);
        $this->assertSame('credito', $pedido->forma_pagamento);
        $this->assertSame('12.50', (string) UserCredito::where('user_id', $user->id)->value('divida_atual'));
        $this->assertSame('20.00', (string) $user->fresh()->saldo);

        // 2. O aluno cancela pelo app.
        $this->actingAs($user)
            ->postJson("/api/pedidos/{$pedidoId}/cancelar")
            ->assertOk()
            ->assertJsonPath('estorno.forma_pagamento', 'credito');

        // 3. Dívida revertida; saldo nunca foi mexido.
        $this->assertSame('0.00', (string) UserCredito::where('user_id', $user->id)->value('divida_atual'));
        $this->assertSame('20.00', (string) $user->fresh()->saldo);
        $this->assertSame('cancelado', $pedido->fresh()->status);
    }

    /*
     * =========================================================================
     * 10. O Totem também deve gravar 'saldo' explicitamente
     * =========================================================================
     */
    public function test_fluxo_totem_com_saldo_registra_forma_pagamento_saldo(): void
    {
        $user = $this->createUser([
            'saldo' => 50.00,
            'rfid_code' => 'CARD-TOTEM-SALDO',
        ]);

        $produto = Produto::create([
            'nome' => 'Suco',
            'descricao' => 'Bebida',
            'preco_atual' => 10.00,
            'disponivel' => true,
            'categoria' => 'Bebidas',
            'imagem' => null,
        ]);

        $response = $this->withHeader('X-Totem-Token', 'totem-dev-token')
            ->postJson('/api/totem/pedidos/finalizar', [
                'rfid_code' => $user->rfid_code,
                'forma_pagamento' => 'saldo',
                'pin' => '123456',
                'momento_bebida' => 'agora',
                'itens' => [[
                    'produto_id' => $produto->id,
                    'quantidade' => 1,
                ]],
            ]);

        $response->assertCreated();
        $pedido = Pedido::find($response->json('id'));

        $this->assertSame('saldo', $pedido->forma_pagamento);
        $this->assertSame('40.00', (string) $user->fresh()->saldo);
    }

    /*
     * =========================================================================
     * Helpers
     * =========================================================================
     */
    private function createUser(array $attributes = []): User
    {
        return User::create(array_merge([
            'name' => 'Aluno Teste',
            'email' => 'aluno-' . uniqid() . '@example.com',
            'password' => Hash::make('password'),
            'tipo' => 'aluno',
            'saldo' => 0.00,
            'ativo' => true,
            'rfid_code' => 'CARD-' . uniqid(),
            'rfid_blocked' => false,
            'rfid_pin' => Hash::make('123456'),
        ], $attributes));
    }

    private function createCredit(User $user, array $attributes = []): UserCredito
    {
        return UserCredito::create(array_merge([
            'user_id' => $user->id,
            'cpf' => (string) random_int(10000000000, 99999999999),
            'ra' => 'RA' . uniqid(),
            'telefone' => '11999999999',
            'email_institucional' => 'aluno-' . uniqid() . '@unesp.br',
            'pin' => Hash::make('123456'),
            'limite' => 50.00,
            'divida_atual' => 0.00,
            'verificado' => true,
        ], $attributes));
    }

    private function createPedido(User $user, array $attributes = []): Pedido
    {
        $pedido = Pedido::create(array_merge([
            'user_id' => $user->id,
            'valor_total' => 10.00,
            'senha_diaria' => Pedido::max('senha_diaria') + 1,
            'status' => 'pendente',
            'momento_bebida' => 'agora',
            'posicao_fila' => 0,
            'codigo_retirada' => '0001',
        ], $attributes));

        PedidoProduto::create([
            'pedido_id' => $pedido->id,
            'produto_id' => Produto::create([
                'nome' => 'Produto ' . uniqid(),
                'descricao' => 'Item',
                'preco_atual' => $pedido->valor_total,
                'disponivel' => true,
                'categoria' => 'Bebidas',
                'imagem' => null,
            ])->id,
            'quantidade' => 1,
            'preco_unitario' => $pedido->valor_total,
            'observacao' => null,
            'entregue' => false,
        ]);

        return $pedido;
    }
}
