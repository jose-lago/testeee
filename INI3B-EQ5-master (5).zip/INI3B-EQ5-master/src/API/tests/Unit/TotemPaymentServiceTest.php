<?php

namespace Tests\Unit;

use App\Models\Configuracao;
use App\Models\User;
use App\Models\UserCredito;
use App\Services\TotemPaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use InvalidArgumentException;
use RuntimeException;
use Tests\TestCase;

class TotemPaymentServiceTest extends TestCase
{
	use RefreshDatabase;

	protected function setUp(): void
	{
		parent::setUp();
		Configuracao::setValor('credito_ativo', true);
	}

	public function test_approves_payment_with_balance(): void
	{
		$user = $this->createUser(['saldo' => 25.00]);

		$result = $this->service()->processarPagamento('CARD-1', '10.00', 'saldo', '123456');

		$this->assertTrue($result['approved']);
		$this->assertSame('saldo', $result['payment_method']);
		$this->assertSame('25.00', $result['balance_before']);
		$this->assertSame('15.00', $result['balance_after']);
		$this->assertSame('15.00', (string) $user->fresh()->saldo);
	}

	public function test_rejects_missing_card_pin(): void
	{
		$this->createUser(['saldo' => 25.00]);

		$this->expectException(InvalidArgumentException::class);
		$this->expectExceptionMessage('A senha do cartão RFID é obrigatória.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'saldo', null);
	}

	public function test_rejects_insufficient_balance(): void
	{
		$this->createUser(['saldo' => 5.00]);

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Saldo insuficiente.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'saldo', '123456');
	}

	public function test_rejects_unknown_rfid(): void
	{
		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Cartão RFID não encontrado.');

		$this->service()->processarPagamento('UNKNOWN', '10.00', 'saldo', '123456');
	}

	public function test_rejects_blocked_rfid(): void
	{
		$this->createUser(['rfid_blocked' => true]);

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Cartão RFID bloqueado.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'saldo', '123456');
	}

	public function test_rejects_inactive_credit(): void
	{
		$this->createUser();
		UserCredito::create([
			'user_id' => User::query()->where('rfid_code', 'CARD-1')->value('id'),
			'cpf' => '12345678901',
			'ra' => 'RA1234',
			'telefone' => '11999999999',
			'email_institucional' => 'aluno@unesp.br',
			'pin' => Hash::make('123456'),
			'limite' => 50.00,
			'divida_atual' => 0.00,
			'verificado' => false,
		]);

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Crédito não ativado para este usuário.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'credito', '123456');
	}

	public function test_rejects_incorrect_pin(): void
	{
		$this->createUser();
		$this->createCredit(['pin' => Hash::make('123456')]);

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Senha do cartão incorreta.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'credito', '000000');
	}

	public function test_rejects_insufficient_credit_limit(): void
	{
		$this->createUser();
		$this->createCredit(['limite' => 50.00, 'divida_atual' => 45.00]);

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('Limite de crédito insuficiente.');

		$this->service()->processarPagamento('CARD-1', '10.00', 'credito', '123456');
	}

	public function test_approves_payment_with_credit(): void
	{
		$this->createUser();
		$credit = $this->createCredit();

		$result = $this->service()->processarPagamento('CARD-1', '10.00', 'credito', '123456');

		$this->assertTrue($result['approved']);
		$this->assertSame('credito', $result['payment_method']);
		$this->assertSame('0.00', $result['balance_before']);
		$this->assertSame('10.00', $result['balance_after']);
		$this->assertSame('10.00', (string) $credit->fresh()->divida_atual);
	}

	public function test_rolls_back_payment_when_the_order_fails(): void
	{
		$user = $this->createUser(['saldo' => 25.00]);

		try {
			DB::transaction(function () {
				$this->service()->processarPagamento('CARD-1', '10.00', 'saldo', '123456');
				throw new RuntimeException('Falha ao criar pedido.');
			});
		} catch (RuntimeException $exception) {
			$this->assertSame('Falha ao criar pedido.', $exception->getMessage());
		}

		$this->assertSame('25.00', (string) $user->fresh()->saldo);
	}

	private function service(): TotemPaymentService
	{
		return app(TotemPaymentService::class);
	}

	private function createUser(array $attributes = []): User
	{
		return User::create(array_merge([
			'name' => 'Aluno Teste',
			'email' => 'aluno-' . uniqid() . '@example.com',
			'password' => Hash::make('password'),
			'tipo' => 'aluno',
			'saldo' => 0.00,
			'rfid_code' => 'CARD-1',
			'rfid_blocked' => false,
			'rfid_pin' => Hash::make('123456'),
		], $attributes));
	}

	private function createCredit(array $attributes = []): UserCredito
	{
		return UserCredito::create(array_merge([
			'user_id' => User::query()->where('rfid_code', 'CARD-1')->value('id'),
			'cpf' => '12345678901',
			'ra' => 'RA1234',
			'telefone' => '11999999999',
			'email_institucional' => 'aluno-' . uniqid() . '@unesp.br',
			'pin' => Hash::make('123456'),
			'limite' => 50.00,
			'divida_atual' => 0.00,
			'verificado' => true,
		], $attributes));
	}
}
