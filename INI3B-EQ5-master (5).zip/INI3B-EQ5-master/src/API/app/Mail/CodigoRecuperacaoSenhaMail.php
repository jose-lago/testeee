<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CodigoRecuperacaoSenhaMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public string $codigoOtp,
        public string $nomeAluno,
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: '[Saviore] Código para redefinir sua senha',
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.recuperacao-senha',
        );
    }

    public function attachments(): array
    {
        return [];
    }
}
