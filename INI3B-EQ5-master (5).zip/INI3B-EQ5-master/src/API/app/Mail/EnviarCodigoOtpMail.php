<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class EnviarCodigoOtpMail extends Mailable
{
    use Queueable, SerializesModels;

    public string $codigoOtp;
    public string $nomeAluno;

    /**
     * Create a new message instance.
     */
    public function __construct(string $codigoOtp, string $nomeAluno = 'Aluno(a)')
    {
        $this->codigoOtp = $codigoOtp;
        $this->nomeAluno = $nomeAluno;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: "[Saviore] Seu código de ativação do crédito: {$this->codigoOtp}",
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.otp',
            with: [
                'codigoOtp' => $this->codigoOtp,
                'nomeAluno' => $this->nomeAluno,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
