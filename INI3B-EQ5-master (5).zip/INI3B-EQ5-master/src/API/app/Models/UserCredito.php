<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCredito extends Model
{
    use HasFactory;

    protected $table = 'user_creditos';

    protected $fillable = [
        'user_id',
        'cpf',
        'ra',
        'telefone',
        'email_institucional',
        'pin',
        'limite',
        'divida_atual',
        'verificado',
    ];

    protected $hidden = [
        'pin',
    ];

    protected $casts = [
        'limite' => 'decimal:2',
        'divida_atual' => 'decimal:2',
        'verificado' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
