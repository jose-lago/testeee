<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Exception;

class Movimentacao extends Model
{
    protected $table = 'movimentacoes';

    protected $fillable = [
        'user_id',
        'pedido_id',
        'admin_id',
        'valor',
        'tipo',
        'saldo_anterior',
        'saldo_posterior',
        'descricao',
    ];

    protected $casts = [
        'valor' => 'decimal:2',
        'saldo_anterior' => 'decimal:2',
        'saldo_posterior' => 'decimal:2',
    ];

    /**
     * Validações de segurança no ciclo de vida do Model
     */
    protected static function booted()
    {
        static::saving(function ($mov) {
            $tiposValidos = ['recarga', 'pedido', 'estorno', 'ajuste', 'pedido_credito', 'pagamento_credito'];
            if (!in_array($mov->tipo, $tiposValidos)) {
                throw new Exception("Tipo de movimentação inválido.");
            }
        });
    }

    // ========================
    // Relacionamentos
    // ========================

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }
}
