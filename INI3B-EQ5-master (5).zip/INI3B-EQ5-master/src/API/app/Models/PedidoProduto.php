<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Exception;

class PedidoProduto extends Model
{
    protected $table = 'pedido_produto';

    protected $fillable = [
        'pedido_id',
        'produto_id',
        'quantidade',
        'preco_unitario',
        'observacao',
        'entregue',
    ];

    protected $casts = [
        'quantidade' => 'integer',
        'preco_unitario' => 'decimal:2',
        'entregue' => 'boolean',
    ];

    /**
     * Validações de segurança para os itens do pedido
     */
    protected static function booted()
    {
        static::saving(function ($item) {
            if ($item->quantidade <= 0) {
                throw new Exception("Falha de segurança: A quantidade do produto deve ser maior que zero.");
            }
            if ($item->preco_unitario < 0) {
                throw new Exception("Falha de segurança: O preço unitário não pode ser negativo.");
            }
        });
    }

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function produto()
    {
        return $this->belongsTo(Produto::class);
    }
}
