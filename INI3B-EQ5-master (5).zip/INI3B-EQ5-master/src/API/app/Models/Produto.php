<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{

    protected $table = 'produtos';

    protected $fillable = [
        'nome', 
        'descricao', 
        'preco_atual', 
        'disponivel',
        'categoria',
        'imagem'
    ];

      protected $casts = [
        'preco_atual' => 'decimal:2',
        'disponivel' => 'boolean',
    ];

    protected $appends = [
        'imagem_url',
    ];

    /**
     * Retorna a URL pública completa da imagem do produto.
     */
    public function getImagemUrlAttribute(): ?string
    {
        if (!$this->imagem) {
            return null;
        }

        return request()->getSchemeAndHttpHost() . '/storage/' . ltrim($this->imagem, '/');
    }
}
