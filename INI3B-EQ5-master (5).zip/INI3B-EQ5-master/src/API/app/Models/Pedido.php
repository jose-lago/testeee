<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Exception;

class Pedido extends Model
{
    protected $fillable = [
        'user_id',
        'preparador_id',
        'valor_total',
        'forma_pagamento',
        'senha_diaria',
        'status',
        'momento_bebida',
        'posicao_fila',
        'codigo_retirada',
    ];

    // Forçando conversão de tipos para evitar vulnerabilidades matemáticas e de tipo
    protected $casts = [
        'valor_total' => 'decimal:2',
        'senha_diaria' => 'integer',
        'posicao_fila' => 'integer',
    ];

    /**
     * O método booted é chamado automaticamente pelo Laravel em eventos de ciclo de vida.
     * Ideal para validações de regra de negócio blindadas (segurança máxima).
     */
    protected static function booted()
    {
        static::saving(function ($pedido) {
            // Verificação de Segurança 1: Impede que o sistema salve um valor_total negativo
            if ($pedido->valor_total < 0) {
                throw new Exception("O valor total do pedido não pode ser negativo.");
            }

            // Verificação de Segurança 2: Se um preparador for assinado, ele OBRIGATORIAMENTE deve ser um funcionário ou admin
            if ($pedido->isDirty('preparador_id') && $pedido->preparador_id !== null) {
                $preparador = User::find($pedido->preparador_id);
                
                // Se o usuário não existir, ou se o 'tipo' for 'aluno' ou diferente dos permitidos
                if (!$preparador || !in_array($preparador->tipo, ['funcionario', 'admin'])) {
                    throw new Exception("Ação Bloqueada: Apenas usuários do tipo 'funcionario' ou 'admin' podem preparar pedidos.");
                }
            }
            
            // Verificação de Segurança 3: Impede status inválidos no banco caso fuja da validação do Controller
            $statusValidos = ['pendente', 'preparando', 'pronto', 'entregue', 'cancelado'];
            if (!in_array($pedido->status, $statusValidos)) {
                throw new Exception("Status de pedido inválido.");
            }
        });
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function preparador()
    {
        return $this->belongsTo(User::class, 'preparador_id');
    }

    public function itens()
    {
        return $this->hasMany(PedidoProduto::class);
    }
}
