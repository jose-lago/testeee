<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

#[Fillable(['name', 'email', 'password', 'tipo', 'saldo', 'ativo', 'push_token', 'rfid_code', 'rfid_blocked', 'rfid_pin'])]
#[Hidden(['password', 'remember_token', 'rfid_pin'])]
class User extends Authenticatable
{
    /* Quando você usar factory nesse Model,
    o Laravel vai usar a UserFactory para gerar dados fake. */
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'users';

    protected $fillable = [
        'name',
        'email',
        'password', 
        'tipo',
        'saldo',
        'ativo',
        'push_token',
        'rfid_code',
        'rfid_blocked',
        'rfid_pin',
        // 'saldo' removido do fillable por segurança — usar increment/decrement + Movimentacao
    ];

    /*
     * O método retorna um array de casts
     */
    protected $hidden = [
        'password',
        'remember_token',
        'rfid_pin',
    ];
    
    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'rfid_pin' => 'hashed',
            'saldo' => 'decimal:2',
            'ativo' => 'boolean',
            'rfid_blocked' => 'boolean',
        ];
    }

    // ========================
    // Relacionamentos
    // ========================

    public function movimentacoes()
    {
        return $this->hasMany(\App\Models\Movimentacao::class);
    }

    public function credito()
    {
        return $this->hasOne(\App\Models\UserCredito::class);
    }
}
