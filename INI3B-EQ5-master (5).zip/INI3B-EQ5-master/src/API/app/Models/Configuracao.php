<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Configuracao extends Model
{
    use HasFactory;

    protected $table = 'configuracoes';

    protected $fillable = [
        'chave',
        'valor',
        'descricao',
    ];

    /**
     * Retorna o valor de uma configuração com fallback.
     */
    public static function getValor(string $chave, mixed $default = null): mixed
    {
        $config = static::where('chave', $chave)->first();
        if (!$config) {
            return $default;
        }

        $valor = $config->valor;

        if ($valor === 'true') return true;
        if ($valor === 'false') return false;

        return $valor;
    }

    /**
     * Define ou atualiza uma configuração.
     */
    public static function setValor(string $chave, mixed $valor, ?string $descricao = null): static
    {
        $stringValor = is_bool($valor) ? ($valor ? 'true' : 'false') : (string) $valor;

        return static::updateOrCreate(
            ['chave' => $chave],
            [
                'valor' => $stringValor,
                'descricao' => $descricao ?? 'Configuração do sistema',
            ]
        );
    }

    /**
     * Verifica se o crédito/fiado está ativo no sistema.
     */
    public static function isCreditoAtivo(): bool
    {
        return (bool) static::getValor('credito_ativo', true);
    }
}
