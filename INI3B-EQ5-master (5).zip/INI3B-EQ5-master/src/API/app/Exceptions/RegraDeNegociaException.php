<?php

namespace App\Exceptions;

use Exception;

/**
 * Indica que uma regra de negócio de estorno/cancelamento não foi satisfeita
 * (ex.: usuário sem registro de crédito para o estorno).
 * Traduzida em HTTP 400 pelo PedidoController@cancelar.
 */
class RegraDeNegociaException extends Exception {}
