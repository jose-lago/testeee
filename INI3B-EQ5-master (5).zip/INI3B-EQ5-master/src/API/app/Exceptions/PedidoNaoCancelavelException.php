<?php

namespace App\Exceptions;

use Exception;

/**
 * Indica que um pedido não pode ser cancelado no estado atual.
 * Traduzida pelo PedidoController@cancelar para 403 (não cancelável)
 * ou 409 (já cancelado).
 */
class PedidoNaoCancelavelException extends Exception
{
    public function __construct(
        string $message,
        private readonly int $statusCode = 403
    ) {
        parent::__construct($message);
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }
}
