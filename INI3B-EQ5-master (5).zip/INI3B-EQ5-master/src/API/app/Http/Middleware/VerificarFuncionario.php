<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class VerificarFuncionario
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check() && in_array(Auth::user()->tipo, ['funcionario', 'admin'])) {
            return $next($request);
        }

        return response()->json([
            'sucesso' => false,
            'mensagem' => 'Acesso restrito a funcionários da cantina.'
        ], 403);
    }
}
