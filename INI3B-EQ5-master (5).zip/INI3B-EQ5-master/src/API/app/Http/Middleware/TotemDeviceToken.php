<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TotemDeviceToken
{
    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->header('X-Totem-Token')
            ?? $request->header('x-totem-token');

        $expected = env('TICKET_TOTEM_TOKEN', 'totem-dev-token');

        if (!$token || !hash_equals((string) $expected, (string) $token)) {
            return response()->json([
                'message' => 'Dispositivo não autorizado.'
            ], 401);
        }

        return $next($request);
    }
}
