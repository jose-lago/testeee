<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use Symfony\Component\HttpFoundation\Response;

class VerificarAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check() && Auth::user()->tipo === 'admin') {
            
            // É administrador! Pode passar.
            return $next($request);
        }

        return response()->json([
            'sucesso' => false,
            'mensagem' => 'Acesso negado. Área restrita aos administradores da cantina.'
        ], 403);
    }
}