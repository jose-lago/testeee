<?php

namespace App\Http\Controllers;

use App\Models\Configuracao;
use App\Models\UserCredito;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ConfiguracaoController extends Controller
{
    /**
     * GET /api/configuracoes/credito
     * 
     * Retorna o status da funcionalidade de crédito e métricas gerais (para o admin).
     */
    public function getCreditoStatus(Request $request): JsonResponse
    {
        $ativo = Configuracao::isCreditoAtivo();
        $totalAlunos = UserCredito::count();
        $totalDivida = (float) UserCredito::sum('divida_atual');

        return response()->json([
            'success' => true,
            'credito_ativo' => $ativo,
            'metricas' => [
                'total_alunos_com_credito' => $totalAlunos,
                'total_divida_acumulada' => $totalDivida,
                'limite_padrao' => 50.00,
            ],
        ], 200);
    }

    /**
     * POST /api/configuracoes/credito (Admin-only)
     * 
     * Habilita ou desabilita a funcionalidade de crédito/fiado.
     */
    public function setCreditoStatus(Request $request): JsonResponse
    {
        $request->validate([
            'ativo' => 'required|boolean',
        ]);

        $ativo = (bool) $request->ativo;

        Configuracao::setValor(
            'credito_ativo',
            $ativo,
            'Ativa ou desativa a funcionalidade de Crédito / Fiado para os alunos'
        );

        return response()->json([
            'success' => true,
            'credito_ativo' => $ativo,
            'mensagem' => $ativo
                ? 'Funcionalidade de Crédito / Fiado ATIVADA com sucesso!'
                : 'Funcionalidade de Crédito / Fiado DESATIVADA com sucesso!',
        ], 200);
    }
}
