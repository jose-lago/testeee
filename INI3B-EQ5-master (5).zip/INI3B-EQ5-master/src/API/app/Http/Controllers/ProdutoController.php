<?php

namespace App\Http\Controllers;

use App\Models\Produto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Exception;

class ProdutoController extends Controller
{
    /**
     * Monta a URL completa da imagem do produto.
     */
    private function montarUrlImagem(?string $caminho): ?string
    {
        if (!$caminho) {
            return null;
        }

        return request()->getSchemeAndHttpHost() . '/storage/' . ltrim($caminho, '/');
    }

    private function armazenarImagem(\Illuminate\Http\UploadedFile $imagem): string
    {
        $caminho = $imagem->store('produtos', 'public');

        if (!$caminho || !Storage::disk('public')->exists($caminho)) {
            throw new \RuntimeException('A imagem do produto não foi salva no disco público.');
        }

        return $caminho;
    }

    /**
     * Adiciona imagem_url ao produto antes de retornar no JSON.
     */
    private function comImagemUrl($produto)
    {
        $produto->imagem_url = $this->montarUrlImagem($produto->imagem);
        return $produto;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $query = Produto::query();

            if ($request->filled('nome')) {
                $nome = $request->input('nome');
                $query->where('nome', 'ilike', "%{$nome}%");
            }

            if ($request->has('disponivel')) {
                $query->where('disponivel', $request->boolean('disponivel'));
            }

            if ($request->filled('categoria')) {
                $query->where('categoria', $request->input('categoria'));
            }

            $colunasPermitidas = ['id', 'nome', 'preco_atual', 'disponivel', 'categoria', 'created_at', 'updated_at'];
            $direcoesPermitidas = ['asc', 'desc'];

            $coluna = $request->input('_sort', 'nome');
            $direcao = strtolower($request->input('_order', 'asc'));

            if (!in_array($coluna, $colunasPermitidas)) {
                $coluna = 'nome';
            }

            if (!in_array($direcao, $direcoesPermitidas)) {
                $direcao = 'asc';
            }

            $query->orderBy($coluna, $direcao);

            $produtos = $query->get()->map(function ($p) {
                $p->imagem_url = $this->montarUrlImagem($p->imagem);
                return $p;
            });

            // Refine espera um Array limpo na listagem
            return response()->json($produtos, 200);

        } catch (Exception $e) {
            Log::error('Erro no ProdutoController@index: ' . $e->getMessage());
            return response()->json(['message' => 'Erro interno ao buscar produtos'], 500);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'nome'        => 'required|string|max:255',
                'descricao'   => 'nullable|string',
                'preco_atual' => 'required|numeric|min:0',
                'disponivel'  => 'boolean',
                'categoria'   => 'required|string|max:20',
                'imagem'      => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            ]);

            // Se veio arquivo de imagem, salva no disco público
            if ($request->hasFile('imagem')) {
                $validated['imagem'] = $this->armazenarImagem($request->file('imagem'));
            } else {
                unset($validated['imagem']);
            }

            $produto = Produto::create($validated);

            // Refine espera o Objeto criado de volta
            return response()->json($this->comImagemUrl($produto), 201); 

        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $e) {
            // Ocultando o erro real do usuário e salvando nos logs do Laravel
            Log::error('Erro no ProdutoController@store: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao salvar o produto.'], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $produto = Produto::find($id);

        if (!$produto) {
            return response()->json(['message' => 'Produto não encontrado.'], 404);
        }

        // Refine espera o Objeto limpo
        return response()->json($this->comImagemUrl($produto), 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $produto = Produto::find($id);

            if (!$produto) {
                return response()->json(['message' => 'Produto inexistente.'], 404);
            }

            $validados = $request->validate([
                'nome'        => 'sometimes|string|max:255',
                'descricao'   => 'nullable|string',
                'preco_atual' => 'sometimes|numeric|min:0',
                'disponivel'  => 'sometimes|boolean',
                'categoria'   => 'sometimes|string|max:20',
                'imagem'      => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            ]);

            // Se veio novo arquivo de imagem, substitui o anterior
            if ($request->hasFile('imagem')) {
                $imagemAnterior = $produto->imagem;
                $validados['imagem'] = $this->armazenarImagem($request->file('imagem'));
            } else {
                unset($validados['imagem']);
            }

            $produto->update($validados);

            if (isset($imagemAnterior) && $imagemAnterior && $imagemAnterior !== $produto->imagem) {
                Storage::disk('public')->delete($imagemAnterior);
            }

            // Refine espera o Objeto atualizado de volta
            return response()->json($this->comImagemUrl($produto), 200);

        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $e) {
            Log::error('Erro no ProdutoController@update: ' . $e->getMessage());
            return response()->json(['message' => 'Erro na atualização.'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $produto = Produto::find($id);

            if (!$produto) {
                return response()->json(['message' => 'Produto não encontrado.'], 404);
            }

            // Remove a imagem do disco se existir
            if ($produto->imagem) {
                Storage::disk('public')->delete($produto->imagem);
            }

            $produto->delete();

            // Refine aceita uma resposta vazia para deleção com sucesso ou dados irrelevantes
            return response()->json(['message' => 'Produto removido com sucesso.'], 200);

        } catch (Exception $e) {
            Log::error('Erro no ProdutoController@destroy: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao tentar excluir o produto.'], 500);
        }
    }
}