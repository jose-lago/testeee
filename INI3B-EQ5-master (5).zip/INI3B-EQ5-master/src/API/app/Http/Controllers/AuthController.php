<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Exception;
use App\Mail\CodigoRecuperacaoSenhaMail;

class AuthController extends Controller
{
    private const PASSWORD_RESET_OTP_TTL_MINUTES = 15;

    // REGISTRAR
    public function registrar(Request $request)
    {
        $dados = $request->validate([
            'nome' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'push_token' => 'nullable|string|max:255',
        ]);

        $pushToken = $dados['push_token'] ?? null;
        if ($pushToken) {
            User::where('push_token', $pushToken)->update(['push_token' => null]);
        }

        $user = User::create([
            'name' => $dados['nome'],
            'email' => $dados['email'],
            'password' => $dados['password'], 
            'tipo' => 'aluno',
            'saldo' => 0,
            'push_token' => $pushToken,
        ]);

        $token = $user->createToken('Mobile')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'name'  => $user->name,
                'email' => $user->email,
                'saldo' => $user->saldo,
                'tipo'  => $user->tipo,
            ]
        ], 201); 
    }

    // LOGIN
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
            'push_token' => 'nullable|string|max:255',
        ]);

        $emailInformado = strtolower(trim($request->input('email')));
        $emailCadastrado = User::whereRaw('LOWER(email) = ?', [$emailInformado])->value('email');

        if (!$emailCadastrado || !Auth::attempt([
            'email' => $emailCadastrado,
            'password' => $request->input('password'),
        ])) {
            return response()->json(['message' => 'Credenciais incorretas.'], 401);
        }

        /** @var \App\Models\User $user */
        $user = Auth::user();

        if ($request->filled('push_token')) {
            $novoToken = $request->push_token;
            User::where('push_token', $novoToken)
                ->where('id', '!=', $user->id)
                ->update(['push_token' => null]);
            $user->update(['push_token' => $novoToken]);
        }

        $token = $user->createToken('Mobile')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'name' => $user->name,
                'email' => $user->email,
                'saldo' => $user->saldo,
                'tipo' => $user->tipo 
            ]
        ], 200);
    }

    public function solicitarRecuperacaoSenha(Request $request)
    {
        $dados = $request->validate([
            'email' => 'required|email|max:255',
        ]);

        $email = strtolower(trim($dados['email']));
        $user = User::whereRaw('LOWER(email) = ?', [$email])->first();

        if ($user) {
            $codigoOtp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $cacheKey = $this->chaveRecuperacaoSenha($email);

            Cache::put($cacheKey, [
                'user_id' => $user->id,
                'codigo_hash' => Hash::make($codigoOtp),
            ], now()->addMinutes(self::PASSWORD_RESET_OTP_TTL_MINUTES));

            try {
                Mail::to($user->email)->send(new CodigoRecuperacaoSenhaMail($codigoOtp, $user->name));
            } catch (Exception $e) {
                Cache::forget($cacheKey);
                Log::error('Falha ao enviar código de recuperação de senha.', [
                    'user_id' => $user->id,
                    'exception' => $e->getMessage(),
                ]);

                return response()->json([
                    'message' => 'Não foi possível enviar o código agora. Tente novamente mais tarde.',
                ], 503);
            }
        }

        return response()->json([
            'message' => 'Se houver uma conta associada a esse e-mail, enviaremos um código de recuperação.',
            'expira_em_minutos' => self::PASSWORD_RESET_OTP_TTL_MINUTES,
        ], 200);
    }

    public function redefinirSenha(Request $request)
    {
        $dados = $request->validate([
            'email' => 'required|email|max:255',
            'codigo' => 'required|digits:6',
            'password' => 'required|string|size:6|confirmed',
        ], [
            'password.size' => 'A nova senha deve ter exatamente 6 caracteres.',
            'password.confirmed' => 'A confirmação da senha não corresponde.',
        ]);

        $email = strtolower(trim($dados['email']));
        $cacheKey = $this->chaveRecuperacaoSenha($email);

        $redefinido = DB::transaction(function () use ($email, $cacheKey, $dados) {
            $codigoCache = Cache::get($cacheKey);
            if (!$codigoCache || !Hash::check($dados['codigo'], $codigoCache['codigo_hash'] ?? '')) {
                return false;
            }

            $user = User::whereKey($codigoCache['user_id'] ?? null)
                ->lockForUpdate()
                ->first();

            if (!$user || strtolower($user->email) !== $email) {
                return false;
            }

            // Re-read after acquiring the user lock so concurrent requests cannot reuse one code.
            $codigoCache = Cache::get($cacheKey);
            if (!$codigoCache || (int) ($codigoCache['user_id'] ?? 0) !== (int) $user->id
                || !Hash::check($dados['codigo'], $codigoCache['codigo_hash'] ?? '')) {
                return false;
            }

            $user->password = $dados['password'];
            $user->save();
            $user->tokens()->delete();
            Cache::forget($cacheKey);

            return true;
        });

        if (!$redefinido) {
            return response()->json([
                'message' => 'Código inválido ou expirado. Solicite um novo código.',
            ], 422);
        }

        return response()->json([
            'message' => 'Senha redefinida com sucesso. Entre com sua nova senha.',
        ], 200);
    }

    private function chaveRecuperacaoSenha(string $email): string
    {
        return 'otp_recuperacao_senha_' . hash('sha256', $email);
    }

    // LOGOUT (Adicionado)
    public function logout(Request $request)
    {
        try {
            // Deleta o token que foi usado para autenticar a requisição atual
            $request->user()->currentAccessToken()->delete();

            return response()->json([
                'status' => true,
                'message' => 'Token revogado e logout realizado com sucesso.'
            ], 200);
            
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Erro ao realizar logout.'
            ], 500);
        }
    }
}