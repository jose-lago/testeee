<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\EnviarCodigoOtpMail;
use App\Models\Configuracao;
use App\Models\Movimentacao;
use App\Models\User;
use App\Models\UserCredito;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class CreditoController extends Controller
{
    /**
     * Validação matemática oficial de CPF brasileiro (Módulo 11).
     */
    public static function validarCpf(string $cpf): bool
    {
        $cpf = preg_replace('/\D/', '', $cpf);

        if (strlen($cpf) !== 11) {
            return false;
        }

        // Rejeita padrões com 11 dígitos idênticos (ex: 00000000000, 11111111111...)
        if (preg_match('/^(\d)\1{10}$/', $cpf)) {
            return false;
        }

        // Cálculo do primeiro dígito verificador
        $soma = 0;
        for ($i = 0; $i < 9; $i++) {
            $soma += (int) $cpf[$i] * (10 - $i);
        }
        $resto = ($soma * 10) % 11;
        if ($resto === 10 || $resto === 11) {
            $resto = 0;
        }
        if ($resto !== (int) $cpf[9]) {
            return false;
        }

        // Cálculo do segundo dígito verificador
        $soma = 0;
        for ($i = 0; $i < 10; $i++) {
            $soma += (int) $cpf[$i] * (11 - $i);
        }
        $resto = ($soma * 10) % 11;
        if ($resto === 10 || $resto === 11) {
            $resto = 0;
        }
        if ($resto !== (int) $cpf[10]) {
            return false;
        }

        return true;
    }

    /**
     * Validação estrita do RA: deve conter exatamente 7 dígitos numéricos.
     */
    public static function validarRa(string $ra): bool
    {
        return (bool) preg_match('/^\d{7}$/', trim($ra));
    }

    /**
     * POST /api/credito/solicitar
     * 
     * Valida o e-mail institucional @unesp.br e dados prévios (CPF, RA, Telefone),
     * verifica duplicidades e funcionalidade ativa, gera OTP de 6 dígitos e envia por e-mail.
     */
    public function solicitar(Request $request): JsonResponse
    {
        $user = $request->user();

        // 1. Verifica se a funcionalidade está ativada pela administração
        if (!Configuracao::isCreditoAtivo()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'A funcionalidade de crédito / fiado está temporariamente desativada pela administração da cantina.',
            ], 403);
        }

        // 2. Bloqueia se o usuário já possui crédito ativo
        if ($user->credito()->exists() && $user->credito->verificado) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Você já possui o serviço de crédito / fiado ativado nesta conta.',
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'email_institucional' => [
                'required',
                'email',
                'regex:/^[a-zA-Z0-9._%+-]+@unesp\.br$/i',
            ],
            'cpf' => 'nullable|string',
            'ra' => 'nullable|string',
            'telefone' => 'nullable|string',
        ], [
            'email_institucional.required' => 'O e-mail institucional é obrigatório.',
            'email_institucional.email' => 'Informe um endereço de e-mail válido.',
            'email_institucional.regex' => 'O e-mail informado deve pertencer ao domínio @unesp.br.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'mensagem' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $email = strtolower(trim($request->email_institucional));

        // 3. Validação prévia de duplicidade do e-mail
        $emailExistente = UserCredito::where('email_institucional', $email)
            ->where('user_id', '!=', $user->id)
            ->exists();
        if ($emailExistente) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Este e-mail institucional já foi utilizado para ativar o crédito em outra conta.',
            ], 422);
        }

        // 4. Se o CPF foi enviado na etapa 1, valida algoritmo oficial e duplicidade
        if ($request->filled('cpf')) {
            $cpfLimpo = preg_replace('/\D/', '', $request->cpf);
            if (!self::validarCpf($cpfLimpo)) {
                return response()->json([
                    'success' => false,
                    'mensagem' => 'O CPF informado é inválido de acordo com as regras oficiais brasileiras.',
                ], 422);
            }

            $cpfExistente = UserCredito::where('cpf', $cpfLimpo)
                ->where('user_id', '!=', $user->id)
                ->exists();
            if ($cpfExistente) {
                return response()->json([
                    'success' => false,
                    'mensagem' => 'Este CPF já está cadastrado em outra conta de crédito.',
                ], 422);
            }
        }

        // 5. Se o RA foi enviado, valida formato de 7 dígitos e duplicidade
        if ($request->filled('ra')) {
            $raLimpo = trim($request->ra);
            if (!self::validarRa($raLimpo)) {
                return response()->json([
                    'success' => false,
                    'mensagem' => 'O RA deve conter exatamente 7 dígitos numéricos.',
                ], 422);
            }

            $raExistente = UserCredito::where('ra', $raLimpo)
                ->where('user_id', '!=', $user->id)
                ->exists();
            if ($raExistente) {
                return response()->json([
                    'success' => false,
                    'mensagem' => 'Este RA já está cadastrado no sistema.',
                ], 422);
            }
        }

        // 6. Se o telefone foi enviado, valida duplicidade
        if ($request->filled('telefone')) {
            $telLimpo = preg_replace('/\D/', '', $request->telefone);
            if (strlen($telLimpo) >= 8) {
                $telExistente = UserCredito::where('telefone', $telLimpo)
                    ->where('user_id', '!=', $user->id)
                    ->exists();
                if ($telExistente) {
                    return response()->json([
                        'success' => false,
                        'mensagem' => 'Este número de telefone já está cadastrado no sistema.',
                    ], 422);
                }
            }
        }

        // Gera código OTP de 6 dígitos numéricos
        $codigoOtp = str_pad((string) random_int(100000, 999999), 6, '0', STR_PAD_LEFT);

        // Armazena no cache por 15 minutos associado ao usuário
        $cacheKey = "otp_credito_{$user->id}";
        Cache::put($cacheKey, [
            'otp' => $codigoOtp,
            'email' => $email,
            'criado_em' => now()->toIso8601String(),
        ], now()->addMinutes(15));

        Log::info("OTP Credito gerado para usuario #{$user->id} ({$email}): {$codigoOtp}");

        // Dispara e-mail transacional via Brevo com remetente seguro
        try {
            Mail::to($email)->send(new EnviarCodigoOtpMail($codigoOtp, $user->name));
        } catch (Exception $e) {
            Log::error("Erro no envio do e-mail OTP para {$email}: " . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensagem' => 'Erro ao enviar o e-mail com o código de verificação: ' . $e->getMessage(),
            ], 500);
        }

        $response = [
            'success' => true,
            'mensagem' => 'Código de verificação enviado com sucesso para seu e-mail institucional!',
            'email_institucional' => $email,
            'expira_em_minutos' => 15,
        ];

        // Em ambiente de teste/debug, disponibiliza código auxiliar para auditoria
        if (config('app.debug')) {
            $response['otp_debug'] = $codigoOtp;
        }

        return response()->json($response, 200);
    }

    /**
     * POST /api/credito/verificar
     * 
     * Valida o OTP recebido, dados cadastrais (CPF módulo 11, RA 7 dígitos, duplicidades)
     * e grava o hash do PIN de 6 dígitos.
     */
    public function verificar(Request $request): JsonResponse
    {
        $user = $request->user();

        // 1. Verifica se a funcionalidade está ativa
        if (!Configuracao::isCreditoAtivo()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'A funcionalidade de crédito / fiado está temporariamente desativada pela cantina.',
            ], 403);
        }

        // 2. Bloqueia se o usuário já possui crédito ativo
        if ($user->credito()->exists() && $user->credito->verificado) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Você já possui crédito / fiado ativado nesta conta.',
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'cpf' => 'required|string',
            'ra' => 'required|string',
            'telefone' => 'required|string|min:8|max:20',
            'email_institucional' => [
                'required',
                'email',
                'regex:/^[a-zA-Z0-9._%+-]+@unesp\.br$/i',
            ],
            'otp' => 'required|string|size:6',
            'pin' => 'required|digits:6',
        ], [
            'cpf.required' => 'O CPF é obrigatório.',
            'ra.required' => 'O RA é obrigatório.',
            'telefone.required' => 'O telefone de contato é obrigatório.',
            'email_institucional.required' => 'O e-mail institucional é obrigatório.',
            'email_institucional.regex' => 'O e-mail deve pertencer ao domínio @unesp.br.',
            'otp.required' => 'O código de verificação OTP é obrigatório.',
            'otp.size' => 'O código de verificação deve ter exatamente 6 dígitos.',
            'pin.required' => 'O PIN de segurança é obrigatório.',
            'pin.digits' => 'O PIN de segurança deve ter exatamente 6 dígitos numéricos.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'mensagem' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $cpfLimpo = preg_replace('/\D/', '', $request->cpf);
        $raLimpo = trim($request->ra);
        $telefoneLimpo = preg_replace('/\D/', '', $request->telefone);
        $email = strtolower(trim($request->email_institucional));

        // 3. Validação estrita do CPF (Módulo 11 da Receita Federal)
        if (!self::validarCpf($cpfLimpo)) {
            return response()->json([
                'success' => false,
                'mensagem' => 'CPF inválido de acordo com as regras oficiais brasileiras.',
            ], 422);
        }

        // 4. Validação estrita do RA (Exatamente 7 dígitos)
        if (!self::validarRa($raLimpo)) {
            return response()->json([
                'success' => false,
                'mensagem' => 'O RA deve conter exatamente 7 dígitos numéricos.',
            ], 422);
        }

        // 5. Bloqueio definitivo de duplicidade de CPF
        if (UserCredito::where('cpf', $cpfLimpo)->where('user_id', '!=', $user->id)->exists()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Este CPF já está cadastrado em outra conta de crédito.',
            ], 422);
        }

        // 6. Bloqueio definitivo de duplicidade de RA
        if (UserCredito::where('ra', $raLimpo)->where('user_id', '!=', $user->id)->exists()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Este RA já está cadastrado no sistema.',
            ], 422);
        }

        // 7. Bloqueio definitivo de duplicidade de Telefone
        if (UserCredito::where('telefone', $telefoneLimpo)->where('user_id', '!=', $user->id)->exists()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Este número de telefone já está cadastrado no sistema.',
            ], 422);
        }

        // 8. Bloqueio definitivo de duplicidade de E-mail
        if (UserCredito::where('email_institucional', $email)->where('user_id', '!=', $user->id)->exists()) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Este e-mail institucional já foi utilizado para ativação de crédito.',
            ], 422);
        }

        // 9. Validação do código OTP do cache
        $cacheKey = "otp_credito_{$user->id}";
        $dadosCache = Cache::get($cacheKey);

        if (!$dadosCache) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Nenhum código OTP pendente ou o código expirou. Solicite um novo código.',
            ], 422);
        }

        if ($dadosCache['otp'] !== trim($request->otp) || strtolower($dadosCache['email']) !== $email) {
            return response()->json([
                'success' => false,
                'mensagem' => 'Código de verificação incorreto ou e-mail divergente.',
            ], 422);
        }

        // Hash seguro do PIN de 6 dígitos
        $hashedPin = Hash::make($request->pin);

        // Grava a conta de crédito
        $credito = UserCredito::updateOrCreate(
            ['user_id' => $user->id],
            [
                'cpf' => $cpfLimpo,
                'ra' => $raLimpo,
                'telefone' => $telefoneLimpo,
                'email_institucional' => $email,
                'pin' => $hashedPin,
                'limite' => 50.00,
                'verificado' => true,
            ]
        );

        // Remove o OTP do cache após uso com sucesso
        Cache::forget($cacheKey);

        return response()->json([
            'success' => true,
            'mensagem' => 'Crédito / Fiado ativado com sucesso! Seu limite de R$ 50,00 está disponível.',
            'dados' => [
                'user_id' => $user->id,
                'email_institucional' => $credito->email_institucional,
                'ra' => $credito->ra,
                'limite' => (float) $credito->limite,
                'divida_atual' => (float) ($credito->divida_atual ?? 0.00),
                'verificado' => (bool) $credito->verificado,
            ],
        ], 200);
    }

    /**
     * GET /api/credito/devedores (Admin-only)
     * 
     * Retorna a lista de alunos com saldo devedor pendente.
     */
    public function devedores(Request $request): JsonResponse
    {
        $devedores = UserCredito::with(['user:id,name,email'])
            ->where('divida_atual', '>', 0)
            ->orderByDesc('divida_atual')
            ->get()
            ->map(function ($credito) {
                return [
                    'id' => $credito->id,
                    'user_id' => $credito->user_id,
                    'nome' => $credito->user ? $credito->user->name : 'Aluno não encontrado',
                    'ra' => $credito->ra,
                    'cpf' => $credito->cpf,
                    'telefone' => $credito->telefone,
                    'email_institucional' => $credito->email_institucional,
                    'divida_atual' => (float) $credito->divida_atual,
                    'limite' => (float) $credito->limite,
                    'atualizado_em' => $credito->updated_at ? $credito->updated_at->toIso8601String() : null,
                ];
            });

        $totalDividas = $devedores->sum('divida_atual');

        return response()->json([
            'success' => true,
            'total_devedores' => $devedores->count(),
            'valor_total_pendente' => (float) $totalDividas,
            'data' => $devedores,
        ], 200);
    }

    /**
     * POST /api/credito/pagar-divida (Admin-only)
     * 
     * Registra o pagamento total ou parcial da dívida em crédito no balcão.
     */
    public function pagarDivida(Request $request): JsonResponse
    {
        $admin = $request->user();

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'valor' => 'required|numeric|min:0.01',
        ], [
            'user_id.required' => 'O usuário deve ser informado.',
            'user_id.exists' => 'Usuário informado não foi encontrado.',
            'valor.required' => 'O valor do pagamento é obrigatório.',
            'valor.numeric' => 'O valor deve ser numérico.',
            'valor.min' => 'O valor mínimo para quitação é R$ 0,01.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'mensagem' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $valorPago = (float) $request->valor;

        return DB::transaction(function () use ($request, $admin, $valorPago) {
            $credito = UserCredito::where('user_id', $request->user_id)
                ->lockForUpdate()
                ->first();

            if (!$credito || (float) $credito->divida_atual <= 0) {
                return response()->json([
                    'success' => false,
                    'mensagem' => 'Este usuário não possui dívida pendente de crédito.',
                ], 400);
            }

            $dividaAnterior = (float) $credito->divida_atual;

            if ($valorPago > $dividaAnterior) {
                return response()->json([
                    'success' => false,
                    'mensagem' => "O valor pago (R$ " . number_format($valorPago, 2, ',', '.') . ") é superior à dívida atual (R$ " . number_format($dividaAnterior, 2, ',', '.') . ").",
                ], 400);
            }

            $novaDivida = max(0, round($dividaAnterior - $valorPago, 2));
            $credito->divida_atual = $novaDivida;
            $credito->save();

            // Grava registro na tabela de movimentações para auditoria e prestação de contas
            Movimentacao::create([
                'user_id' => $credito->user_id,
                'admin_id' => $admin->id,
                'valor' => $valorPago,
                'tipo' => 'pagamento_credito',
                'saldo_anterior' => $dividaAnterior,
                'saldo_posterior' => $novaDivida,
                'descricao' => "Pagamento de fiado no balcão recebido por: {$admin->name}",
            ]);

            return response()->json([
                'success' => true,
                'mensagem' => 'Pagamento de fiado registrado com sucesso!',
                'dados' => [
                    'user_id' => $credito->user_id,
                    'valor_pago' => $valorPago,
                    'divida_anterior' => $dividaAnterior,
                    'divida_restante' => $novaDivida,
                    'quitado' => $novaDivida == 0,
                ],
            ], 200);
        });
    }

    /**
     * GET /api/credito/status
     */
    public function status(Request $request): JsonResponse
    {
        $creditoHabilitadoSistema = Configuracao::isCreditoAtivo();
        $credito = $request->user()->credito;

        if (!$credito || !$credito->verificado) {
            return response()->json([
                'ativo' => false,
                'credito_habilitado_sistema' => $creditoHabilitadoSistema,
                'mensagem' => 'Crédito não ativado.',
            ]);
        }

        return response()->json([
            'ativo' => true,
            'credito_habilitado_sistema' => $creditoHabilitadoSistema,
            'verificado' => (bool) $credito->verificado,
            'limite' => (float) $credito->limite,
            'divida_atual' => (float) $credito->divida_atual,
            'limite_restante' => (float) ($credito->limite - $credito->divida_atual),
        ]);
    }
}
