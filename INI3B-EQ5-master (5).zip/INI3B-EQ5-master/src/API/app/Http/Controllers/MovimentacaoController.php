<?php

namespace App\Http\Controllers;

use App\Models\Movimentacao;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Exception;

class MovimentacaoController extends Controller
{
    // ========================
    // ALUNO — Minhas movimentações (React Native)
    // ========================

    /**
     * Lista as movimentações do usuário autenticado
     */
    public function minhas(Request $request)
    {
        try {
            $movimentacoes = Movimentacao::where('user_id', $request->user()->id)
                ->with(['pedido:id,senha_diaria,status', 'admin:id,name'])
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'saldo_atual'    => $request->user()->saldo,
                'movimentacoes'  => $movimentacoes,
            ], 200);

        } catch (Exception $e) {
            Log::error('MovimentacaoController@minhas: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao buscar movimentações.'], 500);
        }
    }

    // ========================
    // ADMIN — Recarregar saldo de um aluno
    // ========================

    /**
     * Adiciona saldo a um usuário com registro de movimentação
     */
    public function recarregar(Request $request, string $id)
    {
        try {
            $request->validate([
                'valor' => 'required|numeric|min:0.01|max:9999.99',
                'descricao' => 'nullable|string|max:255',
            ]);

            $usuario = User::find($id);

            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado.'], 404);
            }

            $valor = round((float) $request->input('valor'), 2);
            $descricao = $request->input('descricao', 'Recarga de saldo via admin');
            $admin = $request->user();

            $movimentacao = DB::transaction(function () use ($usuario, $valor, $descricao, $admin) {
                $saldoAnterior = $usuario->saldo;

                // Incrementar saldo
                $usuario->increment('saldo', $valor);

                $saldoPosterior = $saldoAnterior + $valor;

                // Registrar movimentação
                $movimentacao = Movimentacao::create([
                    'user_id'         => $usuario->id,
                    'pedido_id'       => null,
                    'admin_id'        => $admin->id,
                    'valor'           => $valor,
                    'tipo'            => 'recarga',
                    'saldo_anterior'  => $saldoAnterior,
                    'saldo_posterior' => $saldoPosterior,
                    'descricao'       => $descricao,
                ]);

                return $movimentacao;
            });

            return response()->json([
                'message'      => 'Saldo recarregado com sucesso.',
                'movimentacao' => $movimentacao,
                'saldo_atual'  => $usuario->fresh()->saldo,
            ], 200);

        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $e) {
            Log::error('MovimentacaoController@recarregar: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao recarregar saldo.'], 500);
        }
    }

    // ========================
    // ADMIN — Desfazer recarga de saldo
    // ========================

    /**
     * Desfaz uma recarga de saldo, criando um ajuste negativo
     */
    public function desfazer(Request $request, string $id)
    {
        try {
            $admin = $request->user();
            
            $movimentacaoOriginal = Movimentacao::with('user')->find($id);

            if (!$movimentacaoOriginal) {
                return response()->json(['message' => 'Movimentação não encontrada.'], 404);
            }

            if ($movimentacaoOriginal->tipo !== 'recarga') {
                return response()->json(['message' => 'Apenas recargas podem ser desfeitas por este método.'], 400);
            }

            // Verifica se já foi desfeita (olhando se existe alguma movimentação de ajuste que referencie esta)
            $jaDesfeita = Movimentacao::where('tipo', 'ajuste')
                ->where('descricao', 'LIKE', "%Ref: {$movimentacaoOriginal->id}%")
                ->exists();

            if ($jaDesfeita) {
                return response()->json(['message' => 'Esta recarga já foi desfeita anteriormente.'], 400);
            }

            $usuario = $movimentacaoOriginal->user;
            $valorEstorno = $movimentacaoOriginal->valor;

            if ($usuario->saldo < $valorEstorno) {
                return response()->json(['message' => 'O usuário não possui saldo suficiente para estornar esta recarga.'], 400);
            }

            $novaMovimentacao = DB::transaction(function () use ($usuario, $valorEstorno, $admin, $movimentacaoOriginal) {
                $saldoAnterior = $usuario->saldo;
                
                $usuario->decrement('saldo', $valorEstorno);
                
                $saldoPosterior = $saldoAnterior - $valorEstorno;

                return Movimentacao::create([
                    'user_id'         => $usuario->id,
                    'pedido_id'       => null,
                    'admin_id'        => $admin->id,
                    'valor'           => -$valorEstorno,
                    'tipo'            => 'ajuste',
                    'saldo_anterior'  => $saldoAnterior,
                    'saldo_posterior' => $saldoPosterior,
                    'descricao'       => "Estorno de recarga (Ref: {$movimentacaoOriginal->id})",
                ]);
            });

            return response()->json([
                'message' => 'Recarga desfeita com sucesso.',
                'movimentacao' => $novaMovimentacao,
            ], 200);

        } catch (Exception $e) {
            Log::error('MovimentacaoController@desfazer: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao desfazer recarga.'], 500);
        }
    }

    // ========================
    // ADMIN — Listagem para o Refine (cantina-admin)
    // ========================

    /**
     * Lista todas as movimentações (para o painel admin / Refine)
     */
    public function index(Request $request)
    {
        try {
            $query = Movimentacao::with(['user:id,name,email', 'pedido:id,senha_diaria,status', 'admin:id,name']);

            // Filtros seguros
            $filtrosPermitidos = ['tipo', 'user_id'];
            foreach ($filtrosPermitidos as $campo) {
                if ($request->filled($campo)) {
                    $query->where($campo, $request->input($campo));
                }
            }

            // Ordenação segura
            $colunasPermitidas = ['id', 'valor', 'tipo', 'created_at'];
            $coluna = $request->input('_sort', 'id');
            $direcao = strtolower($request->input('_order', 'desc'));

            if (!in_array($coluna, $colunasPermitidas)) {
                $coluna = 'id';
            }
            if (!in_array($direcao, ['asc', 'desc'])) {
                $direcao = 'desc';
            }

            $query->orderBy($coluna, $direcao);

            return response()->json($query->get(), 200);

        } catch (Exception $e) {
            Log::error('MovimentacaoController@index: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao buscar movimentações.'], 500);
        }
    }

    /**
     * Mostra uma movimentação específica
     */
    public function show(string $id)
    {
        try {
            $movimentacao = Movimentacao::with(['user:id,name,email', 'pedido:id,senha_diaria,status', 'admin:id,name'])->find($id);

            if (!$movimentacao) {
                return response()->json(['message' => 'Movimentação não encontrada.'], 404);
            }

            return response()->json($movimentacao, 200);

        } catch (Exception $e) {
            Log::error('MovimentacaoController@show: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao buscar movimentação.'], 500);
        }
    }
}
