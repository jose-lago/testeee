<?php

namespace App\Http\Controllers;

use App\Models\Produto;
use App\Models\User;
use App\Services\TotemPaymentService;
use App\Services\PedidoService;
use Illuminate\Http\Request;

class TotemController extends Controller
{
    /**
     * Lista todos os produtos disponíveis para exibição no totem.
     */
    public function produtos()
    {
        return response()->json(
            Produto::orderBy('categoria')
                ->orderBy('nome')
                ->get()
        );
    }

    /**
     * Consulta e validação de usuário pelo código do cartão RFID.
     */
    public function usuarioPorRfid($rfidCode)
    {
        $rfidCode = trim((string) $rfidCode);

        if ($rfidCode === '') {
            return response()->json([
                'message' => 'Código RFID inválido.'
            ], 422);
        }

        $user = User::where('rfid_code', $rfidCode)->first();

        /*
         * RFID-05: Cartão não cadastrado.
         */
        if (!$user) {
            return response()->json([
                'message' => 'Cartão não encontrado.'
            ], 404);
        }

        /*
         * RFID-04: Cartão bloqueado.
         */
        if ($user->rfid_blocked) {
            return response()->json([
                'message' => 'Cartão bloqueado.'
            ], 403);
        }

        if (!$user->ativo) {
            return response()->json([
                'message' => 'Usuário inativo.'
            ], 403);
        }

        /*
         * RFID-03: Cartão válido.
         * Retorna dados públicos do usuário e indica se o PIN está cadastrado.
         */
        $temPin = !empty($user->getAttributes()['rfid_pin']);

        return response()->json([
            'id'                => $user->id,
            'nome'              => $user->name,
            'rfid_code'         => $user->rfid_code,
            'tem_pin_cadastrado' => $temPin,
        ]);
    }

    /**
     * Finalização de pedido do Totem delegada para a centralização em PedidoController.
     */
    public function criarPedido(
        Request $request,
        TotemPaymentService $paymentService,
        PedidoService $pedidoService
    ) {
        return app(PedidoController::class)->finalizar($request, $paymentService, $pedidoService);
    }
}