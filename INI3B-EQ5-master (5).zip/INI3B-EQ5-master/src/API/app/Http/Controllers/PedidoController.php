<?php

namespace App\Http\Controllers;

use App\Models\Pedido;
use App\Models\PedidoProduto;
use App\Models\Produto;
use App\Models\User;
use App\Models\Movimentacao;
use App\Models\UserCredito;
use App\Services\ExpoNotificationService;
use App\Services\TotemPaymentService;
use App\Services\PedidoService;
use App\Exceptions\PedidoNaoCancelavelException;
use App\Exceptions\RegraDeNegociaException;
use App\Events\OrderCreated;
use Illuminate\Http\Request;
use Illuminate\Contracts\Cache\LockProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Exception;
use Illuminate\Validation\ValidationException;

class PedidoController extends Controller
{
    /**
     * 1. LISTAR PEDIDOS (Admin - Refine)
     */
    public function index(Request $request)
    {
        try {
            $query = Pedido::with(['itens.produto', 'user', 'preparador']);

            $filtrosPermitidos = ['status', 'user_id', 'preparador_id'];
            foreach ($filtrosPermitidos as $campo) {
                if ($request->filled($campo)) {
                    $query->where($campo, $request->input($campo));
                }
            }

            $colunasPermitidas = ['id', 'senha_diaria', 'status', 'valor_total', 'created_at', 'updated_at'];
            $coluna = $request->input('_sort', 'id');
            $direcao = strtolower($request->input('_order', 'desc'));

            if (!in_array($coluna, $colunasPermitidas)) $coluna = 'id';
            if (!in_array($direcao, ['asc', 'desc'])) $direcao = 'desc';

            $query->orderBy($coluna, $direcao);

            return response()->json($query->get(), 200);
        } catch (Exception $e) {
            Log::error('PedidoController@index: ' . $e->getMessage());
            return response()->json(['message' => 'Erro interno ao buscar pedidos.'], 500);
        }
    }

    /**
     * 2. MOSTRAR PEDIDO ESPECÍFICO
     */
    public function show(string $id)
    {
        try {
            $pedido = Pedido::with(['itens.produto', 'user', 'preparador'])->find($id);
            if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);
            return response()->json($pedido, 200);
        } catch (Exception $e) {
            Log::error('PedidoController@show: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao buscar pedido.'], 500);
        }
    }

    /**
     * 3. CRIAR PEDIDO (React Native - Suporta Saldo e Crédito)
     */
    public function criar(Request $request, PedidoService $pedidoService)
    {
        try {
            $request->validate([
                'momento_bebida'  => 'sometimes|in:agora,com_almoco',
                'forma_pagamento' => 'sometimes|in:saldo,credito',
                'pin'             => 'required_if:forma_pagamento,credito',
                'itens'           => 'required|array|min:1',
                'itens.*.produto_id' => 'required|exists:produtos,id',
                'itens.*.quantidade' => 'required|integer|min:1',
            ]);

            $user = $request->user();
            $formaPagamento = $request->input('forma_pagamento', 'saldo');

            // 1. Validação centralizada de itens e cálculo do valor total
            $resultado = $pedidoService->validarItensECalcularTotal($request->input('itens'));
            $valorTotal = $resultado['valor_total'];
            $itensVerificados = $resultado['itens_verificados'];

            // 2. Criação transacionada com rollback automático do débito caso falhe a criação do pedido/itens
            $pedido = $pedidoService->criarPedidoTransacionado(
                function () use ($user, $formaPagamento, $valorTotal, $request) {
                    if ($formaPagamento === 'credito') {
                        if (!\App\Models\Configuracao::isCreditoAtivo()) {
                            throw new \RuntimeException('A funcionalidade de crédito / fiado está temporariamente desativada pela cantina.');
                        }

                        $credito = UserCredito::where('user_id', $user->id)->lockForUpdate()->first();
                        if (!$credito || !$credito->verificado) {
                            throw new \RuntimeException('Serviço de crédito não ativado.');
                        }

                        if (!Hash::check($request->input('pin'), $credito->pin)) {
                            throw new \RuntimeException('PIN de segurança incorreto.');
                        }

                        if (($credito->limite - $credito->divida_atual) < $valorTotal) {
                            throw new \RuntimeException('Limite de crédito insuficiente.');
                        }

                        $dividaAnterior = (float) $credito->divida_atual;
                        $credito->increment('divida_atual', $valorTotal);

                        return [
                            'user' => $user,
                            'payment_method' => 'credito',
                            'balance_before' => $dividaAnterior,
                            'balance_after' => $dividaAnterior + $valorTotal,
                        ];
                    } else {
                        $userLocked = User::where('id', $user->id)->lockForUpdate()->first();
                        if ($userLocked->saldo < $valorTotal) {
                            throw new \RuntimeException('Saldo insuficiente.');
                        }

                        $saldoAnterior = (float) $userLocked->saldo;
                        $userLocked->decrement('saldo', $valorTotal);

                        return [
                            'user' => $userLocked,
                            'payment_method' => 'saldo',
                            'balance_before' => $saldoAnterior,
                            'balance_after' => $saldoAnterior - $valorTotal,
                        ];
                    }
                },
                $itensVerificados,
                $valorTotal,
                $request->input('momento_bebida', 'agora')
            );

            return response()->json($pedido->load('itens.produto'), 201);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\InvalidArgumentException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        } catch (\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        } catch (Exception $e) {
            Log::error('PedidoController@criar: ' . $e->getMessage());
            return response()->json(['message' => $e->getMessage() ?: 'Erro ao criar pedido.'], 500);
        }
    }

    /**
     * 3.1. FINALIZAR PEDIDO (Totem de Autoatendimento com RFID + Senha do Cartão)
     */
    public function finalizar(Request $request, TotemPaymentService $totemPaymentService, PedidoService $pedidoService)
    {
        try {
            $dados = $request->validate([
                'rfid_code'       => 'required|string',
                'forma_pagamento' => 'required|in:saldo,credito',
                'pin'             => 'required|string',
                'momento_bebida'  => 'sometimes|in:agora,com_almoco',
                'itens'           => 'required|array|min:1',
                'itens.*.produto_id' => 'required|exists:produtos,id',
                'itens.*.quantidade' => 'required|integer|min:1',
            ]);

            // 1. Validação centralizada dos produtos e cálculo do total
            $resultado = $pedidoService->validarItensECalcularTotal($dados['itens']);
            $valorTotal = $resultado['valor_total'];
            $itensVerificados = $resultado['itens_verificados'];

            // 2. Processamento do pagamento e persistência do pedido com rollback atômico
            $pedido = $pedidoService->criarPedidoTransacionado(
                function () use ($totemPaymentService, $dados, $valorTotal) {
                    return $totemPaymentService->processarPagamento(
                        $dados['rfid_code'],
                        (string) $valorTotal,
                        $dados['forma_pagamento'],
                        $dados['pin']
                    );
                },
                $itensVerificados,
                $valorTotal,
                $dados['momento_bebida'] ?? 'agora'
            );

            return response()->json($pedido->load('itens.produto'), 201);

        } catch (ValidationException $e) {
            throw $e;
        } catch (\InvalidArgumentException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        } catch (\RuntimeException $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        } catch (Exception $e) {
            Log::error('PedidoController@finalizar: ' . $e->getMessage());
            return response()->json(['message' => $e->getMessage() ?: 'Erro ao processar pedido no totem.'], 400);
        }
    }

    /**
     * 4. MEUS PEDIDOS (React Native)
     */
    public function meusPedidos(Request $request)
    {
        try {
            $pedidos = Pedido::where('user_id', $request->user()->id)
                ->with(['itens.produto'])
                ->orderBy('created_at', 'desc')
                ->get();
            return response()->json($pedidos, 200);
        } catch (Exception $e) {
            Log::error('PedidoController@meusPedidos: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao buscar seus pedidos.'], 500);
        }
    }

    /**
     * 5. STATUS DO PEDIDO
     */
    public function statusPedido(Request $request, string $id)
    {
        try {
            $pedido = Pedido::with(['itens.produto'])->find($id);
            if (!$pedido || $pedido->user_id !== $request->user()->id) {
                return response()->json(['message' => 'Acesso negado.'], 403);
            }

            $posicao = Pedido::whereIn('status', ['pendente', 'preparando'])->where(function ($q) use ($pedido) {
                $q->where('posicao_fila', '<', $pedido->posicao_fila)->orWhere(function ($q2) use ($pedido) {
                    $q2->where('posicao_fila', '=', $pedido->posicao_fila)->where('created_at', '<', $pedido->created_at);
                });
            })->count() + 1;

            return response()->json([
                'id' => $pedido->id,
                'senha' => $pedido->senha_diaria,
                'senha_diaria' => $pedido->senha_diaria,
                'status' => $pedido->status,
                'posicao' => $posicao,
                'codigo_retirada' => $pedido->codigo_retirada,
                'momento_bebida' => $pedido->momento_bebida,
                'itens' => $pedido->itens
            ], 200);
        } catch (Exception $e) {
            return response()->json(['message' => 'Erro ao consultar status.'], 500);
        }
    }

    /**
     * 6. AÇÕES DO KANBAN (Funcionária)
     */
    public function preparadores() {
        return response()->json(User::whereIn('tipo', ['funcionario', 'admin'])->select('id', 'name', 'tipo')->orderBy('name', 'asc')->get(), 200);
    }

    public function fila() {
        $bebidasAgora = Pedido::where('momento_bebida', 'agora')
            ->whereIn('status', ['pendente', 'preparando'])
            ->whereHas('itens', fn($q) => $q->where('entregue', false)->whereHas('produto', fn($p) => $p->where('categoria', 'bebida')))
            ->with(['itens' => fn($q) => $q->where('entregue', false)->whereHas('produto', fn($p) => $p->where('categoria', 'bebida')), 'itens.produto', 'user'])
            ->orderBy('posicao_fila', 'asc')
            ->get();

        $pendentes = Pedido::where('status', 'pendente')->with(['itens.produto', 'user'])->orderBy('posicao_fila', 'asc')->get();
        $emPreparo = Pedido::where('status', 'preparando')->with(['itens.produto', 'user', 'preparador'])->get();
        $prontos = Pedido::where('status', 'pronto')->with(['itens.produto', 'user'])->get();

        return response()->json([
            'bebidas_agora' => $bebidasAgora,
            'pendentes' => $pendentes,
            'em_preparo' => $emPreparo,
            'prontos' => $prontos,
            'total_fila' => Pedido::where('status', 'pendente')->count()
        ], 200);
    }

    public function entregarBebida(string $id) {
        $pedido = Pedido::with('user')->find($id);
        if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

        $pedido->itens()->whereHas('produto', fn($q) => $q->where('categoria', 'bebida'))->update(['entregue' => true]);
        if ($pedido->itens()->where('entregue', false)->count() === 0) {
            $pedido->update(['status' => 'entregue']);
        }

        // Disparo de notificação para bebida
        if ($pedido->user) {
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $pedido->user,
                '🥤 Bebida pronta para retirada!',
                "Sua bebida do pedido #{$pedido->senha_diaria} já pode ser retirada no balcão.",
                ['pedido_id' => $pedido->id, 'status' => 'bebida_entregue', 'senha_diaria' => $pedido->senha_diaria]
            );
        }

        return response()->json($pedido->load('itens.produto'), 200);
    }

    public function preparar(Request $request, string $id) {
        $pedido = Pedido::with('user')->find($id);
        if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

        $pedido->update(['preparador_id' => $request->preparador_id, 'status' => 'preparando']);

        // Disparo de notificação: Em preparo
        if ($pedido->user) {
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $pedido->user,
                '👨‍🍳 Pedido em preparo!',
                "Seu pedido #{$pedido->senha_diaria} começou a ser preparado pela cantina.",
                ['pedido_id' => $pedido->id, 'status' => 'preparando', 'senha_diaria' => $pedido->senha_diaria]
            );
        }

        return response()->json($pedido->load('itens.produto'), 200);
    }

    public function pronto(string $id) {
        $pedido = Pedido::with('user')->find($id);
        if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

        $pedido->update(['status' => 'pronto']);

        // Disparo de notificação: Pronto para retirada
        if ($pedido->user) {
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $pedido->user,
                '🎉 Pedido pronto!',
                "Seu pedido #{$pedido->senha_diaria} está pronto para retirada! Código: {$pedido->codigo_retirada}",
                [
                    'pedido_id' => $pedido->id,
                    'status' => 'pronto',
                    'senha_diaria' => $pedido->senha_diaria,
                    'codigo_retirada' => $pedido->codigo_retirada
                ]
            );
        }

        return response()->json($pedido->load('itens.produto'), 200);
    }

    public function entregar(Request $request, string $id) {
        $pedido = Pedido::with('user')->find($id);
        if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

        $pedido->update(['status' => 'entregue']);
        $pedido->itens()->update(['entregue' => true]);

        // Disparo de notificação: Entregue
        if ($pedido->user) {
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $pedido->user,
                '✅ Pedido entregue!',
                "Seu pedido #{$pedido->senha_diaria} foi concluído. Bom apetite!",
                ['pedido_id' => $pedido->id, 'status' => 'entregue', 'senha_diaria' => $pedido->senha_diaria]
            );
        }

        return response()->json(['message' => 'Entregue'], 200);
    }

    public function cancelar(Request $request, string $id) {
        try {
            $user = $request->user();
            $pedido = Pedido::find($id);

            if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

            // 1. Somente o dono do pedido pode cancelar
            if ((string) $pedido->user_id !== (string) $user->id) {
                return response()->json(['message' => 'Acesso negado.'], 403);
            }

            // 2. Cancelamento permitido apenas enquanto o pedido estiver pendente.
            //    Pedidos já cancelados caem aqui, garantindo idempotência e impedindo estorno duplo.
            if ($pedido->status !== 'pendente') {
                throw new PedidoNaoCancelavelException(
                    $pedido->status === 'cancelado'
                        ? 'Este pedido já foi cancelado.'
                        : 'Não é possível cancelar, o pedido já está em preparo.',
                    $pedido->status === 'cancelado' ? 409 : 403
                );
            }

            $resultado = DB::transaction(function () use ($pedido, $user) {
                // 3. Revalida o pedido dentro da transação e com lock de linha,
                //    fechando a corrida entre dois cancelamentos simultâneos.
                $pedidoLock = Pedido::where('id', $pedido->id)->lockForUpdate()->first();

                if (!$pedidoLock) {
                    throw new RegraDeNegociaException('Pedido não encontrado.');
                }

                if ($pedidoLock->status !== 'pendente') {
                    throw new PedidoNaoCancelavelException(
                        $pedidoLock->status === 'cancelado'
                            ? 'Este pedido já foi cancelado.'
                            : 'Não é possível cancelar, o pedido já está em preparo.',
                        $pedidoLock->status === 'cancelado' ? 409 : 403
                    );
                }

                // 4. Pedidos antigos (forma_pagamento NULL) são tratados como 'saldo'.
                $formaPagamento = $pedidoLock->forma_pagamento ?: 'saldo';
                $valor = (float) $pedidoLock->valor_total;

                $pedidoLock->update(['status' => 'cancelado']);

                if ($formaPagamento === 'credito') {
                    // 4a. Estorno de CRÉDITO: reverte a dívida, sem tocar no saldo.
                    $credito = UserCredito::where('user_id', $pedidoLock->user_id)
                        ->lockForUpdate()
                        ->first();

                    if (!$credito) {
                        throw new RegraDeNegociaException('Não foi possível localizar o registro de crédito do usuário para o estorno.');
                    }

                    $dividaAnterior = (float) $credito->divida_atual;
                    $dividaPosterior = max(0, round($dividaAnterior - $valor, 2));

                    $credito->divida_atual = $dividaPosterior;
                    $credito->save();

                    $valorAnterior = $dividaAnterior;
                    $valorPosterior = $dividaPosterior;
                    $contaAfetada = 'dívida de crédito';
                } else {
                    // 4b. Estorno de SALDO: credita de volta somente o saldo.
                    $userLock = User::where('id', $pedidoLock->user_id)->lockForUpdate()->first();

                    $saldoAnterior = (float) $userLock->saldo;
                    $saldoPosterior = round($saldoAnterior + $valor, 2);

                    $userLock->saldo = $saldoPosterior;
                    $userLock->save();

                    $valorAnterior = $saldoAnterior;
                    $valorPosterior = $saldoPosterior;
                    $contaAfetada = 'saldo';
                }

                // 5. Registra a movimentação de estorno.
                Movimentacao::create([
                    'user_id' => $pedidoLock->user_id,
                    'pedido_id' => $pedidoLock->id,
                    'valor' => $valor,
                    'tipo' => 'estorno',
                    'saldo_anterior' => $valorAnterior,
                    'saldo_posterior' => $valorPosterior,
                    'descricao' => "Estorno do pedido #{$pedidoLock->senha_diaria} (" . ucfirst($formaPagamento) . " - {$contaAfetada})",
                ]);

                return [
                    'forma_pagamento' => $formaPagamento,
                    'valor' => $valor,
                    'valor_anterior' => $valorAnterior,
                    'valor_posterior' => $valorPosterior,
                ];
            });

            // 6. Notificação fora da transação.
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $user,
                '⚠️ Pedido cancelado',
                $resultado['forma_pagamento'] === 'credito'
                    ? "Seu pedido #{$pedido->senha_diaria} foi cancelado e a dívida de crédito foi revertida."
                    : "Seu pedido #{$pedido->senha_diaria} foi cancelado e o valor foi estornado.",
                ['pedido_id' => $pedido->id, 'status' => 'cancelado', 'senha_diaria' => $pedido->senha_diaria]
            );

            return response()->json(['message' => 'Cancelado', 'estorno' => $resultado], 200);

        } catch (PedidoNaoCancelavelException $e) {
            // Pedido não está mais em estado cancelável.
            return response()->json(['message' => $e->getMessage()], $e->getStatusCode());
        } catch (RegraDeNegociaException $e) {
            return response()->json(['message' => $e->getMessage()], 400);
        } catch (Exception $e) {
            Log::error('PedidoController@cancelar: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao cancelar o pedido.'], 500);
        }
    }
    
    public function entregarProximo(Request $request, string $id) {
        $dados = $request->validate([
            'codigo_confirmado' => 'required|accepted',
            'preparador_id' => 'sometimes|nullable|integer|exists:users,id',
        ]);

        $resultado = DB::transaction(function () use ($id, $dados) {
            $pedido = Pedido::whereKey($id)->lockForUpdate()->with('user')->first();
            if (!$pedido) {
                return ['error' => 'Pedido não encontrado.', 'status' => 404];
            }

            if ($pedido->status !== 'pronto') {
                return ['error' => 'Somente pedidos prontos podem ser entregues.', 'status' => 422];
            }

            $proximo = Pedido::where('status', 'pendente')
                ->orderBy('posicao_fila')
                ->orderBy('created_at')
                ->orderBy('id')
                ->lockForUpdate()
                ->first();

            if ($proximo) {
                if (empty($dados['preparador_id'])) {
                    throw ValidationException::withMessages([
                        'preparador_id' => 'Selecione quem irá preparar o próximo pedido.',
                    ]);
                }

                $preparador = User::whereKey($dados['preparador_id'])->lockForUpdate()->first();
                if (!$preparador || !in_array($preparador->tipo, ['funcionario', 'admin'], true)) {
                    throw ValidationException::withMessages([
                        'preparador_id' => 'O preparador selecionado não é funcionário da cantina.',
                    ]);
                }
            }

            $pedido->update(['status' => 'entregue']);
            $pedido->itens()->update(['entregue' => true]);

            if ($proximo) {
                $proximo->update([
                    'preparador_id' => $preparador->id,
                    'status' => 'preparando',
                ]);
                $proximo->load('user');
            }

            return [
                'entregue' => $pedido->load(['itens.produto', 'user']),
                'proximo' => $proximo?->load(['itens.produto', 'user']),
            ];
        }, 3);

        if (isset($resultado['error'])) {
            return response()->json(['message' => $resultado['error']], $resultado['status']);
        }

        if ($resultado['proximo']?->user) {
            app(ExpoNotificationService::class)->enviarParaUsuario(
                $resultado['proximo']->user,
                '👨‍🍳 Pedido em preparo!',
                "Seu pedido #{$resultado['proximo']->senha_diaria} começou a ser preparado pela cantina.",
                [
                    'pedido_id' => $resultado['proximo']->id,
                    'status' => 'preparando',
                    'senha_diaria' => $resultado['proximo']->senha_diaria,
                ]
            );
        }

        return response()->json($resultado, 200);
    }

    public function desfazer(string $id) {
        $resultado = DB::transaction(function () use ($id) {
            $pedido = Pedido::whereKey($id)->lockForUpdate()->first();
            if (!$pedido) {
                return ['error' => 'Pedido não encontrado.', 'status' => 404];
            }

            if ($pedido->status === 'preparando') {
                $pedido->update(['status' => 'pendente', 'preparador_id' => null]);
            } elseif ($pedido->status === 'pronto') {
                $pedido->update(['status' => 'preparando']);
            } elseif ($pedido->status === 'entregue') {
                $pedido->update(['status' => 'pronto']);
                $pedido->itens()->update(['entregue' => false]);
            } else {
                return ['error' => 'Não há ação para desfazer neste pedido.', 'status' => 422];
            }

            return ['pedido' => $pedido->load('itens.produto')];
        }, 3);

        if (isset($resultado['error'])) {
            return response()->json(['message' => $resultado['error']], $resultado['status']);
        }

        return response()->json($resultado['pedido'], 200);
    }

    public function update(Request $request, string $id)
    {
        $dados = $request->validate([
            'status' => 'sometimes|in:pendente,preparando,pronto,entregue,cancelado',
            'posicao_fila' => 'sometimes|integer|min:0',
        ]);

        $resultado = DB::transaction(function () use ($id, $dados) {
            $pedido = Pedido::whereKey($id)->lockForUpdate()->first();
            if (!$pedido) {
                return ['error' => 'Pedido não encontrado.', 'status' => 404];
            }

            if (array_key_exists('status', $dados)) {
                if ($pedido->status === 'cancelado' && $dados['status'] !== 'cancelado') {
                    return [
                        'error' => 'Pedidos cancelados não podem voltar ao fluxo; crie um novo pedido.',
                        'status' => 422,
                    ];
                }

                if ($dados['status'] === 'cancelado' && $pedido->status !== 'cancelado') {
                    return [
                        'error' => 'Use o fluxo de cancelamento para garantir o estorno do pagamento.',
                        'status' => 422,
                    ];
                }
            }

            $pedido->update($dados);

            return ['pedido' => $pedido->load(['itens.produto', 'user', 'preparador'])];
        }, 3);

        if (isset($resultado['error'])) {
            return response()->json(['message' => $resultado['error']], $resultado['status']);
        }

        return response()->json($resultado['pedido'], 200);
    }

    public function destroy(string $id)
    {
        $pedido = Pedido::find($id);
        if (!$pedido) return response()->json(['message' => 'Pedido não encontrado.'], 404);

        $pedido->delete();

        return response()->json(['message' => 'Pedido excluído.'], 200);
    }
}
