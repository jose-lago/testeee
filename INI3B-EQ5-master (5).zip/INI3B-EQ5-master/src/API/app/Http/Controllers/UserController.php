<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log; 
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Exception; 

class UserController extends Controller
{
    /**
     * 1. LISTAR USUÁRIOS (Apenas Filtros e Ordenação)
     */
    public function index(Request $request)
    {
        try {
            $consulta = User::query();

            $colunasPermitidas = ['id', 'name', 'email', 'tipo', 'saldo', 'created_at', 'updated_at'];
            foreach ($request->query() as $campo => $valor) {
                if (in_array($campo, ['_sort', '_order', 'page', 'per_page'])) {
                    continue;
                }
                $colunaReal = str_replace('_like', '', $campo);
                if (!in_array($colunaReal, $colunasPermitidas)) {
                    continue;
                }
                if (str_ends_with($campo, '_like')) {
                    $consulta->where($colunaReal, 'ilike', "%{$valor}%");
                } else {
                    $consulta->where($campo, $valor);
                }
            }

            if ($request->has('_sort')) {
                $coluna = $request->input('_sort');
                $direcao = $request->input('_order', 'asc');
                $consulta->orderBy($coluna, $direcao);
            } else {
                $consulta->orderBy('id', 'desc'); 
            }

            $usuarios = $consulta->get();
            return response()->json($usuarios, 200);

        } catch (Exception $erro) {
            Log::error('Erro ao listar usuários: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro interno ao buscar usuários'], 500);
        }
    }

    /**
     * 2. CRIAR USUÁRIO
     */
    public function store(Request $request)
    {
        try {
            $dadosValidados = $request->validate([
                'name'     => 'required|string',
                'email'    => 'required|email|unique:users,email',
                'password' => 'required|min:6',
                'tipo'     => 'sometimes|string',
            ]);
            $usuario = User::create($dadosValidados);
            return response()->json($usuario, 201);
        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $erro) {
            Log::error('Erro ao criar usuário: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao salvar o novo usuário.'], 500);
        }
    }

    /**
     * 3. MOSTRAR UM USUÁRIO ESPECÍFICO
     */
    public function show(string $id)
    {
        try {
            $usuario = User::find($id);
            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado'], 404);
            }
            return response()->json($usuario, 200);
        } catch (Exception $erro) {
            Log::error('Erro ao buscar usuário específico: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao buscar os dados do usuário.'], 500);
        }
    }

    /**
     * 4. ATUALIZAR USUÁRIO
     */
    public function update(Request $request, string $id)
    {
        try {
            $usuario = User::find($id);
            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado'], 404);
            }
            $dadosValidados = $request->validate([
                'name'     => 'sometimes|string',
                'email'    => 'sometimes|email|unique:users,email,' . $id,
                'password' => 'sometimes|min:6',
                'tipo'     => 'sometimes|string',
            ]);
            $usuario->update($dadosValidados);
            return response()->json($usuario, 200);
        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $erro) {
            Log::error('Erro ao atualizar usuário: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao tentar atualizar os dados.'], 400);
        }
    }

    /**
     * 5. EXCLUIR USUÁRIO
     */
    public function destroy(string $id)
    {
        try {
            $usuario = User::find($id);
            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado'], 404);
            }
            $usuario->delete();
            return response()->json(['message' => 'Excluído com sucesso'], 200);
        } catch (Exception $erro) {
            Log::error('Erro ao excluir usuário: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao tentar excluir o usuário.'], 500);
        }
    }

    /**
     * Vincular código RFID a um usuário (apenas funcionario/admin)
     */
    public function linkRfid(Request $request, string $id)
    {
        $dados = $request->validate([
            'rfid_code' => 'required|string'
        ]);

        $rfid = trim($dados['rfid_code']);

        try {
            return DB::transaction(function () use ($id, $rfid) {
                $usuario = User::where('id', $id)->lockForUpdate()->first();
                if (!$usuario) {
                    return response()->json(['message' => 'Usuário não encontrado'], 404);
                }

                // Verifica se o código já pertence a outro usuário
                $outro = User::where('rfid_code', $rfid)->where('id', '!=', $usuario->id)->first();
                if ($outro) {
                    return response()->json(['message' => 'Código RFID já vinculado a outro usuário'], 409);
                }

                $usuario->rfid_code = $rfid;
                $usuario->save();

                return response()->json($usuario, 200);
            });
        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $erro) {
            Log::error('Erro ao vincular RFID: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao vincular RFID.'], 500);
        }
    }

    /**
     * Desvincular RFID
     */
    public function unlinkRfid(Request $request, string $id)
    {
        try {
            return DB::transaction(function () use ($id) {
                $usuario = User::where('id', $id)->lockForUpdate()->first();
                if (!$usuario) {
                    return response()->json(['message' => 'Usuário não encontrado'], 404);
                }

                $usuario->rfid_code = null;
                $usuario->save();

                return response()->json($usuario, 200);
            });
        } catch (Exception $erro) {
            Log::error('Erro ao desvincular RFID: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao desvincular RFID.'], 500);
        }
    }

    /**
     * Bloquear cartão RFID
     */
    public function blockRfid(Request $request, string $id)
    {
        try {
            $usuario = User::find($id);
            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado'], 404);
            }
            $usuario->rfid_blocked = true;
            $usuario->save();
            return response()->json($usuario, 200);
        } catch (Exception $erro) {
            Log::error('Erro ao bloquear RFID: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao bloquear RFID.'], 500);
        }
    }

    /**
     * Desbloquear cartão RFID
     */
    public function unblockRfid(Request $request, string $id)
    {
        try {
            $usuario = User::find($id);
            if (!$usuario) {
                return response()->json(['message' => 'Usuário não encontrado'], 404);
            }
            $usuario->rfid_blocked = false;
            $usuario->save();
            return response()->json($usuario, 200);
        } catch (Exception $erro) {
            Log::error('Erro ao desbloquear RFID: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao desbloquear RFID.'], 500);
        }
    }

    /**
     * Definir ou trocar o PIN do cartão RFID (autenticado como próprio usuário)
     *
     * Regras:
     *  - Só possível se o usuário já tiver rfid_code vinculado.
     *  - Se já houver rfid_pin, exige confirmação do PIN atual antes de trocar.
     *  - PIN deve ser numérico com exatamente 6 dígitos.
     */
    public function setRfidPin(Request $request)
    {
        try {
            $usuario = $request->user();

            // Cartão não vinculado: não permite definir PIN
            if (empty($usuario->rfid_code)) {
                return response()->json([
                    'message' => 'Você não possui um cartão RFID vinculado. Procure a cantina para vincular seu cartão.'
                ], 422);
            }

            $dados = $request->validate([
                'pin_atual' => 'sometimes|nullable|string|digits:6',
                'novo_pin'  => 'required|string|digits:6|confirmed',
            ]);

            $jaTemPin = !empty($usuario->getAttributes()['rfid_pin']);

            // Se já tem PIN, exige confirmação do PIN atual
            if ($jaTemPin) {
                $pinAtual = $dados['pin_atual'] ?? null;

                if (empty($pinAtual)) {
                    return response()->json([
                        'message' => 'Para trocar a senha, informe sua senha atual do cartão.'
                    ], 422);
                }

                if (!\Illuminate\Support\Facades\Hash::check($pinAtual, $usuario->getAttributes()['rfid_pin'])) {
                    return response()->json([
                        'message' => 'Senha atual do cartão incorreta.'
                    ], 422);
                }
            }

            // Salva o novo PIN (o cast 'hashed' do Eloquent faz o bcrypt automaticamente)
            $usuario->rfid_pin = $dados['novo_pin'];
            $usuario->save();

            return response()->json([
                'message' => $jaTemPin
                    ? 'Senha do cartão RFID alterada com sucesso.'
                    : 'Senha do cartão RFID cadastrada com sucesso. Você já pode usar o totem!'
            ], 200);

        } catch (ValidationException $e) {
            throw $e;
        } catch (Exception $erro) {
            Log::error('Erro ao definir PIN do RFID: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao salvar a senha do cartão.'], 500);
        }
    }

    /**
     * 6. PERFIL DO USUÁRIO AUTENTICADO
     */
    public function me(Request $request)
    {
        try {
            $usuarioLogado = $request->user();

            if (!$usuarioLogado) {
                return response()->json(['message' => 'Não autenticado.'], 401);
            }

            // Carrega os dados de crédito do aluno para o App saber o limite
            $usuarioLogado->load('credito');

            // Inclui status do cartão RFID sem expor o hash do PIN
            $dados = $usuarioLogado->toArray();
            $dados['rfid_code'] = $usuarioLogado->rfid_code;
            $dados['tem_pin_cadastrado'] = !empty($usuarioLogado->getAttributes()['rfid_pin']);

            return response()->json($dados, 200);

        } catch (Exception $erro) {
            Log::error('Erro ao buscar perfil do usuário autenticado: ' . $erro->getMessage());
            return response()->json(['message' => 'Erro ao obter dados do perfil.'], 500);
        }
    }

    /**
     * 7. REGISTRAR PUSH TOKEN DO USUÁRIO
     */
    public function salvarPushToken(Request $request)
    {
        try {
            $validados = $request->validate([
                'push_token' => 'required|string|max:255',
            ]);

            $usuario = $request->user();
            $novoToken = $validados['push_token'];

            // SEGURANÇA: Se outro usuário usava este mesmo dispositivo, limpa o token dele para evitar vazamento
            User::where('push_token', $novoToken)
                ->where('id', '!=', $usuario->id)
                ->update(['push_token' => null]);

            $usuario->update(['push_token' => $novoToken]);

            return response()->json([
                'sucesso' => true,
                'message' => 'Push token registrado com sucesso.'
            ], 200);

        } catch (ValidationException $e) {
            return response()->json([
                'sucesso' => false,
                'message' => 'Formato de token inválido.',
                'errors' => $e->errors()
            ], 422);
        } catch (Exception $e) {
            Log::error('Erro ao salvar push token: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao registrar token de notificação.'], 500);
        }
    }

    /**
     * 8. REMOVER PUSH TOKEN (LOGOUT)
     */
    public function removerPushToken(Request $request)
    {
        try {
            $usuario = $request->user();
            $usuario->update(['push_token' => null]);

            return response()->json([
                'sucesso' => true,
                'message' => 'Push token removido com sucesso.'
            ], 200);

        } catch (Exception $e) {
            Log::error('Erro ao remover push token: ' . $e->getMessage());
            return response()->json(['message' => 'Erro ao remover token.'], 500);
        }
    }
}
