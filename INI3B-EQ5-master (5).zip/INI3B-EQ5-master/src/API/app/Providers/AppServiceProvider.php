<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Força HTTPS quando em produção, sob proxy reverso (ngrok, Cloudflare, Caddy, etc.) ou quando configurado app.url https
        if (
            $this->app->environment('production') ||
            (function_exists('request') && request()->header('x-forwarded-proto') === 'https') ||
            str_contains(config('app.url', ''), 'https://')
        ) {
            URL::forceScheme('https');
        }
    }
}
