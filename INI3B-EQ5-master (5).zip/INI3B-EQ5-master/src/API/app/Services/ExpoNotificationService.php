<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class ExpoNotificationService
{
    private const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';

    /**
     * Valida se a string é um token válido do Expo.
     */
    public static function isExpoPushToken(?string $token): bool
    {
        if (empty($token) || !is_string($token)) {
            return false;
        }

        // Formatos aceitos pela Expo
        return (bool) (str_starts_with($token, 'ExponentPushToken[') || str_starts_with($token, 'ExpoPushToken[') || preg_match('/^[a-zA-Z0-9_\-\.\[\]]+$/', $token));
    }

    /**
     * Envia uma notificação push para um usuário específico através de seu push_token.
     *
     * @param User|string $userOrToken Instância do User ou string do ExpoPushToken
     * @param string $titulo Título da notificação
     * @param string $mensagem Corpo da mensagem
     * @param array $dados Dados adicionais (ex: ['pedido_id' => 123])
     * @return bool Retorna true se a requisição foi aceita pela Expo
     */
    public function enviarParaUsuario($userOrToken, string $titulo, string $mensagem, array $dados = []): bool
    {
        $token = null;
        $user = null;

        if ($userOrToken instanceof User) {
            $user = $userOrToken;
            $token = $user->push_token;
        } elseif (is_string($userOrToken)) {
            $token = $userOrToken;
        }

        if (empty($token) || !self::isExpoPushToken($token)) {
            Log::info("ExpoNotificationService: Token inexistente ou inválido para envio.", [
                'user_id' => $user?->id,
                'token' => $token ? substr($token, 0, 20) . '...' : null
            ]);
            return false;
        }

        return $this->enviarPush([
            'to' => $token,
            'title' => strip_tags(mb_substr($titulo, 0, 100)),
            'body' => strip_tags(mb_substr($mensagem, 0, 255)),
            'sound' => 'default',
            'priority' => 'high',
            'channelId' => 'pedidos',
            'data' => $dados,
        ], $user);
    }

    /**
     * Dispara a requisição HTTP para a API da Expo com timeout e tratamento de erros.
     */
    private function enviarPush(array $payload, ?User $user = null): bool
    {
        try {
            $response = Http::timeout(5)
                ->withoutVerifying()
                ->withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ])
                ->post(self::EXPO_PUSH_URL, $payload);

            if ($response->successful()) {
                $responseData = $response->json();
                $data = $responseData['data'] ?? [];

                // Se a resposta for um objeto com status
                if (isset($data['status'])) {
                    if ($data['status'] === 'error') {
                        $errorDetails = $data['details'] ?? [];
                        Log::warning('ExpoNotificationService: Erro retornado pela Expo.', [
                            'message' => $data['message'] ?? 'Erro desconhecido',
                            'details' => $errorDetails,
                        ]);

                        // Limpeza automática de segurança se o token foi invalidado/desinstalado
                        if (($errorDetails['error'] ?? '') === 'DeviceNotRegistered' && $user) {
                            $user->update(['push_token' => null]);
                            Log::info("ExpoNotificationService: Token invalidado removido do usuário #{$user->id}");
                        }
                        return false;
                    }
                }

                return true;
            }

            Log::error('ExpoNotificationService: Falha HTTP ao enviar push.', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            return false;

        } catch (Exception $e) {
            // Não quebra a transação do pedido caso haja instabilidade de rede
            Log::error('ExpoNotificationService: Exceção ao tentar enviar push: ' . $e->getMessage());
            return false;
        }
    }
}
