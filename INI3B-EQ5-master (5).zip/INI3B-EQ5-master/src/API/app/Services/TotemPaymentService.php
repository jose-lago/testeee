<?php

namespace App\Services;

use App\Models\User;
use App\Models\UserCredito;
use Illuminate\Support\Facades\Hash;
use InvalidArgumentException;
use RuntimeException;

class TotemPaymentService
{
    /**
     * Processa o pagamento do Totem.
     *
     * Este método deve ser chamado dentro de uma DB::transaction()
     * controlada pelo endpoint de finalização.
     */
    public function processarPagamento(
        string $rfidCode,
        string $valorTotal,
        string $metodo,
        ?string $pin = null
    ): array {
        $rfidCode = trim($rfidCode);
        $metodo = strtolower(trim($metodo));
        $valorTotal = $this->normalizarValor($valorTotal);

        if ($rfidCode === '') {
            throw new InvalidArgumentException('O código RFID é obrigatório.');
        }
        //valor total do pagamento
        if ($valorTotal === null || bccomp($valorTotal, '0.00', 2) !== 1) {
            throw new InvalidArgumentException('O valor do pagamento deve ser positivo.');
        }
        //valida o metd. de pagamento
        if (!in_array($metodo, ['saldo', 'credito'], true)) {
            throw new InvalidArgumentException('Forma de pagamento inválida.');
        }
        //procura o cartão RFID e impede que outro processo o utilize ao mesmo tempo
        $user = User::query()
            ->where('rfid_code', $rfidCode) // dev 4 tem que criar coluna
            ->lockForUpdate()
            ->first();

        if (!$user) {
            throw new RuntimeException('Cartão RFID não encontrado.');
        }

        if (!$this->usuarioAtivo($user)) {
            throw new RuntimeException('Usuário inativo.');
        }

        if ($user->rfid_blocked) {
            throw new RuntimeException('Cartão RFID bloqueado.');
        }

        // PIN nulo: bloqueia qualquer pagamento via Totem e orienta o usuário
        if (empty($user->rfid_pin)) {
            throw new RuntimeException(
                'Você ainda não cadastrou a senha do seu cartão RFID. ' .
                'Acesse o aplicativo: Perfil → Configurações da Conta → Senha do Cartão RFID.'
            );
        }

        // Validação obrigatória da senha do cartão RFID para qualquer forma de pagamento
        if (!is_string($pin) || trim($pin) === '') {
            throw new InvalidArgumentException('A senha do cartão RFID é obrigatória.');
        }

        if (!Hash::check($pin, $user->rfid_pin)) {
            throw new RuntimeException('Senha do cartão incorreta.');
        }

        if ($metodo === 'saldo') {
            return $this->processarSaldo($user, $valorTotal);
        }

        return $this->processarCredito($user, $valorTotal);
    }
    // Processa o pagamento com saldo
    private function processarSaldo(User $user, string $valorTotal): array
    {  
        $saldoAnterior = $this->normalizarValor((string) $user->saldo);
        // verifica se o saldo é suficiente
        if (bccomp($saldoAnterior, $valorTotal, 2) === -1) {
            throw new RuntimeException('Saldo insuficiente.');
        }
        //calcula o resultado
        $saldoPosterior = bcsub($saldoAnterior, $valorTotal, 2);

        $user->saldo = $saldoPosterior;
        $user->save();

        return [
            'approved' => true,
            'user' => $user->fresh(),
            'payment_method' => 'saldo',
            'amount' => $valorTotal,
            'balance_before' => $saldoAnterior,
            'balance_after' => $saldoPosterior,
        ];
    }

    private function processarCredito(
        User $user,
        string $valorTotal
    ): array {
        if (!\App\Models\Configuracao::isCreditoAtivo()) {
            throw new RuntimeException('A funcionalidade de crédito / fiado está temporariamente desativada pela cantina.');
        }

        //busca crédito do user e bloqueia p/ atualização
        $credito = UserCredito::query()
            ->where('user_id', $user->id)
            ->lockForUpdate()
            ->first();

        if (!$credito || !$credito->verificado) {
            throw new RuntimeException('Crédito não ativado para este usuário.');
        }
        $limite = $this->normalizarValor((string) $credito->limite);
        $dividaAnterior = $this->normalizarValor((string) $credito->divida_atual);
        //calcula limite disponível
        $limiteDisponivel = bcsub($limite, $dividaAnterior, 2);

        if (bccomp($limiteDisponivel, $valorTotal, 2) === -1) {
            throw new RuntimeException('Limite de crédito insuficiente.');
        }
        // nova dívida após o pagamento
        $dividaPosterior = bcadd($dividaAnterior, $valorTotal, 2);

        $credito->divida_atual = $dividaPosterior;
        $credito->save();

        return [
            'approved' => true,
            'user' => $user->fresh(),
            'payment_method' => 'credito',
            'amount' => $valorTotal,
            'balance_before' => $dividaAnterior,
            'balance_after' => $dividaPosterior,
        ];
    }

    private function usuarioAtivo(User $user): bool
    {
        $atributos = $user->getAttributes();

        foreach (['ativo', 'active', 'is_active'] as $campo) {
            if (array_key_exists($campo, $atributos)) {
                return (bool) $user->getAttribute($campo);
            }
        }

        return true;
    }

    // valor do pagmnto deve ser positivo e com no max 2 casas decimais
    private function normalizarValor(string $valor): ?string
    {
        $valor = trim($valor);

        if (!preg_match('/^\d+(?:\.\d{1,2})?$/D', $valor)) {
            return null;
        }

        [$parteInteira, $parteDecimal] = array_pad(
            explode('.', $valor, 2),
            2,
            ''
        );

        $parteInteira = ltrim($parteInteira, '0') ?: '0';
        $parteDecimal = str_pad($parteDecimal, 2, '0');

        return $parteInteira . '.' . $parteDecimal;
    }
}