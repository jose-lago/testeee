<?php

namespace App\Services;

use App\Models\Movimentacao;
use App\Models\Pedido;
use App\Models\PedidoProduto;
use App\Models\Produto;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Cache\LockProvider;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use RuntimeException;

class PedidoService
{
    /**
     * Valida os itens do pedido e calcula o valor total.
     *
     * @param array $itens Itens no formato [['produto_id' => 1, 'quantidade' => 2, 'observacao' => '...']]
     * @return array ['valor_total' => float, 'itens_verificados' => array]
     */
    public function validarItensECalcularTotal(array $itens): array
    {
        if (empty($itens)) {
            throw new InvalidArgumentException('O pedido deve conter pelo menos um item.');
        }

        $valorTotal = 0.00;
        $itensVerificados = [];

        foreach ($itens as $item) {
            $quantidade = (int) ($item['quantidade'] ?? 1);
            if ($quantidade <= 0) {
                throw new InvalidArgumentException('A quantidade de cada produto deve ser maior que zero.');
            }

            $produto = Produto::find($item['produto_id'] ?? null);
            if (!$produto) {
                throw new InvalidArgumentException("Produto ID {$item['produto_id']} não encontrado.");
            }

            if (!$produto->disponivel) {
                throw new InvalidArgumentException("Produto '{$produto->nome}' indisponível.");
            }

            $preco = (float) $produto->preco_atual;
            $valorTotal += $preco * $quantidade;

            $itensVerificados[] = [
                'produto' => $produto,
                'quantidade' => $quantidade,
                'preco_unitario' => $preco,
                'observacao' => $item['observacao'] ?? null,
            ];
        }

        return [
            'valor_total' => round($valorTotal, 2),
            'itens_verificados' => $itensVerificados,
        ];
    }

    /**
     * Executa a criação do pedido dentro de um lock de concorrência e transação atômica.
     * O callback de pagamento é executado DENTRO da transação, garantindo rollback automático caso a criação falhe.
     */
    public function criarPedidoTransacionado(
        callable $processadorPagamento,
        array $itensVerificados,
        float $valorTotal,
        string $momentoBebida = 'agora'
    ): Pedido {
        $senhaData = Carbon::today()->toDateString();

        $lockStore = Cache::store('database')->getStore();
        $lock = ($lockStore instanceof LockProvider)
            ? $lockStore->lock('pedido-senha-diaria:' . $senhaData, 120)
            : Cache::lock('pedido-senha-diaria:' . $senhaData, 120);

        return $lock->block(10, function () use (
            $processadorPagamento,
            $itensVerificados,
            $valorTotal,
            $momentoBebida,
            $senhaData
        ) {
            return DB::transaction(function () use (
                $processadorPagamento,
                $itensVerificados,
                $valorTotal,
                $momentoBebida,
                $senhaData
            ) {
                // 1. Executa o débito/pagamento dentro da transação para permitir rollback em caso de falha posterior
                $pagamento = $processadorPagamento();

                $user = $pagamento['user'];
                $formaPagamento = $pagamento['payment_method'];
                $saldoAnterior = (float) $pagamento['balance_before'];
                $saldoPosterior = (float) $pagamento['balance_after'];

                // 2. Calcula sequencial diário
                $ultimaSenha = Pedido::whereDate('created_at', $senhaData)->max('senha_diaria') ?? 0;

                // 3. Cria cabeçalho do Pedido
                $pedido = Pedido::create([
                    'user_id' => $user->id,
                    'valor_total' => $valorTotal,
                    'forma_pagamento' => $formaPagamento,
                    'senha_diaria' => $ultimaSenha + 1,
                    'status' => 'pendente',
                    'momento_bebida' => in_array($momentoBebida, ['agora', 'com_almoco']) ? $momentoBebida : 'agora',
                    'posicao_fila' => 0,
                    'codigo_retirada' => str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT),
                ]);

                // 4. Cria itens
                foreach ($itensVerificados as $item) {
                    PedidoProduto::create([
                        'pedido_id' => $pedido->id,
                        'produto_id' => $item['produto']->id,
                        'quantidade' => $item['quantidade'],
                        'preco_unitario' => $item['preco_unitario'],
                        'observacao' => $item['observacao'],
                        'entregue' => false,
                    ]);
                }

                // 5. Registra extrato na tabela movimentacoes
                Movimentacao::create([
                    'user_id' => $user->id,
                    'pedido_id' => $pedido->id,
                    'valor' => -$valorTotal,
                    'tipo' => $formaPagamento === 'credito' ? 'pedido_credito' : 'pedido',
                    'saldo_anterior' => $saldoAnterior,
                    'saldo_posterior' => $saldoPosterior,
                    'descricao' => "Pedido #{$pedido->senha_diaria} (" . ucfirst($formaPagamento) . ")",
                ]);

                return $pedido;
            });
        });
    }
}
