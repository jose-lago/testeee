<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProdutoController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PedidoController;
use App\Http\Controllers\MovimentacaoController;
use App\Http\Controllers\CreditoController;
use App\Http\Controllers\TotemController;
use App\Http\Controllers\ConfiguracaoController;

Route::post('/registrar', [AuthController::class, 'registrar']);
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/password/forgot', [AuthController::class, 'solicitarRecuperacaoSenha'])->middleware('throttle:5,1');
Route::post('/password/reset', [AuthController::class, 'redefinirSenha'])->middleware('throttle:10,1');

// TOTEM (Autoatendimento)
Route::middleware(['totem.device', 'throttle:60,1'])->group(function () {
    Route::get('/totem/produtos', [TotemController::class, 'produtos']);
    Route::get('/totem/usuario/{rfid}', [TotemController::class, 'usuarioPorRfid']);
    Route::post('/totem/pedidos/finalizar', [PedidoController::class, 'finalizar']);
});

// Qualquer user logado (Aluno e Admin)
Route::middleware('auth:sanctum')->group(function () {

    // Conta do usuário
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [UserController::class, 'me']);
    Route::post('/push-token', [UserController::class, 'salvarPushToken']);
    Route::delete('/push-token', [UserController::class, 'removerPushToken']);

    // Senha do cartão RFID (o próprio usuário define/troca pelo app)
    Route::post('/me/rfid/pin', [UserController::class, 'setRfidPin']);

    Route::get('/produtos', [ProdutoController::class, 'index']);
    Route::get('/produtos/{id}', [ProdutoController::class, 'show']);

    // PEDIDOS — Ações do Aluno (React Native)
    Route::post('/pedidos/criar',             [PedidoController::class, 'criar']);
    Route::get('/pedidos/meus',               [PedidoController::class, 'meusPedidos']);
    Route::get('/pedidos/{id}/status',        [PedidoController::class, 'statusPedido']);
    Route::post('/pedidos/{id}/cancelar',     [PedidoController::class, 'cancelar']);

    // MOVIMENTAÇÕES — Histórico do Aluno (React Native)
    Route::get('/movimentacoes/minhas',       [MovimentacaoController::class, 'minhas']);

    // CRÉDITO / FIADO — Ações do Aluno (React Native)
    Route::post('/credito/solicitar',         [CreditoController::class, 'solicitar']);
    Route::post('/credito/verificar',         [CreditoController::class, 'verificar']);
    Route::get('/credito/status',             [CreditoController::class, 'status']);

});

// Funcionário + Admin (operação da cantina / Kanban)
Route::middleware(['auth:sanctum', 'funcionario'])->group(function () {

    Route::get('/pedidos/fila',                   [PedidoController::class, 'fila']);
    Route::get('/pedidos/preparadores',           [PedidoController::class, 'preparadores']);
    Route::post('/pedidos/{id}/entregar-bebida',   [PedidoController::class, 'entregarBebida']);
    Route::post('/pedidos/{id}/preparar',          [PedidoController::class, 'preparar']);
    Route::post('/pedidos/{id}/pronto',            [PedidoController::class, 'pronto']);
    Route::post('/pedidos/{id}/entregar',          [PedidoController::class, 'entregar']);
    Route::post('/pedidos/{id}/entregar-proximo',  [PedidoController::class, 'entregarProximo']);
    Route::post('/pedidos/{id}/desfazer',          [PedidoController::class, 'desfazer']);

    // RFID management (staff)
    Route::post('/users/{id}/rfid/link', [UserController::class, 'linkRfid']);
    Route::post('/users/{id}/rfid/unlink', [UserController::class, 'unlinkRfid']);
    Route::post('/users/{id}/rfid/block', [UserController::class, 'blockRfid']);
    Route::post('/users/{id}/rfid/unblock', [UserController::class, 'unblockRfid']);

});

// Exige ser admin (Painel Refine)
Route::middleware(['auth:sanctum', 'admin'])->group(function () {

    // PRODUTOS (Escrita)
    Route::post('/produtos', [ProdutoController::class, 'store']);
    Route::put('/produtos/{id}', [ProdutoController::class, 'update']);
    Route::delete('/produtos/{id}', [ProdutoController::class, 'destroy']);

    // USUÁRIOS (CRUD Completo)
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'show']);
    Route::post('/users', [UserController::class, 'store']);
    Route::put('/users/{id}', [UserController::class, 'update']);
    Route::delete('/users/{id}', [UserController::class, 'destroy']);

    // RFID management (admin panel)
    Route::post('/users/{id}/rfid/link', [UserController::class, 'linkRfid']);
    Route::post('/users/{id}/rfid/unlink', [UserController::class, 'unlinkRfid']);
    Route::post('/users/{id}/rfid/block', [UserController::class, 'blockRfid']);
    Route::post('/users/{id}/rfid/unblock', [UserController::class, 'unblockRfid']);

    // PEDIDOS (CRUD Admin)
    Route::get('/pedidos',          [PedidoController::class, 'index']);
    Route::get('/pedidos/{id}',     [PedidoController::class, 'show']);
    Route::put('/pedidos/{id}',     [PedidoController::class, 'update']);
    Route::delete('/pedidos/{id}',  [PedidoController::class, 'destroy']);

    // MOVIMENTAÇÕES (Admin)
    Route::get('/movimentacoes',          [MovimentacaoController::class, 'index']);
    Route::get('/movimentacoes/{id}',     [MovimentacaoController::class, 'show']);
    Route::post('/movimentacoes/{id}/desfazer', [MovimentacaoController::class, 'desfazer']);

    // RECARGA DE SALDO (Admin)
    Route::post('/users/{id}/recarregar', [MovimentacaoController::class, 'recarregar']);

    // GESTÃO DE CRÉDITO & DEVEDORES (Admin)
    Route::get('/credito/devedores',          [CreditoController::class, 'devedores']);
    Route::post('/credito/pagar-divida',      [CreditoController::class, 'pagarDivida']);

    // CONFIGURAÇÕES DO SISTEMA (Admin) — liga/desliga Crédito / Fiado
    Route::get('/configuracoes/credito',  [ConfiguracaoController::class, 'getCreditoStatus']);
    Route::post('/configuracoes/credito', [ConfiguracaoController::class, 'setCreditoStatus']);
});
