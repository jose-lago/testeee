# Adição da Funcionalidade de Crédito (Fiado)

Abaixo está o panorama completo detalhando as alterações necessárias em cada parte do projeto (API, React Native e Painel Admin).

## Fluxo de Uso (Mermaid)

```mermaid
sequenceDiagram
    autonumber
    actor Aluno
    participant App as React Native (App)
    participant API as Laravel (API)
    participant Email as Servidor SMTP
    participant Painel as Refine (Admin)

    %% FLUXO DE ATIVAÇÃO
    rect rgb(30, 40, 50)
    Note over Aluno, Painel: Fluxo 1: Ativação do Crédito
    Aluno->>App: Clica em "Ativar Fiado" (Perfil)
    App->>Aluno: Pede CPF, RA, Telefone, Email Institucional
    Aluno->>App: Preenche dados e envia
    App->>API: POST /api/credito/solicitar
    API->>API: Valida domínio @unesp.br
    API->>Email: Dispara código OTP (4 a 6 dígitos)
    Email-->>Aluno: Recebe código
    Aluno->>App: Digita OTP e escolhe PIN (6 dígitos)
    App->>API: POST /api/credito/verificar
    API->>API: Valida OTP. Salva dados na tabela `user_creditos` (hash do PIN)
    API-->>App: Crédito Ativado com sucesso!
    end

    %% FLUXO DE COMPRA
    rect rgb(40, 30, 50)
    Note over Aluno, Painel: Fluxo 2: Comprando com Crédito
    Aluno->>App: Vai pro Carrinho e finaliza compra
    App->>Aluno: Forma de Pgto: "Saldo" ou "Crédito"
    Aluno->>App: Escolhe "Crédito"
    App->>Aluno: Pede PIN
    Aluno->>App: Digita PIN
    App->>API: POST /api/pedidos (forma=credito, pin=XXXXXX)
    API->>API: Verifica se `divida_atual` + `valor_pedido` <= Limite
    API->>API: Registra Pedido
    API->>API: Registra Movimentação (tipo=pedido_credito)
    API->>API: Aumenta `divida_atual` do aluno
    API-->>App: Pedido finalizado!
    end

    %% FLUXO DE PAGAMENTO DA DÍVIDA
    rect rgb(30, 50, 40)
    Note over Aluno, Painel: Fluxo 3: Pagamento no Balcão
    Aluno->>Painel: Vai ao balcão e paga em dinheiro/Pix
    Painel->>API: Acessa tela "Devedores"
    Painel->>API: POST /api/credito/pagar-divida (ID do Aluno, Valor)
    API->>API: Registra Movimentação (tipo=pagamento_credito)
    API->>API: Reduz `divida_atual` do aluno
    API-->>Painel: Baixa efetuada com sucesso
    end
```

## Proposed Changes (Panorama Técnico)

### 1. API Laravel (`src/API`)

**Banco de Dados:**
- **Nova Tabela `user_creditos`**: `id`, `user_id`, `cpf`, `ra`, `telefone`, `email_institucional`, `pin` (string/hash), `limite` (decimal, default: 50.00), `divida_atual` (decimal, default: 0.00), timestamps.
- **Tabela `movimentacoes`**: Atualizar enum `tipo` para suportar `pedido_credito` e `pagamento_credito`.

**Modelos (Models):**
- **UserCredito.php**: Modelo com propriedades _fillable_ (`user_id`, `cpf`, `ra`, `telefone`, `email_institucional`, `pin`, `limite`, `divida_atual`).
- **User.php**: Adicionar função `credito()` retornando `hasOne(UserCredito::class)`.

**Controladores e Rotas:**
- **`CreditoController`**:
  - `solicitar`: Gera um OTP de 6 dígitos temporário (pode salvar no cache/banco temporário associado ao email) e envia e-mail via SMTP com a _Mail facade_ do Laravel.
  - `verificar`: Recebe o OTP e os dados (telefone, cpf, ra, email, pin), valida o OTP e cria o registro na `user_creditos`.
  - `pagar_divida`: (Admin-only) Zera ou deduz a `divida_atual` e gera movimentação.
  - `devedores`: (Admin-only) Lista os usuários cujo `divida_atual > 0`.
- **`PedidoController`**:
  - Ajustar o método de criação de pedidos.
  - Adicionar novo campo no request: `forma_pagamento` (saldo ou credito) e `pin` (se for crédito).
  - Lógica: Se crédito, checa `Hash::check($request->pin, $user->credito->pin)`. Verifica `divida_atual + pedido_valor <= limite`. Adiciona valor na dívida, debita zero do saldo padrão. Registra movimentação do tipo `pedido_credito`.

---

### 2. Painel Admin Refine (`cantina-admin`)

**Nova Tela (Recurso `fiados` ou `devedores`):**
- **Listagem (`list.tsx`)**: Mostra todos os alunos que estão com `divida_atual > 0`.
  - Colunas: Nome do Aluno, RA, Email Institucional, Valor Devido, Limite Total.
- **Ações de Pagamento (`Baixa na Dívida`)**:
  - Na listagem de devedores, um botão "Registrar Pagamento".
  - Abre um modal para inserir o "Valor Pago" (caso ele pague parcial ou total).
  - Executa uma chamada à API customizada (`POST /api/credito/pagar-divida`) ou via `dataProvider.custom` do Refine.

**Navegação:**
- Atualizar o `App.tsx` injetando o novo _Resource_ para fiados no menu lateral, visível apenas para _Admins_.

---

### 3. Aplicativo React Native (`React Native`)

**Tela de Perfil (`PerfilScreen.js`)**:
- Adicionar um botão destacado: **"💳 Ativar Fiado"**.
- Se o fiado já estiver ativo, mostra: **"Fiado Ativo. Dívida Atual: R$ X,XX / Limite: R$ Y,YY"**.

**Nova Tela de Ativação (`AtivarCreditoScreen.js`)**:
- Passo 1: Formulário longo: CPF, RA, Telefone, Email Institucional. Dispara a API `/solicitar`.
- Passo 2: Digite o código OTP recebido por e-mail e crie o seu PIN de 6 dígitos (Input numérico mascarado).
- Botão Finalizar ativa a conta na API `/verificar`.

**Tela do Carrinho (`CarrinhoScreen.js`)**:
- Onde antes havia apenas "Finalizar Compra", deve ter um seletor visual:
  - 🔘 **Saldo na Conta** (R$ X,XX)
  - 🔘 **Fiado/Crédito** (Disponível: R$ Y,YY)
- Ao escolher crédito e clicar em confirmar: Surge um **Modal para digitar o PIN**.
- Só após inserir o PIN o pedido é processado enviando o PIN e o método para a API.

## Verification Plan

### Testes
- **Backend (SMTP)**: Garantir que emails estão sendo disparados (você precisará configurar seu `.env` do Laravel com suas chaves de SMTP reais: Mailtrap, Gmail, Brevo, etc.).
- **Backend (Validação)**: Tentativas de compras com PIN incorreto devem ser negadas com HTTP 403. Compras acima do limite devem ser negadas.
- **Painel Admin**: Abater a dívida deve gerar a movimentação corretamente no histórico do sistema para manter o caixa transparente.
