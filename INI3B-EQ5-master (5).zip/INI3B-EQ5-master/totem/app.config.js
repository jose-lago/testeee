const isEasBuild = Boolean(process.env.EAS_BUILD_PROFILE);

module.exports = ({ config }) => ({
	...config,
	android: {
		...config.android,
		usesCleartextTraffic:
			!isEasBuild && config.android.usesCleartextTraffic === true,
	},
});
