import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import TotemRFIDScreen from './src/screens/totem/TotemRFIDScreen';
import TotemProdutosScreen from './src/screens/totem/TotemProdutosScreen';
import TotemFinalizacaoScreen from './src/screens/totem/TotemFinalizacaoScreen';
import TotemSucessoScreen from './src/screens/totem/TotemSucessoScreen';

import { useTotemFonts } from './src/hooks/useTotemFonts';

import { navigationRef } from './src/services/navigationRef';

import TotemInactivityHandler, {
  triggerActivity,
} from './src/components/TotemInactivityHandler';

const Stack = createStackNavigator();

export default function App() {
  useTotemFonts();

  return (
    <TotemInactivityHandler timeoutMs={15000}>

      <NavigationContainer
        ref={navigationRef}
        onStateChange={() => triggerActivity()}
      >

        <Stack.Navigator
          initialRouteName="TotemProdutos"
          screenOptions={{
            headerShown: false,
          }}
        >

          <Stack.Screen
            name="TotemProdutos"
            component={TotemProdutosScreen}
          />

          <Stack.Screen
            name="TotemRFID"
            component={TotemRFIDScreen}
          />

          <Stack.Screen
            name="TotemFinalizacao"
            component={TotemFinalizacaoScreen}
          />

          <Stack.Screen
            name="TotemSucesso"
            component={TotemSucessoScreen}
          />

        </Stack.Navigator>

      </NavigationContainer>

    </TotemInactivityHandler>
  );
}