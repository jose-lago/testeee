export const typography = {
  fontHeading: 'Ahkio',             // Para títulos grandes ou informações em destaque
  fontBody: 'HammersmithOne',       // Para textos diversos
  fontFamily: 'HammersmithOne',     // Padrão geral
};

export default typography;
