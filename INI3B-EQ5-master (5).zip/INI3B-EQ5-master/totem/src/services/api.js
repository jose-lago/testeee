import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = (
  process.env.EXPO_PUBLIC_API_URL ||
  'http://127.0.0.1:8000/api'
).replace(/\/$/, '');

const TOTE_M_TOKEN = process.env.EXPO_PUBLIC_TOTEM_TOKEN || 'totem-dev-token';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// interceptor
api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('token');

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (!config.headers['X-Totem-Token']) {
      config.headers['X-Totem-Token'] = TOTE_M_TOKEN;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

export default api;