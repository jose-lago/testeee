import { createNavigationContainerRef } from '@react-navigation/native';

export const navigationRef =
  createNavigationContainerRef();

/*
 * Retorna para uma nova sessão limpa.
 *
 * A tela inicial agora é TotemProdutos,
 * pois o RFID só é solicitado no checkout.
 */
export function resetToInicio() {
  if (!navigationRef.isReady()) {
    return;
  }

  navigationRef.reset({
    index: 0,
    routes: [
      {
        name: 'TotemProdutos',
      },
    ],
  });
}