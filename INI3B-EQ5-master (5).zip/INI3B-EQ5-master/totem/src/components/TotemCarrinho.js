import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { typography } from '../tokens/typography';

export default function TotemCarrinho({
  carrinho,
  onAumentar,
  onDiminuir,
  onRemover,
  onFinalizar,
  onCancelar,
}) {
  const total = carrinho.reduce((soma, item) => {
    return soma + Number(item.preco_atual) * item.quantidade;
  }, 0);

  return (
    <View style={styles.container}>

      <View style={styles.cabecalho}>
        <Text style={styles.titulo}>
          Seu carrinho
        </Text>

        <Text style={styles.itens}>
          {carrinho.length} item(ns)
        </Text>
      </View>

      <ScrollView style={styles.lista}>

        {carrinho.length === 0 ? (
          <Text style={styles.vazio}>
            Seu carrinho está vazio.
          </Text>
        ) : (
          carrinho.map(item => (
            <View
              key={item.id}
              style={styles.item}
            >

              <View style={styles.itemInfo}>
                <Text style={styles.nome}>
                  {item.nome}
                </Text>

                <Text style={styles.preco}>
                  R$ {Number(item.preco_atual).toFixed(2)}
                </Text>
              </View>

              <View style={styles.controles}>

                <TouchableOpacity
                  onPress={() => onDiminuir(item.id)}
                  style={styles.controle}
                >
                  <Text style={styles.controleTexto}>
                    −
                  </Text>
                </TouchableOpacity>

                <Text style={styles.quantidade}>
                  {item.quantidade}
                </Text>

                <TouchableOpacity
                  onPress={() => onAumentar(item.id)}
                  style={styles.controle}
                >
                  <Text style={styles.controleTexto}>
                    +
                  </Text>
                </TouchableOpacity>

              </View>

              <TouchableOpacity
                onPress={() => onRemover(item.id)}
              >
                <Text style={styles.remover}>
                  Remover
                </Text>
              </TouchableOpacity>

            </View>
          ))
        )}

      </ScrollView>

      <View style={styles.resumo}>

        <View style={styles.linha}>
          <Text style={styles.subtotalTexto}>
            Subtotal
          </Text>

          <Text style={styles.subtotal}>
            R$ {total.toFixed(2)}
          </Text>
        </View>

        <View style={styles.linha}>
          <Text style={styles.totalTexto}>
            TOTAL
          </Text>

          <Text style={styles.total}>
            R$ {total.toFixed(2)}
          </Text>
        </View>

      </View>

      <TouchableOpacity
        style={[
          styles.finalizar,
          carrinho.length === 0 && styles.desabilitado,
        ]}
        disabled={carrinho.length === 0}
        onPress={onFinalizar}
      >
        <Text style={styles.finalizarTexto}>
          FINALIZAR PEDIDO
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.cancelar}
        onPress={onCancelar}
      >
        <Text style={styles.cancelarTexto}>
          CANCELAR
        </Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 380,
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderLeftWidth: 2,
    borderLeftColor: '#FDB368',
    padding: 20,
  },

  cabecalho: {
    borderBottomWidth: 1,
    borderBottomColor: '#DDD',
    paddingBottom: 12,
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 28,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  itens: {
    fontFamily: typography.fontBody,
    color: '#666',
    marginTop: 4,
  },

  lista: {
    flex: 1,
    marginTop: 10,
  },

  vazio: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    color: '#777',
    marginTop: 30,
  },

  item: {
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
    paddingVertical: 15,
  },

  itemInfo: {
    marginBottom: 8,
  },

  nome: {
    fontFamily: typography.fontHeading,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0F1A25',
  },

  preco: {
    fontFamily: typography.fontBody,
    marginTop: 3,
    color: '#555',
  },

  controles: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  controle: {
    width: 42,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#FDB368',
    alignItems: 'center',
    justifyContent: 'center',
  },

  controleTexto: {
    fontFamily: typography.fontBody,
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0F1A25',
  },

  quantidade: {
    fontFamily: typography.fontBody,
    width: 45,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },

  remover: {
    fontFamily: typography.fontBody,
    color: '#D32F2F',
    fontWeight: 'bold',
    marginTop: 8,
  },

  resumo: {
    borderTopWidth: 1,
    borderTopColor: '#DDD',
    paddingTop: 15,
  },

  linha: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },

  subtotalTexto: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#555',
  },

  subtotal: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#555',
  },

  totalTexto: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  total: {
    fontFamily: typography.fontHeading,
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FF7A00',
  },

  finalizar: {
    backgroundColor: '#FF7A00',
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
  },

  desabilitado: {
    backgroundColor: '#CCC',
  },

  finalizarTexto: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 17,
  },

  cancelar: {
    paddingVertical: 15,
    alignItems: 'center',
  },

  cancelarTexto: {
    fontFamily: typography.fontBody,
    color: '#D32F2F',
    fontWeight: 'bold',
    fontSize: 16,
  },
});