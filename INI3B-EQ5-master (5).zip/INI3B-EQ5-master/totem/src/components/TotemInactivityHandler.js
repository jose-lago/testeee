import React, {
  useEffect,
  useRef,
} from 'react';

import {
  View,
  PanResponder,
  Platform,
  StyleSheet,
} from 'react-native';

import { resetToInicio } from '../services/navigationRef';

let globalResetTimer = null;

export function triggerActivity() {
  if (globalResetTimer) {
    globalResetTimer();
  }
}

export default function TotemInactivityHandler({
  children,
  timeoutMs = 15000,
}) {
  const timerRef = useRef(null);

  const resetTimer = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    timerRef.current = setTimeout(() => {
      /*
       * RFID-08
       *
       * Após 15 segundos sem interação,
       * começa uma nova sessão.
       *
       * Como o carrinho fica dentro da tela
       * de produtos, o reset desmonta a tela
       * e elimina o carrinho.
       */
      resetToInicio();
    }, timeoutMs);
  };

  useEffect(() => {
    globalResetTimer = resetTimer;

    resetTimer();

    if (
      Platform.OS === 'web' &&
      typeof window !== 'undefined'
    ) {
      const events = [
        'mousedown',
        'mousemove',
        'keydown',
        'touchstart',
        'scroll',
        'pointerdown',
      ];

      const handleUserActivity = () => {
        /*
         * RFID-09
         *
         * Qualquer interação reinicia o timer.
         */
        resetTimer();
      };

      events.forEach(event => {
        window.addEventListener(
          event,
          handleUserActivity,
          { passive: true }
        );
      });

      return () => {
        globalResetTimer = null;

        if (timerRef.current) {
          clearTimeout(timerRef.current);
        }

        events.forEach(event => {
          window.removeEventListener(
            event,
            handleUserActivity
          );
        });
      };
    }

    return () => {
      globalResetTimer = null;

      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [timeoutMs]);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponderCapture: () => {
        resetTimer();
        return false;
      },

      onMoveShouldSetPanResponderCapture: () => {
        resetTimer();
        return false;
      },
    })
  ).current;

  return (
    <View
      style={styles.container}
      {...panResponder.panHandlers}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});