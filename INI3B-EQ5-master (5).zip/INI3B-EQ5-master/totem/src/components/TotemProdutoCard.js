import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { typography } from '../tokens/typography';

export default function TotemProdutoCard({
  produto,
  quantidade,
  onAumentar,
  onDiminuir,
  onAdicionar,
}) {
  const preco = Number(produto.preco_atual) || 0;
  const disponivel = Boolean(produto.disponivel);

  return (
    <View style={styles.card}>

      {produto.imagem_url ? (
        <Image
          source={{
            uri: produto.imagem_url,
            headers: {
              'Bypass-Tunnel-Reminder': 'true',
            },
          }}
          style={styles.imagem}
          resizeMode="cover"
        />
      ) : (
        <View style={styles.imagem}>
          <Text style={styles.semImagem}>
            Sem imagem
          </Text>
        </View>
      )}

      <View style={styles.conteudo}>

        <Text style={styles.nome}>
          {produto.nome}
        </Text>

        <Text style={styles.categoria}>
          {produto.categoria}
        </Text>

        <Text style={styles.preco}>
          R$ {preco.toFixed(2)}
        </Text>

        {!disponivel ? (
          <View style={styles.indisponivel}>
            <Text style={styles.textoIndisponivel}>
              INDISPONÍVEL
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.quantidadeContainer}>

              <TouchableOpacity
                style={styles.botaoQuantidade}
                onPress={onDiminuir}
              >
                <Text style={styles.textoQuantidade}>
                  −
                </Text>
              </TouchableOpacity>

              <Text style={styles.quantidade}>
                {quantidade}
              </Text>

              <TouchableOpacity
                style={styles.botaoQuantidade}
                onPress={onAumentar}
              >
                <Text style={styles.textoQuantidade}>
                  +
                </Text>
              </TouchableOpacity>

            </View>

            <TouchableOpacity
              style={styles.botaoAdicionar}
              onPress={onAdicionar}
            >
              <Text style={styles.textoAdicionar}>
                ADICIONAR
              </Text>
            </TouchableOpacity>
          </>
        )}

      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 300,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#FDB368',
    padding: 14,
    margin: 8,
  },

  imagem: {
    width: '100%',
    height: 150,
    borderRadius: 12,
    backgroundColor: '#FDB368',
    alignItems: 'center',
    justifyContent: 'center',
  },

  semImagem: {
    fontFamily: typography.fontBody,
    color: '#3E2723',
    fontWeight: 'bold',
  },

  conteudo: {
    paddingTop: 12,
  },

  nome: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0F1A25',
  },

  categoria: {
    fontFamily: typography.fontBody,
    marginTop: 4,
    fontSize: 14,
    color: '#666',
    textTransform: 'capitalize',
  },

  preco: {
    fontFamily: typography.fontHeading,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF7A00',
    marginTop: 8,
  },

  quantidadeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    backgroundColor: '#FDB368',
    borderRadius: 10,
  },

  botaoQuantidade: {
    width: 50,
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
  },

  textoQuantidade: {
    fontFamily: typography.fontBody,
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0F1A25',
  },

  quantidade: {
    fontFamily: typography.fontBody,
    fontSize: 20,
    fontWeight: 'bold',
    width: 50,
    textAlign: 'center',
    color: '#0F1A25',
  },

  botaoAdicionar: {
    backgroundColor: '#FF9430',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },

  textoAdicionar: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0F1A25',
  },

  indisponivel: {
    backgroundColor: '#D32F2F',
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 12,
    alignItems: 'center',
  },

  textoIndisponivel: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});