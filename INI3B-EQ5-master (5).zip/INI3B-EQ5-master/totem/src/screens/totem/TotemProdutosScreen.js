import React, { useEffect, useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Modal,
  useWindowDimensions,
} from 'react-native';

import api from '../../services/api';

import TotemProdutoCard from '../../components/TotemProdutoCard';
import TotemCarrinho from '../../components/TotemCarrinho';
import { typography } from '../../tokens/typography';

export default function TotemProdutosScreen({ navigation, route }) {
  const { height: windowHeight } = useWindowDimensions();
  const [produtos, setProdutos] = useState([]);
  const [categoria, setCategoria] = useState('todos');
  const [carrinho, setCarrinho] = useState(route.params?.carrinho || []);
  const [quantidades, setQuantidades] = useState({});
  const [carregando, setCarregando] = useState(true);
  const [erroProdutos, setErroProdutos] = useState(false);
  const [modalMomentoBebida, setModalMomentoBebida] = useState(false);

  useEffect(() => {
    carregarProdutos();
  }, []);

  async function carregarProdutos() {
    setCarregando(true);
    setErroProdutos(false);

    try {
      const response = await api.get('/totem/produtos');

      setProdutos(response.data);
    } catch (error) {
      console.log(
        'ERRO AO CARREGAR PRODUTOS:',
        error.response?.data || error.message
      );

      setErroProdutos(true);
    } finally {
      setCarregando(false);
    }
  }

  const categorias = [
    'todos',
    ...new Set(produtos.map(p => p.categoria)),
  ];

  const produtosFiltrados =
    categoria === 'todos'
      ? produtos
      : produtos.filter(
          p => p.categoria === categoria
        );

  /*
   * Quantidade selecionada no card.
   */
  function alterarQuantidadeProduto(id, delta) {
    setQuantidades(prev => {
      const atual = prev[id] || 1;
      const novaQuantidade = atual + delta;

      return {
        ...prev,
        [id]: novaQuantidade < 1 ? 1 : novaQuantidade,
      };
    });
  }

  /*
   * Adiciona produto ao carrinho.
   */
  function adicionarProduto(produto) {
    if (!produto.disponivel) {
      return;
    }

    const quantidadeSelecionada =
      quantidades[produto.id] || 1;

    setCarrinho(prev => {
      const existente = prev.find(
        item => item.id === produto.id
      );

      if (existente) {
        return prev.map(item =>
          item.id === produto.id
            ? {
                ...item,
                quantidade:
                  item.quantidade +
                  quantidadeSelecionada,
              }
            : item
        );
      }

      return [
        ...prev,
        {
          ...produto,
          quantidade: quantidadeSelecionada,
        },
      ];
    });

    setQuantidades(prev => ({
      ...prev,
      [produto.id]: 1,
    }));

    Alert.alert(
      'Produto adicionado',
      `${quantidadeSelecionada}x ${produto.nome} foi adicionado ao carrinho.`
    );

  }

  /*
   * Aumenta produto que já está no carrinho.
   */
  function aumentar(id) {
    setCarrinho(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              quantidade: item.quantidade + 1,
            }
          : item
      )
    );
  }

  /*
   * Diminui produto que já está no carrinho.
   */
  function diminuir(id) {
    setCarrinho(prev =>
      prev
        .map(item =>
          item.id === id
            ? {
                ...item,
                quantidade: item.quantidade - 1,
              }
            : item
        )
        .filter(item => item.quantidade > 0)
    );
  }

  /*
   * Remove completamente do carrinho.
   */
  function remover(id) {
    setCarrinho(prev =>
      prev.filter(item => item.id !== id)
    );
  }

  const temAlmoco = carrinho.some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('almoc') || cat.includes('almoç') || cat.includes('refeicao');
  });

  const temBebida = carrinho.some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('bebid');
  });

  /*
   * RFID-07
   *
   * O RFID só é solicitado no checkout.
   */
  function finalizar() {
    if (carrinho.length === 0) {
      Alert.alert(
        'Carrinho vazio',
        'Adicione pelo menos um produto.'
      );
      return;
    }

    if (temAlmoco && temBebida) {
      setModalMomentoBebida(true);
    } else {
      prosseguirParaCheckout(temBebida ? 'agora' : 'com_almoco');
    }
  }

  function prosseguirParaCheckout(momentoEscolhido) {
    setModalMomentoBebida(false);
    navigation.navigate('TotemRFID', {
      carrinho,
      momentoBebida: momentoEscolhido,
    });
  }

  /*
   * Cancela toda a sessão atual.
   *
   * O próximo cliente começa sem carrinho.
   */
  function cancelar() {
    setCarrinho([]);
    setQuantidades({});
    setModalMomentoBebida(false);

    navigation.replace('TotemProdutos');
  }

  return (
    <View
      style={[
        styles.container,
        { height: windowHeight, maxHeight: windowHeight },
      ]}
    >

      <View style={styles.conteudo}>

        <View style={styles.topo}>

          <View>
            <Text style={styles.titulo}>
              Escolha seus produtos
            </Text>

            <Text style={styles.subtitulo}>
              Monte seu pedido
            </Text>
          </View>

          <TouchableOpacity
            style={styles.botaoVoltar}
            onPress={cancelar}
          >
            <Text style={styles.botaoVoltarTexto}>
              NOVO CLIENTE
            </Text>
          </TouchableOpacity>

        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.categorias}
        >
          {categorias.map(cat => (
            <TouchableOpacity
              key={cat}
              style={[
                styles.categoriaBotao,
                categoria === cat &&
                  styles.categoriaSelecionada,
              ]}
              onPress={() => setCategoria(cat)}
            >
              <Text
                style={[
                  styles.categoriaTexto,
                  categoria === cat &&
                    styles.categoriaTextoSelecionado,
                ]}
              >
                {cat.toUpperCase()}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {carregando ? (
          <Text style={styles.carregando}>
            Carregando produtos...
          </Text>
        ) : erroProdutos ? (
          <View style={styles.estadoErro}>
            <Text style={styles.mensagemErro}>
              Não foi possível carregar os produtos.
            </Text>
            <TouchableOpacity
              style={styles.botaoTentarNovamente}
              onPress={carregarProdutos}
            >
              <Text style={styles.botaoTentarNovamenteTexto}>
                TENTAR NOVAMENTE
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <ScrollView
            style={styles.listaProdutos}
            contentContainerStyle={styles.produtos}
          >
            {produtosFiltrados.map(produto => (
              <TotemProdutoCard
                key={produto.id}
                produto={produto}
                quantidade={
                  quantidades[produto.id] || 1
                }
                onAumentar={() =>
                  alterarQuantidadeProduto(
                    produto.id,
                    1
                  )
                }
                onDiminuir={() =>
                  alterarQuantidadeProduto(
                    produto.id,
                    -1
                  )
                }
                onAdicionar={() =>
                  adicionarProduto(produto)
                }
              />
            ))}
          </ScrollView>
        )}

      </View>

      <TotemCarrinho
        carrinho={carrinho}
        onAumentar={aumentar}
        onDiminuir={diminuir}
        onRemover={remover}
        onFinalizar={finalizar}
        onCancelar={cancelar}
      />

      {/* Modal de Escolha do Momento da Bebida */}
      <Modal
        visible={modalMomentoBebida}
        transparent
        animationType="fade"
        onRequestClose={() => setModalMomentoBebida(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalIcone}>🥤 + 🍽️</Text>
            <Text style={styles.modalTitulo}>Como prefere sua bebida?</Text>
            <Text style={styles.modalSubtitulo}>
              Identificamos almoço e bebida no seu pedido. Escolha quando deseja receber sua bebida:
            </Text>

            <View style={styles.modalOpcoes}>
              <TouchableOpacity
                style={styles.modalBotaoOpcao}
                activeOpacity={0.85}
                onPress={() => prosseguirParaCheckout('agora')}
              >
                <Text style={styles.modalOpcaoIcone}>⚡</Text>
                <Text style={styles.modalOpcaoTitulo}>PEGAR BEBIDA AGORA</Text>
                <Text style={styles.modalOpcaoSub}>
                  Retirar no balcão imediatamente enquanto seu almoço é preparado.
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalBotaoOpcao, styles.modalBotaoOpcaoJunto]}
                activeOpacity={0.85}
                onPress={() => prosseguirParaCheckout('com_almoco')}
              >
                <Text style={styles.modalOpcaoIcone}>🍽️</Text>
                <Text style={styles.modalOpcaoTitulo}>JUNTO COM O ALMOÇO</Text>
                <Text style={styles.modalOpcaoSub}>
                  Sua bebida sairá na bandeja junto com o almoço quando o prato estiver pronto.
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.modalBotaoVoltar}
              onPress={() => setModalMomentoBebida(false)}
            >
              <Text style={styles.modalBotaoVoltarTexto}>VOLTAR AO CARDÁPIO</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#FFF8F0',
  },

  conteudo: {
    flex: 1,
    padding: 25,
  },

  topo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 34,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  subtitulo: {
    fontFamily: typography.fontBody,
    marginTop: 5,
    color: '#666',
  },

  botaoVoltar: {
    backgroundColor: '#D32F2F',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 10,
  },

  botaoVoltarTexto: {
    fontFamily: typography.fontBody,
    color: '#FFF',
    fontWeight: 'bold',
  },

  categorias: {
    marginVertical: 15,
    maxHeight: 55,
  },

  categoriaBotao: {
    backgroundColor: '#FDB368',
    paddingHorizontal: 20,
    paddingVertical: 13,
    borderRadius: 10,
    marginRight: 10,
  },

  categoriaSelecionada: {
    backgroundColor: '#FF7A00',
  },

  categoriaTexto: {
    fontFamily: typography.fontHeading,
    fontSize: 16,
    color: '#0F1A25',
    fontWeight: 'bold',
  },

  categoriaTextoSelecionado: {
    color: '#FFF',
  },

  /*
   * Sem flex:1 o ScrollView dimensiona pela altura do conteudo e
   * transborda o pai, ficando impossivel rolar. Com flex:1 ele ocupa
   * o espaco vertical restante (limitado pelo container com
   * height:'100%') e vira a area rolavel dos produtos.
   */
  listaProdutos: {
    flex: 1,
  },

  produtos: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'flex-start',
    paddingBottom: 30,
  },

  carregando: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    marginTop: 50,
    fontSize: 20,
    color: '#555',
  },

  estadoErro: {
    alignItems: 'center',
    marginTop: 50,
  },

  mensagemErro: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    fontSize: 20,
    color: '#8B1E1E',
  },

  botaoTentarNovamente: {
    backgroundColor: '#FF7A00',
    borderRadius: 10,
    marginTop: 18,
    paddingHorizontal: 20,
    paddingVertical: 13,
  },

  botaoTentarNovamenteTexto: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  modalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 35,
    width: '90%',
    maxWidth: 620,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FDB368',
    elevation: 8,
  },

  modalIcone: {
    fontSize: 44,
    marginBottom: 8,
  },

  modalTitulo: {
    fontFamily: typography.fontHeading,
    fontSize: 32,
    fontWeight: 'bold',
    color: '#3E2723',
    textAlign: 'center',
  },

  modalSubtitulo: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 25,
    lineHeight: 22,
  },

  modalOpcoes: {
    width: '100%',
    gap: 15,
    marginBottom: 20,
  },

  modalBotaoOpcao: {
    backgroundColor: '#E3F2FD',
    borderRadius: 16,
    padding: 20,
    borderWidth: 2,
    borderColor: '#1565C0',
    alignItems: 'center',
  },

  modalBotaoOpcaoJunto: {
    backgroundColor: '#FFF3E0',
    borderColor: '#FF7A00',
  },

  modalOpcaoIcone: {
    fontSize: 28,
    marginBottom: 4,
  },

  modalOpcaoTitulo: {
    fontFamily: typography.fontBody,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0F1A25',
    marginBottom: 4,
  },

  modalOpcaoSub: {
    fontFamily: typography.fontBody,
    fontSize: 13,
    color: '#555',
    textAlign: 'center',
    lineHeight: 18,
  },

  modalBotaoVoltar: {
    paddingVertical: 12,
    paddingHorizontal: 25,
  },

  modalBotaoVoltarTexto: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#888',
  },
});