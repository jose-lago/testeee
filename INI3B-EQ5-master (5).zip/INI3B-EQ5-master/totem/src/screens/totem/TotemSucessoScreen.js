import React, { useEffect } from 'react';

import {
  View,
  Text,
  StyleSheet,
} from 'react-native';
import { typography } from '../../tokens/typography';

export default function TotemSucessoScreen({
  navigation,
  route,
}) {
  const { pedido } = route.params;

  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('TotemProdutos');
    }, 10000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <View style={styles.check}>
          <Text style={styles.checkTexto}>
            ✓
          </Text>
        </View>

        <Text style={styles.titulo}>
          Pedido realizado!
        </Text>

        <Text style={styles.subtitulo}>
          Seu pedido foi enviado para a cantina.
        </Text>

        <Text style={styles.senhaTexto}>
          SUA SENHA
        </Text>

        <Text style={styles.senha}>
          #{pedido.senha_diaria}
        </Text>

        {pedido.codigo_retirada ? (
          <View style={styles.codigoBox}>
            <Text style={styles.codigoTextoLabel}>CÓDIGO DE RETIRADA</Text>
            <Text style={styles.codigoTexto}>{pedido.codigo_retirada}</Text>
            <Text style={styles.codigoSub}>Apresente este código no balcão</Text>
          </View>
        ) : null}

        {pedido.momento_bebida === 'agora' ? (
          <View style={styles.avisoBebidaAgora}>
            <Text style={styles.avisoBebidaTexto}>
              🥤 Você escolheu retirar sua bebida AGORA no balcão!
            </Text>
          </View>
        ) : pedido.momento_bebida === 'com_almoco' ? (
          <View style={styles.avisoBebidaJunto}>
            <Text style={styles.avisoBebidaTextoJunto}>
              🍽️ Sua bebida sairá na bandeja JUNTO com o almoço.
            </Text>
          </View>
        ) : null}

        <Text style={styles.rodape}>
          Aguarde ser chamado pelo painel ou atendente.
        </Text>

      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    justifyContent: 'center',
    alignItems: 'center',
  },

  card: {
    width: '75%',
    maxWidth: 650,
    backgroundColor: '#FFFFFF',
    borderRadius: 25,
    padding: 45,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FDB368',
  },

  check: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#2E7D32',
    justifyContent: 'center',
    alignItems: 'center',
  },

  checkTexto: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 60,
    fontWeight: 'bold',
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 38,
    fontWeight: 'bold',
    color: '#3E2723',
    marginTop: 25,
  },

  subtitulo: {
    fontFamily: typography.fontBody,
    fontSize: 18,
    color: '#555',
    marginTop: 10,
    textAlign: 'center',
  },

  senhaTexto: {
    fontFamily: typography.fontBody,
    marginTop: 30,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#555',
  },

  senha: {
    fontFamily: typography.fontHeading,
    fontSize: 64,
    fontWeight: 'bold',
    color: '#FF7A00',
    marginTop: 5,
  },

  rodape: {
    fontFamily: typography.fontBody,
    marginTop: 20,
    color: '#555',
    fontSize: 16,
  },

  codigoBox: {
    backgroundColor: '#FFF8F0',
    borderRadius: 14,
    borderWidth: 2,
    borderColor: '#FF7A00',
    borderStyle: 'dashed',
    paddingVertical: 12,
    paddingHorizontal: 25,
    alignItems: 'center',
    marginTop: 15,
  },

  codigoTextoLabel: {
    fontFamily: typography.fontBody,
    fontSize: 12,
    color: '#888',
    fontWeight: 'bold',
    letterSpacing: 1,
  },

  codigoTexto: {
    fontFamily: typography.fontHeading,
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FF7A00',
    letterSpacing: 4,
    marginVertical: 2,
  },

  codigoSub: {
    fontFamily: typography.fontBody,
    fontSize: 11,
    color: '#666',
  },

  avisoBebidaAgora: {
    backgroundColor: '#E3F2FD',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#1565C0',
    marginTop: 16,
    width: '100%',
  },

  avisoBebidaTexto: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0D47A1',
    textAlign: 'center',
  },

  avisoBebidaJunto: {
    backgroundColor: '#FFF3E0',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#FF7A00',
    marginTop: 16,
    width: '100%',
  },

  avisoBebidaTextoJunto: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#E65100',
    textAlign: 'center',
  },
});