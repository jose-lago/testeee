import React, { useEffect, useRef, useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Keyboard,
} from 'react-native';

import api from '../../services/api';
import { typography } from '../../tokens/typography';

export default function TotemRFIDScreen({
  navigation,
  route,
}) {
  const { carrinho = [], momentoBebida = 'agora' } = route.params || {};

  const [rfid, setRfid] = useState('');
  const [mensagem, setMensagem] = useState(
    'Aproxime seu cartão do leitor'
  );
  const [processando, setProcessando] = useState(false);

  const inputRef = useRef(null);

  /*
   * Mantém o campo preparado para receber
   * a leitura do RFID.
   */
  useEffect(() => {
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 300);

    return () => clearTimeout(timer);
  }, []);

  /*
   * RFID-01
   * RFID-12
   *
   * Processa somente quando o leitor envia ENTER.
   */
  async function processarRFID() {
    if (processando) {
      return;
    }

    const codigo = rfid.trim();

    /*
     * RFID-02
     *
     * Limpa o buffer imediatamente.
     */
    setRfid('');

    if (!codigo) {
      setMensagem('Aproxime um cartão válido.');
      inputRef.current?.focus();
      return;
    }

    if (carrinho.length === 0) {
      setMensagem(
        'O carrinho está vazio.'
      );
      return;
    }

    try {
      setProcessando(true);

      setMensagem('Verificando cartão...');

      Keyboard.dismiss();

      /*
       * RFID-03
       *
       * Consulta o cartão na API.
       */
      const response = await api.get(
        `/totem/usuario/${encodeURIComponent(codigo)}`
      );

      /*
       * O backend já confirmou que o cartão
       * existe e não está bloqueado.
       */
      console.log(
        'USUÁRIO RFID:',
        response.data
      );

      /*
       * RFID-03b: Sem PIN cadastrado — não pode pagar no totem.
       * Orienta o aluno a cadastrar a senha no app antes.
       */
      if (!response.data?.tem_pin_cadastrado) {
        setMensagem(
          'Você ainda não cadastrou a senha do cartão.\n' +
          'Abra o aplicativo: Perfil → Configurações da Conta → Senha do Cartão RFID.'
        );
        inputRef.current?.focus();
        return;
      }

      /*
       * RFID-03
       * RFID-07
       *
       * O RFID agora segue para o checkout.
       */
      navigation.replace('TotemFinalizacao', {
        rfidCode: codigo,
        carrinho,
        momentoBebida,
      });

    } catch (error) {
      console.log(
        'ERRO RFID:',
        error.response?.data || error.message
      );

      /*
       * RFID-04
       *
       * Cartão bloqueado.
       */
      if (error.response?.status === 403) {
        setMensagem(
          error.response?.data?.message ||
          'Cartão bloqueado.'
        );

      /*
       * RFID-05
       *
       * Cartão inexistente.
       */
      } else if (error.response?.status === 404) {
        setMensagem(
          error.response?.data?.message ||
          'Cartão não encontrado.'
        );

      } else {
        setMensagem(
          'Não foi possível verificar o cartão.'
        );
      }

      inputRef.current?.focus();

    } finally {
      setProcessando(false);
    }
  }

  /*
   * RFID-11
   *
   * Cancela a identificação temporária.
   *
   * O carrinho continua porque a identificação
   * ainda não foi concluída.
   */
  function cancelar() {
    setRfid('');

    navigation.replace('TotemProdutos', {
      carrinho,
    });
  }

  return (
    <View style={styles.container}>

      <View style={styles.logoContainer}>
        <Text style={styles.logo}>
          CANTINA
        </Text>

        <Text style={styles.subLogo}>
          TOTEM DE AUTOATENDIMENTO
        </Text>
      </View>

      <View style={styles.card}>

        <View style={styles.rfidIcon}>
          <Text style={styles.rfidIconText}>
            RFID
          </Text>
        </View>

        <Text style={styles.titulo}>
          Identificação
        </Text>

        <Text style={styles.instrucao}>
          Aproxime seu cartão RFID
        </Text>

        <Text style={styles.mensagem}>
          {mensagem}
        </Text>

        {/*
         * RFID-06
         *
         * Campo invisível.
         */}
        <TextInput
            ref={inputRef}
            value={rfid}
            onChangeText={setRfid}
            onSubmitEditing={processarRFID}
            placeholder="Digite o código do cartão"
            placeholderTextColor="#999"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.inputRFID}
        />

        <TouchableOpacity
          style={styles.botao}
          onPress={processarRFID}
          disabled={processando}
        >
          <Text style={styles.textoBotao}>
            {processando
              ? 'VERIFICANDO...'
              : 'CONTINUAR'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cancelar}
          onPress={cancelar}
          disabled={processando}
        >
          <Text style={styles.cancelarTexto}>
            CANCELAR
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.rodape}>
        O cartão será utilizado somente para finalizar o pedido
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },

  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },

  logo: {
    fontFamily: typography.fontHeading,
    fontSize: 42,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  subLogo: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF7A00',
    marginTop: 5,
  },

  card: {
    width: '80%',
    maxWidth: 650,
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 40,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FDB368',
  },

  rfidIcon: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: '#FDB368',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 25,
  },

  rfidIconText: {
    fontFamily: typography.fontHeading,
    fontSize: 26,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 38,
    fontWeight: 'bold',
    color: '#3E2723',
  },

  instrucao: {
    fontFamily: typography.fontHeading,
    fontSize: 26,
    fontWeight: 'bold',
    color: '#0F1A25',
    marginTop: 12,
    textAlign: 'center',
  },

  mensagem: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#666',
    marginTop: 10,
    marginBottom: 20,
    textAlign: 'center',
  },

  inputOculto: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
  },

  botao: {
    width: '100%',
    backgroundColor: '#FF7A00',
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 18,
  },

  textoBotao: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

  cancelar: {
    width: '100%',
    paddingVertical: 18,
    alignItems: 'center',
  },

  cancelarTexto: {
    fontFamily: typography.fontBody,
    color: '#D32F2F',
    fontSize: 17,
    fontWeight: 'bold',
  },

  rodape: {
    fontFamily: typography.fontBody,
    marginTop: 25,
    color: '#555',
    fontSize: 15,
    textAlign: 'center',
  },
});