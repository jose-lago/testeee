import React, { useRef, useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Platform,
} from 'react-native';

import api from '../../services/api';
import { typography } from '../../tokens/typography';

export default function TotemFinalizacaoScreen({
  navigation,
  route,
}) {
  const {
    rfidCode,
    carrinho = [],
    momentoBebida: momentoInicial = null,
  } = route.params || {};

  const temAlmoco = (carrinho || []).some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('almoc') || cat.includes('almoç') || cat.includes('refeicao');
  });

  const temBebida = (carrinho || []).some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('bebid');
  });

  const [momentoBebida, setMomentoBebida] = useState(
    momentoInicial || (temAlmoco && temBebida ? 'agora' : (temBebida ? 'agora' : 'com_almoco'))
  );
  const [metodo, setMetodo] = useState(null);
  const [pin, setPin] = useState('');
  const [erro, setErro] = useState('');
  const [processando, setProcessando] = useState(false);
  const envioEmAndamento = useRef(false);

  const total = carrinho.reduce(
    (soma, item) =>
      soma +
      Number(item.preco_atual) *
        item.quantidade,
    0
  );

  async function finalizarPedido() {
    if (envioEmAndamento.current) {
      return;
    }

    if (!metodo) {
      const mensagem = 'Selecione uma forma de pagamento.';
      if (Platform.OS === 'web') {
        setErro(mensagem);
      } else {
        Alert.alert('Pagamento', mensagem);
      }
      return;
    }

    if (!pin || pin.trim() === '') {
      const mensagem = 'Digite a senha do seu cartão RFID.';
      if (Platform.OS === 'web') {
        setErro(mensagem);
      } else {
        Alert.alert('Senha do Cartão', mensagem);
      }
      return;
    }

    try {
      setErro('');
      envioEmAndamento.current = true;
      setProcessando(true);

      const itens = carrinho.map(item => ({
        produto_id: item.id,
        quantidade: item.quantidade,
        observacao: null,
      }));

      const response = await api.post(
        '/totem/pedidos/finalizar',
        {
          rfid_code: rfidCode,
          forma_pagamento: metodo,
          pin: pin,
          momento_bebida: momentoBebida || (temBebida ? 'agora' : 'com_almoco'),
          itens,
        }
      );

      navigation.replace(
        'TotemSucesso',
        {
          pedido: response.data,
        }
      );

    } catch (error) {
      console.log(
        'ERRO TOTEM:',
        error.response?.data || error.message
      );

      const mensagem = error.response?.data?.message || 'Erro ao processar o pedido.';
      if (Platform.OS === 'web') {
        setErro(mensagem);
      } else {
        Alert.alert('Não foi possível finalizar', mensagem);
      }
    } finally {
      envioEmAndamento.current = false;
      setProcessando(false);
    }
  }

  function cancelar() {
    navigation.replace('TotemProdutos', {
      carrinho,
    });
  }

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <Text style={styles.titulo}>
          Confirmar pedido
        </Text>

        <Text style={styles.total}>
          R$ {total.toFixed(2)}
        </Text>

        {temAlmoco && temBebida && (
          <View style={styles.secaoBebida}>
            <Text style={styles.secaoBebidaTitulo}>
              🥤 Retirada da Bebida:
            </Text>
            <View style={styles.botoesBebida}>
              <TouchableOpacity
                style={[
                  styles.botaoBebida,
                  momentoBebida === 'agora' && styles.botaoBebidaAtivo,
                ]}
                onPress={() => setMomentoBebida('agora')}
                activeOpacity={0.8}
              >
                <Text
                  style={[
                    styles.textoBebida,
                    momentoBebida === 'agora' && styles.textoBebidaAtivo,
                  ]}
                >
                  ⚡ Pegar Agora
                </Text>
                <Text
                  style={[
                    styles.subtextoBebida,
                    momentoBebida === 'agora' && styles.subtextoBebidaAtivo,
                  ]}
                >
                  No balcão imediatamente
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.botaoBebida,
                  styles.botaoBebidaJunto,
                  momentoBebida === 'com_almoco' && styles.botaoBebidaJuntoAtivo,
                ]}
                onPress={() => setMomentoBebida('com_almoco')}
                activeOpacity={0.8}
              >
                <Text
                  style={[
                    styles.textoBebida,
                    momentoBebida === 'com_almoco' && styles.textoBebidaAtivo,
                  ]}
                >
                  🍽️ Junto c/ Almoço
                </Text>
                <Text
                  style={[
                    styles.subtextoBebida,
                    momentoBebida === 'com_almoco' && styles.subtextoBebidaAtivo,
                  ]}
                >
                  Na bandeja quando pronto
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <Text style={styles.subtitulo}>
          Escolha a forma de pagamento
        </Text>

        <TouchableOpacity
          style={[
            styles.pagamento,
            metodo === 'saldo' &&
              styles.pagamentoSelecionado,
          ]}
          onPress={() => {
            setMetodo('saldo');
            setErro('');
          }}
        >
          <Text style={styles.pagamentoTexto}>
            SALDO DA CONTA
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.pagamento,
            styles.credito,
            metodo === 'credito' &&
              styles.pagamentoCreditoSelecionado,
          ]}
          onPress={() => {
            setMetodo('credito');
            setErro('');
          }}
        >
          <Text style={styles.pagamentoTexto}>
            CRÉDITO
          </Text>
        </TouchableOpacity>

        {metodo && (
          <TextInput
            style={styles.pin}
            placeholder="Digite a senha do cartão RFID"
            placeholderTextColor="#999"
            keyboardType="numeric"
            secureTextEntry
            maxLength={6}
            value={pin}
            onChangeText={valor => {
              setPin(valor.replace(/\D/g, ''));
              setErro('');
            }}
            editable={!processando}
          />
        )}

        {erro ? (
          <Text style={styles.erro} accessibilityRole="alert">
            {erro}
          </Text>
        ) : null}

        <TouchableOpacity
          style={styles.finalizar}
          onPress={finalizarPedido}
          disabled={processando}
        >
          <Text style={styles.finalizarTexto}>
            {processando
              ? 'PROCESSANDO...'
              : 'CONFIRMAR PAGAMENTO'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cancelar}
          onPress={cancelar}
          disabled={processando}
        >
          <Text style={styles.cancelarTexto}>
            VOLTAR
          </Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },

  card: {
    width: '80%',
    maxWidth: 650,
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 35,
    borderWidth: 2,
    borderColor: '#FDB368',
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 34,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#3E2723',
  },

  total: {
    fontFamily: typography.fontHeading,
    fontSize: 42,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FF7A00',
    marginVertical: 20,
  },

  subtitulo: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    fontSize: 18,
    color: '#555',
    marginBottom: 20,
  },

  pagamento: {
    backgroundColor: '#2E7D32',
    paddingVertical: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },

  credito: {
    backgroundColor: '#1565C0',
  },

  pagamentoSelecionado: {
    borderWidth: 4,
    borderColor: '#3E2723',
  },

  pagamentoCreditoSelecionado: {
    borderWidth: 4,
    borderColor: '#3E2723',
  },

  pagamentoTexto: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

  pin: {
    fontFamily: typography.fontBody,
    height: 55,
    borderWidth: 1,
    borderColor: '#FDB368',
    borderRadius: 10,
    paddingHorizontal: 15,
    textAlign: 'center',
    fontSize: 20,
    marginBottom: 15,
  },

  erro: {
    fontFamily: typography.fontBody,
    color: '#B3261E',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 14,
  },

  finalizar: {
    backgroundColor: '#FF7A00',
    paddingVertical: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },

  finalizarTexto: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

  cancelar: {
    paddingVertical: 18,
    alignItems: 'center',
  },

  cancelarTexto: {
    fontFamily: typography.fontBody,
    color: '#D32F2F',
    fontSize: 17,
    fontWeight: 'bold',
  },

  secaoBebida: {
    backgroundColor: '#FFF8F0',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: '#FFE0B2',
    marginBottom: 20,
  },

  secaoBebidaTitulo: {
    fontFamily: typography.fontHeading,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#3E2723',
    textAlign: 'center',
    marginBottom: 10,
  },

  botoesBebida: {
    flexDirection: 'row',
    gap: 12,
  },

  botaoBebida: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#D9D9D9',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 8,
    alignItems: 'center',
  },

  botaoBebidaAtivo: {
    borderColor: '#1565C0',
    backgroundColor: '#E3F2FD',
  },

  botaoBebidaJunto: {
    borderColor: '#D9D9D9',
  },

  botaoBebidaJuntoAtivo: {
    borderColor: '#FF7A00',
    backgroundColor: '#FFF3E0',
  },

  textoBebida: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#666',
    textAlign: 'center',
  },

  textoBebidaAtivo: {
    color: '#0F1A25',
  },

  subtextoBebida: {
    fontFamily: typography.fontBody,
    fontSize: 11,
    color: '#888',
    textAlign: 'center',
    marginTop: 3,
  },

  subtextoBebidaAtivo: {
    color: '#333',
  },
});