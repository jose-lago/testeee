import { useState, useEffect } from 'react';
import { Text, TextInput } from 'react-native';
import * as Font from 'expo-font';

export function useTotemFonts() {
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    async function loadFonts() {
      try {
        await Font.loadAsync({
          Ahkio: require('../../assets/fonts/Ahkio.ttf'),
          HammersmithOne: require('../../assets/fonts/HammersmithOne-Regular.ttf'),
        });

        if (Text.defaultProps == null) Text.defaultProps = {};
        Text.defaultProps.style = [{ fontFamily: 'HammersmithOne' }, Text.defaultProps.style];

        if (TextInput.defaultProps == null) TextInput.defaultProps = {};
        TextInput.defaultProps.style = [{ fontFamily: 'HammersmithOne' }, TextInput.defaultProps.style];
      } catch (e) {
        console.warn('Erro ao carregar fontes customizadas no Totem:', e);
      } finally {
        setFontsLoaded(true);
      }
    }
    loadFonts();
  }, []);

  return fontsLoaded;
}
