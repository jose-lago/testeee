# Totem

## RFID em desenvolvimento

Sem leitor físico, use a tela de identificação: digite o valor cadastrado em `users.rfid_code` e pressione ENTER. O campo também pode receber a saída de um leitor que funcione como teclado e finalize a leitura com ENTER.

O app remove espaços no início e no fim (`trim()`), rejeita entrada vazia e envia qualquer outro texto à API para consulta. Não há tamanho, alfabeto ou padrão fixo de RFID definido pelo app; um valor só identifica um usuário se corresponder ao `rfid_code` cadastrado. Um valor sem correspondência é tratado como cartão não encontrado. Cartões bloqueados e usuários inativos são recusados pela API. Após uma falha, o campo é limpo e pode receber outra tentativa.

Para simular os cenários, use valores de teste existentes no banco local: um RFID válido, um valor que não esteja cadastrado, um RFID associado a cartão bloqueado e um RFID associado a usuário inativo. ENTER inicia cada consulta. Não use dados de produção para esses testes.

A simulação valida a entrada de texto e o fluxo de software. Não valida leitura elétrica, protocolo, codificação ou comportamento do leitor/cartão físico.

## Configuração local

Copie `.env.example` para `.env` e configure `EXPO_PUBLIC_API_URL` com a URL alcançável da API, incluindo o sufixo `/api`. `EXPO_PUBLIC_TOTEM_TOKEN` deve corresponder a `TICKET_TOTEM_TOKEN` configurado na API. Os valores do exemplo são somente para desenvolvimento local; não coloque tokens de produção no repositório.

### Iniciar a API e o Totem

Em um terminal, inicie o Laravel:

```powershell
cd src/API
php artisan serve --host=0.0.0.0 --port=8000
```

Em outro terminal, configure e inicie o Totem:

```powershell
cd totem
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
npm start
```

No PC e no Expo Web, `http://127.0.0.1:8000/api` aponta para a API local. Em um celular físico, `127.0.0.1` aponta para o próprio celular: informe em `EXPO_PUBLIC_API_URL` o IP real do PC na rede, no formato `http://IP_REAL_DO_PC:8000/api`, e permita a conexão na rede/firewall. Não há IP de dispositivo versionado. Reinicie o Expo depois de mudar `.env`.

`EXPO_PUBLIC_TOTEM_TOKEN` deve ser igual a `TICKET_TOTEM_TOKEN` no `.env` da API. O valor `totem-dev-token` é somente de desenvolvimento; forneça o token apropriado no ambiente de build e não versione segredos.

O campo de RFID aceita digitação manual: use um código RFID de teste cadastrado e pressione ENTER. Isso exercita o fluxo do simulador sem cartão ou leitor físico; para testar o hardware, o leitor deve enviar o código como teclado e finalizar com ENTER.

Para um APK, configure `EXPO_PUBLIC_API_URL` com uma URL HTTPS alcançável pelo dispositivo e `EXPO_PUBLIC_TOTEM_TOKEN` no ambiente de build. O perfil EAS `preview` está configurado para distribuição interna em formato APK.

## Assets e identidade

Os quatro assets referenciados em `app.json` existem em `assets/`: `icon.png`, `splash-icon.png`, `adaptive-icon.png` e `favicon.png`. Ícone, splash e adaptive icon são usados na configuração do app; o favicon é usado no Expo Web. Os arquivos foram reaproveitados de `React-Native/assets/`; nenhum asset foi inventado.

O package Android permanece `com.saulopereira.saviore`, o nome exibido é `Saviore Totem` e a versão é `1.0.0`, em orientação retrato. O slug atual (`snack-...`) é gerado e genérico. Como `owner` e `extra.eas.projectId` já estão informados e são compartilhados com o app do aluno, não é seguro trocar o slug ou o projeto sem confirmar o vínculo remoto com a conta EAS; a identidade EAS própria do Totem fica pendente dessa confirmação.

## Google Services / push

O Totem não chama APIs de notificações ou push no código (`totem/src` e `totem/App.js`). O pacote/plugin `expo-notifications` e a permissão Android ainda estão configurados, mas não há `android.googleServicesFile` no `app.json` nem `google-services.json` no projeto. Esse arquivo não é necessário para o build atual sem push remoto; seria necessário fornecer o arquivo Firebase real caso uma integração de push remoto seja implementada.

Se o Totem passar a precisar de push, o arquivo `google-services.json` real do Firebase (projeto `saviore-54aa8`, package `com.saulopereira.saviore`) precisa ser fornecido e a chave `googleServicesFile` recolocada no `app.json`.

## Build de APK (EAS)

`eas.json` já tem o perfil `preview` com `distribution: internal` e `android.buildType: apk`, que é o perfil para gerar APK instalável:

```bash
cd totem
npx eas-cli build --profile preview --platform android
```

Pré-requisitos externos: conta EAS autenticada e projeto EAS correto; credenciais de build (keystore) ou JDK + Android SDK se o build for local. Nenhum APK foi gerado nesta validação. Antes do build, configure no ambiente `EXPO_PUBLIC_API_URL` (URL acessível pelo dispositivo, sempre HTTPS) e `EXPO_PUBLIC_TOTEM_TOKEN` (igual ao `TICKET_TOTEM_TOKEN` da API).

Para visão geral, instalação e testes do projeto, consulte o [README principal](../README.md). Este arquivo cobre a configuração específica do Totem.

`android.usesCleartextTraffic` é mantido para desenvolvimento local com API HTTP. O `app.config.js` o desativa quando `EAS_BUILD_PROFILE` está definido, portanto o APK EAS deve usar uma API HTTPS.

Variáveis `EXPO_PUBLIC_*` são incorporadas ao bundle/APK. Portanto, `EXPO_PUBLIC_TOTEM_TOKEN` pode ser extraído do aplicativo e não deve ser tratado como segredo forte em produção.

