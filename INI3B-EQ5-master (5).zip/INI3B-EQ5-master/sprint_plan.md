# Divisão Refinada de Tarefas & Pesos (Sprint 14 Dias - Funcionalidade de Crédito)

As tarefas de **QA puro do Dev 6 foram eliminadas por enquanto** e o **Dev 6 passou a atuar diretamente no Backend**, dividindo as tarefas pesadas de banco e checkout que antes eram exclusivas do **Dev 1**.

---

## 📊 Nova Distribuição de Pesos e Responsabilidades (6 Devs)

| Membro | Papel | Parte do Plano onde Atuará | Complexidade | Peso (% Esforço) |
| :--- | :--- | :--- | :---: | :---: |
| **Dev 1** | Backend DB & Models | `API Laravel -> Migrations, Models e Relacionamentos` | **Média-Alta** | **18%** |
| **Dev 2** | Backend OTP & Email | `API Laravel -> CreditoController, SMTP e Email Mailable` | **Alta** | **20%** |
| **Dev 3** | Mobile App (Ativação) | `React Native -> PerfilScreen e AtivarCreditoScreen` | **Média-Alta** | **18%** |
| **Dev 4** | Mobile App (Checkout & PIN) | `React Native -> CarrinhoScreen e Modal do PIN` | **Média** | **16%** |
| **Dev 5** | Web Admin (Devedores) | `Painel Refine -> Recurso Devedores e Quitação` | **Média** | **14%** |
| **Dev 6** | Backend Checkout & Trava R$ 50 | `API Laravel -> PedidoController, DB Transaction e Validação PIN` | **Média-Alta** | **14%** |

---

## 👤 Detalhamento Ajustado por Membro

### 🔨 Dev 1: Backend Engineer (Banco de Dados, Migrations e Models)
* **Atuação no Plano**: `1. Banco de Dados & Laravel -> Migrations, Models e Relacionamento de Crédito`
* **Complexidade**: **Média-Alta**
* **Tarefas Detalhadas**:
  1. **Migration `user_creditos`**:
     - Criar tabela com: `id`, `user_id` (FK), `cpf`, `ra`, `telefone`, `email_institucional`, `pin` (hash), `limite` (decimal 8,2, default 50.00), `divida_atual` (decimal 8,2, default 0.00), `verificado` (boolean).
  2. **Migration de `movimentacoes`**:
     - Expandir a coluna de tipo enum para aceitar `'pedido_credito'` e `'pagamento_credito'`.
  3. **Models & Estrutura Eloquent**:
     - Criar `UserCredito.php` com propriedades `$fillable` e conversões de tipo `$casts`.
     - Atualizar `User.php` injetando a relação `hasOne(UserCredito::class)`.
     - Atualizar o model `Movimentacao.php` para tratar os novos tipos.
  4. **Endpoint de Status**:
     - Criar a rota/método `GET /api/credito/status` que retorna se a conta tem fiado ativo, limite restante e valor da dívida atual.

---

### ✉️ Dev 2: Backend Engineer (Servidor SMTP, Autenticação OTP e Controller de Crédito)
* **Atuação no Plano**: `1. Banco de Dados & Laravel -> CreditoController e Email OTP`
* **Complexidade**: **Alta**
* **Tarefas Detalhadas**:
  1. **Configuração do SMTP**:
     - Configurar `config/mail.php` e `.env` com as chaves reais de SMTP.
     - Criar a classe Mailable `EnviarCodigoOtpMail.php` com template HTML formatado.
  2. **Criação do `CreditoController.php`**:
     - **Endpoint `POST /api/credito/solicitar`**: Valida o sufixo `@unesp.br`, gera código OTP de 6 dígitos e envia por e-mail via SMTP.
     - **Endpoint `POST /api/credito/verificar`**: Valida o OTP, salva CPF/RA/Telefone e grava o hash do PIN na tabela `user_creditos`.
     - **Endpoint `POST /api/credito/pagar-divida` (Admin-only)**: Abate valor na `divida_atual` e grava a movimentação `pagamento_credito`.
     - **Endpoint `GET /api/credito/devedores` (Admin-only)**: Lista alunos inadimplentes (`divida_atual > 0`).

---

### 📱 Dev 3: Mobile Developer 1 (React Native - Perfil e Ativação Multi-etapas)
* **Atuação no Plano**: `2. React Native -> PerfilScreen.js e AtivarCreditoScreen.js`
* **Complexidade**: **Média-Alta**
* **Tarefas Detalhadas**:
  1. **Atualização da `PerfilScreen.js`**:
     - Exibir card com status do crédito (Inativo, Pendente, Ativo) e botão **"💳 Ativar Fiado Cantina"**.
  2. **Criação da Tela `AtivarCreditoScreen.js` (Multi-etapas)**:
     - **Passo 1**: Formulário com CPF, RA, Telefone e Email Institucional (`@unesp.br`).
     - **Passo 2**: Digitação do OTP de 6 dígitos enviado por e-mail.
     - **Passo 3**: Digitação e confirmação do PIN numérico de 6 dígitos.
  3. **Integração `api.js`**: Conectar formulários aos endpoints `/solicitar` e `/verificar`.

---

### 🛒 Dev 4: Mobile Developer 2 (React Native - Seletor do Carrinho e Modal do PIN)
* **Atuação no Plano**: `2. React Native -> CarrinhoScreen.js e Modal do PIN`
* **Complexidade**: **Média**
* **Tarefas Detalhadas**:
  1. **Atualização da `CarrinhoScreen.js`**:
     - Adicionar seletor visual: 🔘 Saldo em Conta vs 🔘 Crédito / Fiado.
  2. **Componente `ModalPinCredito.js`**:
     - Modal exibido ao escolher "Crédito" que exige o PIN de 6 dígitos antes de finalizar.
  3. **Tratamento de Alertas e Erros**:
     - Exibir avisos amigáveis caso o PIN esteja errado ou a compra exceda o limite de R$ 50,00.

---

### 🖥️ Dev 5: Web Admin Developer (Refine - Listagem de Devedores e Quitação)
* **Atuação no Plano**: `3. Painel de Administração -> Recurso Devedores e App.tsx`
* **Complexidade**: **Média**
* **Tarefas Detalhadas**:
  1. **Navegação no `App.tsx`**: Registrar novo recurso `<Resource name="devedores" ... />`.
  2. **Tela de Listagem (`src/pages/fiados/list.tsx`)**: Tabela responsiva com dados dos alunos inadimplentes (Nome, RA, Telefone, Dívida).
  3. **Modal `RegistrarPagamentoModal.tsx`**: Modal para dar baixa na dívida informando o valor pago em dinheiro no balcão e disparando `POST /api/credito/pagar-divida`.

---

### ⚡ Dev 6: Backend Engineer (Regras de Checkout no Pedido, Trava de R$ 50 e Validação PIN)
* **Atuação no Plano**: `1. Banco de Dados & Laravel -> PedidoController, Validação de PIN e Transação Bancária`
* **Complexidade**: **Média-Alta**
* **Tarefas Detalhadas**:
  1. **Modificação em `PedidoController::store`**: Tratar `forma_pagamento = 'credito'`.
  2. **Validação do PIN**: Conferir o PIN enviado via `Hash::check($request->pin, $user->credito->pin)`.
  3. **Trava de Limite em `DB::transaction`**:
     - Garantir que `(divida_atual + valor_pedido) <= 50.00`.
     - Incrementar `divida_atual` e gravar movimentação do tipo `pedido_credito`.

---

## 📅 Cronograma da Sprint (14 Dias)

```mermaid
gantt
    title Cronograma Atualizado da Sprint (14 dias - 6 Devs)
    dateFormat  YYYY-MM-DD
    axisFormat %d/%m

    section Backend
    Dev 1: Migrations & Models        :active, b1, 2026-08-01, 3d
    Dev 2: SMTP & Endpoints Credito    :active, b2, 2026-08-01, 4d
    Dev 6: Logica de Checkout Pedido   :active, b6, 2026-08-04, 4d

    section Mobile App
    Dev 3: Perfil & AtivarCredito      :m3, 2026-08-04, 5d
    Dev 4: Carrinho & Modal PIN        :m4, 2026-08-04, 5d

    section Web Admin
    Dev 5: Admin Devedores & Baixa     :w5, 2026-08-04, 5d

    section Integracoes & Testes
    Todos Devs: Testes Integrados      :t1, 2026-08-10, 4d
    Todos Devs: Ajustes & Homologacao  :t2, 2026-08-14, 1d
```

---

## 📌 RESUMO EXECUTIVO DE TAREFAS POR DEV (CHECKLIST FINAL)

### 🟢 DEV 1 (Backend - Infraestrutura de Banco)
- [ ] Criar migration `user_creditos` (CPF, RA, Telefone, Email Institucional, PIN Hash, Limite 50.00, Dívida Atual).
- [ ] Modificar migration `movimentacoes` adicionando os tipos `'pedido_credito'` e `'pagamento_credito'`.
- [ ] Criar model `UserCredito.php` e incluir relacionamento `hasOne` no `User.php`.
- [ ] Criar endpoint `GET /api/credito/status` para retornar limite e dívida atual do aluno.

### 🔵 DEV 2 (Backend - SMTP Real, OTP & Endpoints)
- [ ] Configurar servidor SMTP em `config/mail.php` e `.env` e criar a classe Mailable do e-mail OTP.
- [ ] Criar endpoint `POST /api/credito/solicitar` (Valida `@unesp.br`, gera OTP e envia e-mail).
- [ ] Criar endpoint `POST /api/credito/verificar` (Valida OTP, grava dados e hash do PIN de 6 dígitos).
- [ ] Criar endpoints de Admin: `GET /api/credito/devedores` e `POST /api/credito/pagar-divida`.

### 🟡 DEV 3 (Mobile RN - Perfil & Fluxo de Ativação)
- [ ] Atualizar `PerfilScreen.js` com o card indicativo do fiado e botão de ativação.
- [ ] Criar a tela multi-step `AtivarCreditoScreen.js` (Formulário -> Input do OTP de 6 dígitos -> Criação do PIN).
- [ ] Conectar as telas com o serviço de API (`/solicitar` e `/verificar`).

### 🟣 DEV 4 (Mobile RN - Carrinho & Modal do PIN)
- [ ] Atualizar `CarrinhoScreen.js` adicionando o seletor de forma de pagamento (Saldo vs Crédito).
- [ ] Criar o componente `ModalPinCredito.js` para exigir o PIN de 6 dígitos ao selecionar crédito.
- [ ] Tratar alertas visuais para erros de PIN incorreto ou limite estourado na tela do carrinho.

### 🔴 DEV 5 (Web Admin Refine - Gestão de Devedores)
- [ ] Registrar a rota/recurso `devedores` no `App.tsx` do Refine.
- [ ] Desenvolver a tela de listagem `src/pages/fiados/list.tsx` com tabela Ant Design.
- [ ] Desenvolver o modal de quitação de dívida `RegistrarPagamentoModal.tsx` enviando `POST /api/credito/pagar-divida`.

### 🟠 DEV 6 (Backend - Checkout, Trava de R$ 50 & Validação de PIN)
- [ ] Modificar `PedidoController::store` para aceitar `forma_pagamento = 'credito'` e `pin`.
- [ ] Implementar verificação do PIN usando `Hash::check`.
- [ ] Criar trava transacional em `DB::transaction` impedindo compras onde `(divida_atual + valor_pedido) > 50.00`.
- [ ] Gravar movimentação de débito em `movimentacoes` com o tipo `pedido_credito`.
