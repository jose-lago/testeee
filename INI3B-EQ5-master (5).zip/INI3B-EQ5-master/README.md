# Saviore

Sistema de cantina (TCC) composto por quatro aplicações que compartilham uma única API:

- **API Laravel** (`src/API`) — regras de negócio, banco de dados, autenticação e integrações.
- **Aplicativo do aluno** (`React-Native`) — Expo / React Native.
- **Totem de autoatendimento** (`totem`) — Expo / React Native (produtos, carrinho, cartão RFID e pagamento).
- **Painel administrativo** (`cantina-admin`) — Vite + React + Refine + Ant Design.

Referência de design: [docs/DESIGN_SYSTEM_TCC.md](docs/DESIGN_SYSTEM_TCC.md).

## Estrutura do repositório

| Caminho | Conteúdo |
| --- | --- |
| `src/API/` | API Laravel (Laravel 13, PHP 8.3+, Sanctum, PostgreSQL) |
| `React-Native/` | Aplicativo do aluno (Expo SDK 54, React Native 0.81) |
| `totem/` | Totem de autoatendimento (Expo SDK 54) |
| `cantina-admin/` | Painel administrativo (Refine + Ant Design) |
| `docs/` | Manuais e documentação do TCC |
| `sprints/`, `hub/`, `gestao/` | Materiais de gestão do TCC (não são código executável) |

## Requisitos

- PHP **8.3+** com extensões padrão do Laravel (validado com PHP 8.5)
- Composer 2.x
- **PostgreSQL** (a API usa `DB_CONNECTION=pgsql`, banco `Cantina` por padrão)
- Node.js + npm (aplicativos Expo e painel admin)
- Para build/instalação em aparelho: conta EAS ou JDK + Android SDK (opcional)

## Banco de dados

Exemplo de configuração local: PostgreSQL em `localhost:5432`, base `Cantina`. Configure usuário e senha somente no `src/API/.env` local; não versione credenciais. Crie a base antes de migrar:

```sql
CREATE DATABASE "Cantina";
```

A aplicação **não** usa dados de produção neste repositório. Os testes automatizados usam SQLite em memória (`src/API/phpunit.xml`), sem tocar no PostgreSQL.

## API (backend Laravel)

```bash
cd src/API
composer install
cp .env.example .env          # Windows: copy .env.example .env
php artisan key:generate
php artisan migrate           # cria as tabelas
php artisan serve             # http://127.0.0.1:8000
```

No `src/API/.env`, `TICKET_TOTEM_TOKEN` é o token que autoriza os totens. Ele precisa ser igual ao `EXPO_PUBLIC_TOTEM_TOKEN` configurado no app do Totem.

Scripts já existentes em `src/API/composer.json`:

- `composer setup` — instala dependências, cria `.env`, gera a `APP_KEY`, migra e roda `npm install` + `npm run build`;
- `composer dev` — sobe `php artisan serve`, `queue:listen`, `pail` e o Vite em conjunto;
- `composer test` — `php artisan config:clear` + `php artisan test`.

### Usuário administrador

O seeder padrão (`DatabaseSeeder`) cria apenas o usuário de exemplo `test@example.com`, **não** cria administrador. Fluxo operacional confirmado no código: cadastre um usuário (app ou `POST /api/registrar`) e depois promova-o:

```bash
cd src/API
php artisan tinker
>>> App\Models\User::where('email', 'seu-email@exemplo.com')->update(['tipo' => 'admin']);
```

O painel admin e as rotas administrativas exigem `tipo = 'admin'` (middleware `admin`).

### Testes

```bash
cd src/API
php artisan test          # ou: composer test
```

Estado atual: **41 testes / 237 assertions, todos passando** (SQLite em memória).

## Aplicativo do aluno (`React-Native`)

```bash
cd React-Native
npm install
npm start                 # Expo; use "w" para web, "a" para Android
```

Scripts reais: `start`, `android`, `ios`, `web`. Copie `.env.example` para `.env` e ajuste `EXPO_PUBLIC_API_URL` (ver [Variáveis de ambiente](#variáveis-de-ambiente)).

## Totem (`totem`)

```bash
cd totem
npm install
npm start
```

Scripts reais: `start`, `android`, `ios`, `web`. Configure `.env` (copiado de `.env.example`) com `EXPO_PUBLIC_API_URL` e `EXPO_PUBLIC_TOTEM_TOKEN`. Detalhes de RFID e build em [totem/README.md](totem/README.md).

## Painel administrativo (`cantina-admin`)

```bash
cd cantina-admin
npm install
npm run dev
```

Scripts reais: `dev`, `build`, `start`, `refine`. Requer `cantina-admin/.env.local` com `VITE_API_URL` (padrão de desenvolvimento: `http://127.0.0.1:8000/api`). O `vite.config.ts` publica em `base: "/2457003/admin/"`.

## Variáveis de ambiente

| Aplicação | Arquivo | Variáveis | Observação |
| --- | --- | --- | --- |
| API | `src/API/.env` | `APP_*`, `DB_*`, `TICKET_TOTEM_TOKEN` | `DB_CONNECTION=pgsql`; token precisa casar com o Totem |
| App do aluno | `React-Native/.env` | `EXPO_PUBLIC_API_URL` | Sem a variável o app usa `http://127.0.0.1:8000/api` |
| Totem | `totem/.env` | `EXPO_PUBLIC_API_URL`, `EXPO_PUBLIC_TOTEM_TOKEN` | Token igual a `TICKET_TOTEM_TOKEN` |
| Painel admin | `cantina-admin/.env.local` | `VITE_API_URL` | Padrão `http://127.0.0.1:8000/api` |

Cenários de URL da API:

1. **Mesmo computador (desenvolvimento)** — `http://127.0.0.1:8000/api` funciona no navegador (Expo Web) e em emulador com `adb reverse`.
2. **Dispositivo físico** — é necessário o endereço da máquina que roda a API, alcançável pelo aparelho (`http://SEU_HOST:8000/api`) ou uma URL HTTPS terminando em `/api`. Esse endereço **não** está definido no repositório: precisa ser informado por você no ambiente de build. Não use IP inventado nem HTTPS falso.
3. **Produção** — sempre HTTPS (ex.: `https://SEU_DOMINIO/api`).

`totem/app.json` mantém `android.usesCleartextTraffic: true` para permitir o desenvolvimento local em HTTP. Em produção, use HTTPS e remova essa permissão.

## RFID

Fluxo implementado (sem dependência de leitor específico):

- O leitor físico é usado como **teclado**: o aplicativo do Totem mantém um campo de texto com foco e processa o código quando o leitor envia **ENTER**.
- Sem leitor, o mesmo campo aceita digitação manual do valor cadastrado em `users.rfid_code`.
- A consulta é feita em `GET /api/totem/usuario/{rfid}` (header `X-Totem-Token` obrigatório), que recusa cartão inexistente (404), cartão bloqueado (403) e usuário inativo (403).
- Cada cartão tem uma **senha (PIN)** própria, cadastrada pelo aluno em *Perfil → Configurações → Senha do Cartão RFID* e exigida em **todos** os pagamentos do Totem (saldo e crédito).
- Gestão de cartões por rotas de staff/admin: `POST /api/users/{id}/rfid/link`, `/rfid/unlink`, `/rfid/block`, `/rfid/unblock`.
- O app do aluno permite definir/trocar a senha do cartão em `POST /api/me/rfid/pin`.

Detalhes operacionais adicionais em [totem/README.md](totem/README.md). **Não há validação de hardware** (protocolo, codificação, distância de leitura) no projeto: isso depende do leitor físico.

## Build e distribuição

**Aplicativo do aluno** (`React-Native/eas.json`): perfis `development` (development client), `preview` (APK, distribuição interna) e `production`.

**Totem** (`totem/eas.json`): perfil `preview` com `distribution: internal` e `buildType: apk` — perfil para gerar APK instalável:

```bash
cd totem
npx eas-cli login
npx eas-cli build --profile preview --platform android
```

Pré-requisitos externos (não versionados): conta/organização EAS, credenciais de build (keystore) ou JDK + Android SDK para build local. Nenhum build foi executado nesta etapa do projeto.

**Push notifications**: apenas o aplicativo do aluno usa push (FCM), via `expo-notifications` + `React-Native/google-services.json`. O Totem **não** usa push, por isso não exige `google-services.json`.

## Limitações conhecidas e pendências

- **Layout do Totem**: problema de layout e rolagem corrigido e validado no Expo Web; lista de produtos e carrinho rolam, e os totais e ações permanecem acessíveis.
- **HTTPS em produção**: ainda não configurado. O Totem usa cleartext em desenvolvimento; produção exige domínio/HTTPS reais.
- **`google-services.json` do Totem**: não é necessário hoje (sem push). Se o Totem passar a usar push, o arquivo real do Firebase (projeto `saviore-54aa8`) precisa ser fornecido.
- **Projeto EAS do Totem**: `totem/app.json` ainda compartilha `slug` e `projectId` com o app do aluno. Para builds/atualizações independentes é necessário criar um projeto EAS próprio (`eas init`) com a sua conta.
- **Ajuda do app do aluno**: a tela contém contatos de exemplo (`Nome Exemplo` / `email@email.com`); faltam os contatos reais.
- **RFID físico**: leitura elétrica, protocolo e cartão real não foram testados (sem hardware no ambiente).
- **Concorrência HTTP real**: os testes cobrem lock/transação em SQLite; concorrência de rede real depende de ambiente com PostgreSQL.
- **CI**: não existe workflow de testes automatizados; o único workflow do repositório é `galeria-sync.yml`.

## Documentação

- [totem/README.md](totem/README.md) — RFID, assets, Google Services e build do Totem.
- [docs/DESIGN_SYSTEM_TCC.md](docs/DESIGN_SYSTEM_TCC.md) — tokens de design do projeto.
