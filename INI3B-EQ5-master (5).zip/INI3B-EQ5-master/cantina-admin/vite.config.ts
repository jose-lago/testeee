import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  base: "/2457003/admin/",
  plugins: [react()],
});
