import { ConfigProvider, theme } from "antd";
import ptBR from "antd/locale/pt_BR";
import {
  type PropsWithChildren,
  createContext,
  useEffect,
  useState,
} from "react";

type ColorModeContextType = {
  mode: string;
  setMode: (mode: string) => void;
};

export const ColorModeContext = createContext<ColorModeContextType>(
  {} as ColorModeContextType
);

export const ColorModeContextProvider: React.FC<PropsWithChildren> = ({
  children,
}) => {
  const colorModeFromLocalStorage = localStorage.getItem("colorMode");
  const isSystemPreferenceDark = window?.matchMedia(
    "(prefers-color-scheme: dark)"
  ).matches;

  const systemPreference = isSystemPreferenceDark ? "dark" : "light";
  const [mode, setMode] = useState(
    colorModeFromLocalStorage || systemPreference
  );

  useEffect(() => {
    window.localStorage.setItem("colorMode", mode);
  }, [mode]);

  const setColorMode = () => {
    if (mode === "light") {
      setMode("dark");
    } else {
      setMode("light");
    }
  };

  const { darkAlgorithm, defaultAlgorithm } = theme;

  return (
    <ColorModeContext.Provider
      value={{
        setMode: setColorMode,
        mode,
      }}
    >
      <ConfigProvider
        locale={ptBR}
        theme={{
          algorithm: mode === "light" ? defaultAlgorithm : darkAlgorithm,
          token: {
            // Paleta extraída do Figma TCC Saviore
            colorPrimary: '#FF9430',
            colorInfo: '#FF9430',
            colorBgLayout: mode === 'light' ? '#F4F5F7' : '#0F1A25',
            colorTextBase: mode === 'light' ? '#3E2723' : '#F5F5F5',
            // Tipografia ampliada para alta legibilidade
            fontSize: 16,
            fontSizeLG: 18,
            fontSizeSM: 14,
            fontSizeHeading1: 30,
            fontSizeHeading2: 24,
            fontSizeHeading3: 20,
            fontSizeHeading4: 18,
            fontSizeHeading5: 16,
            controlHeight: 40,
            controlHeightLG: 46,
            borderRadius: 8,
          },
          components: {
            Layout: {
              siderBg: '#0F1A25', // Cor do sidebar baseada no Figma
              headerBg: mode === 'light' ? '#FFFFFF' : '#0F1A25',
            },
            Menu: {
              colorItemBg: '#0F1A25',
              colorItemText: '#FFFFFF',
              colorItemTextHover: '#FF9430',
              colorItemTextSelected: '#FF9430',
              colorItemBgSelected: 'rgba(255, 148, 48, 0.15)',
              colorItemBgHover: 'rgba(255, 148, 48, 0.15)',
              fontSize: 15,
            },
            Table: {
              fontSize: 15,
            },
            Button: {
              fontSize: 15,
            },
          }
        }}
      >
        {children}
      </ConfigProvider>
    </ColorModeContext.Provider>
  );
};
