import { Refine } from "@refinedev/core";
import { DevtoolsPanel, DevtoolsProvider } from "@refinedev/devtools";
import { RefineKbar, RefineKbarProvider } from "@refinedev/kbar";

import {
    useNotificationProvider,
    ThemedLayout,
    ThemedTitle,
} from "@refinedev/antd";

import { Authenticated } from "@refinedev/core";

import "@refinedev/antd/dist/reset.css";
import "./design-system.css"; // Tokens do Design System (:root CSS variables)
import "./admin-theme.css";   // Customização das tabelas/botões Ant Design

import routerProvider, {
    DocumentTitleHandler,
    UnsavedChangesNotifier,
    NavigateToResource,
} from "@refinedev/react-router";

import { App as AntdApp, ConfigProvider } from "antd";
import ptBR from "antd/locale/pt_BR";
import { HashRouter, Route, Routes, Outlet } from "react-router";

import { ColorModeContextProvider } from "./contexts/color-mode";
import { authProvider } from "./providers/auth";
import { dataProvider } from "./providers/data";
import { i18nProvider } from "./providers/i18n";

import { Login } from "./pages/login";

// Produtos
import { ProdutoList } from "./pages/produtos/list";
import { ProdutoCreate } from "./pages/produtos/create";
import { ProdutoEdit } from "./pages/produtos/edit";

// Usuários
import { UsuarioList } from "./pages/usuarios/list";
import { UsuarioCreate } from "./pages/usuarios/create";
import { UsuarioEdit } from "./pages/usuarios/edit";
import { UsuarioRecharge } from "./pages/usuarios/recharge";

// Pedidos
import { PedidoList } from "./pages/pedidos/list";
import { PedidoEdit } from "./pages/pedidos/edit";

// Kanban
import { KanbanPage } from "./pages/kanban";

// Movimentações
import { MovimentacaoList } from "./pages/movimentacoes/list";

// Devedores
import { DevedoresList } from "./pages/devedores/list";

// Configurações
import { ConfiguracoesPage } from "./pages/configuracoes";

function App() {
    return (
        <HashRouter>
            <RefineKbarProvider>
                <ColorModeContextProvider>
                    <ConfigProvider locale={ptBR}>
                        <AntdApp>
                            <DevtoolsProvider>
                                <Refine
                                    dataProvider={dataProvider}
                                    notificationProvider={useNotificationProvider}
                                    routerProvider={routerProvider}
                                    authProvider={authProvider}
                                    i18nProvider={i18nProvider}
                                    resources={[
                                        {
                                            name: "produtos",
                                            list: "/produtos",
                                            create: "/produtos/create",
                                            edit: "/produtos/edit/:id",
                                            show: "/produtos/show/:id",
                                            meta: {
                                                canDelete: true,
                                                label: "Produtos",
                                            },
                                        },
                                        {
                                            name: "users",
                                            list: "/users",
                                            create: "/users/create",
                                            edit: "/users/edit/:id",
                                            show: "/users/show/:id",
                                            meta: {
                                                canDelete: true,
                                                label: "Usuários",
                                            },
                                        },
                                        {
                                            name: "pedidos",
                                            list: "/pedidos",
                                            edit: "/pedidos/edit/:id",
                                            show: "/pedidos/show/:id",
                                            meta: {
                                                canDelete: true,
                                                label: "Pedidos",
                                            },
                                        },
                                        {
                                            name: "kanban",
                                            list: "/kanban",
                                            meta: {
                                                label: "Kanban",
                                            },
                                        },
                                        {
                                            name: "movimentacoes",
                                            list: "/movimentacoes",
                                            meta: {
                                                label: "Movimentações",
                                            },
                                        },
                                        {
                                            name: "recarga",
                                            list: "/recarga",
                                            meta: {
                                                label: "Adicionar Saldo",
                                            },
                                        },
                                        {
                                            name: "credito/devedores",
                                            list: "/credito/devedores",
                                            meta: {
                                                label: "Devedores",
                                            },
                                        },
                                        {
                                            name: "configuracoes",
                                            list: "/configuracoes",
                                            meta: {
                                                label: "Configurações",
                                            },
                                        },
                                    ]}
                                    options={{
                                        syncWithLocation: true,
                                        warnWhenUnsavedChanges: true,
                                    }}
                                >
                                    <Routes>
                                        {/* LOGIN CUSTOMIZADO EM PT-BR */}
                                        <Route
                                            path="/login"
                                            element={<Login />}
                                        />

                                        {/* ROTAS PROTEGIDAS */}
                                        <Route
                                            element={
                                                <Authenticated
                                                    key="protected-routes"
                                                    fallback={<Login />}
                                                >
                                                    <ThemedLayout
                                                        Title={(titleProps) => (
                                                            <ThemedTitle
                                                                {...titleProps}
                                                                text="Saviore"
                                                                icon={<span style={{ fontSize: 20 }}>🍽️</span>}
                                                            />
                                                        )}
                                                    >
                                                        <Outlet />
                                                    </ThemedLayout>
                                                </Authenticated>
                                            }
                                        >
                                            {/* redirect raiz */}
                                            <Route
                                                index
                                                element={
                                                    <NavigateToResource resource="produtos" />
                                                }
                                            />

                                            {/* PRODUTOS */}
                                            <Route path="/produtos">
                                                <Route index element={<ProdutoList />} />
                                                <Route
                                                    path="create"
                                                    element={<ProdutoCreate />}
                                                />
                                                <Route
                                                    path="edit/:id"
                                                    element={<ProdutoEdit />}
                                                />
                                            </Route>

                                            {/* USUÁRIOS */}
                                            <Route path="/users">
                                                <Route index element={<UsuarioList />} />
                                                <Route
                                                    path="create"
                                                    element={<UsuarioCreate />}
                                                />
                                                <Route
                                                    path="edit/:id"
                                                    element={<UsuarioEdit />}
                                                />
                                            </Route>

                                            {/* PEDIDOS */}
                                            <Route path="/pedidos">
                                                <Route index element={<PedidoList />} />
                                                <Route path="edit/:id" element={<PedidoEdit />} />
                                            </Route>

                                            {/* ADICIONAR SALDO (Isolado) */}
                                            <Route path="/recarga" element={<UsuarioRecharge />} />

                                            {/* KANBAN */}
                                            <Route
                                                path="/kanban"
                                                element={<KanbanPage />}
                                            />

                                            {/* MOVIMENTAÇÕES */}
                                            <Route path="/movimentacoes">
                                                <Route index element={<MovimentacaoList />} />
                                            </Route>

                                            {/* DEVEDORES */}
                                            <Route path="/credito/devedores">
                                                <Route index element={<DevedoresList />} />
                                            </Route>

                                            {/* CONFIGURAÇÕES */}
                                            <Route
                                                path="/configuracoes"
                                                element={<ConfiguracoesPage />}
                                            />
                                        </Route>
                                    </Routes>

                                    <RefineKbar />
                                    <UnsavedChangesNotifier />
                                    <DocumentTitleHandler />
                                </Refine>

                                <DevtoolsPanel />
                            </DevtoolsProvider>
                        </AntdApp>
                    </ConfigProvider>
                </ColorModeContextProvider>
            </RefineKbarProvider>
        </HashRouter>
    );
}

export default App;
