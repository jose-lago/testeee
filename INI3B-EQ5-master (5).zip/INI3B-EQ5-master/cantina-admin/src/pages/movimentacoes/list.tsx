import {
    List,
    useTable,
    FilterDropdown,
} from "@refinedev/antd";
import { Table, Tag, Input, Select, Button, Space, message, Popconfirm } from "antd";
import { UndoOutlined } from "@ant-design/icons";
import { useState } from "react";
import api from "../../services/api";

export const MovimentacaoList = () => {
    const { tableProps } = useTable({
        syncWithLocation: true,
    });

    const [loadingId, setLoadingId] = useState<number | null>(null);

    const handleDesfazer = async (id: number) => {
        setLoadingId(id);
        try {
            await api.post(`/movimentacoes/${id}/desfazer`);
            message.success("Recarga desfeita com sucesso.");
            window.location.reload();
        } catch (error: any) {
            message.error(error.response?.data?.message || "Erro ao desfazer recarga.");
        } finally {
            setLoadingId(null);
        }
    };

    // Mapeamento de cores por tipo de movimentação
    const coresTipo: Record<string, string> = {
        recarga: "green",
        pedido: "red",
        estorno: "blue",
        ajuste: "orange",
    };

    return (
        <List title="Movimentações Financeiras">
            <Table {...tableProps} rowKey="id">
                <Table.Column dataIndex="id" title="ID" width={70} sorter />

                {/* Usuário */}
                <Table.Column
                    dataIndex={["user", "name"]}
                    title="Usuário"
                    filterDropdown={(props) => (
                        <FilterDropdown {...props}>
                            <Input placeholder="Buscar usuário..." />
                        </FilterDropdown>
                    )}
                />

                {/* Tipo */}
                <Table.Column
                    dataIndex="tipo"
                    title="Tipo"
                    sorter
                    filterDropdown={(props) => (
                        <FilterDropdown {...props}>
                            <Select
                                style={{ minWidth: 130 }}
                                placeholder="Filtrar tipo"
                                options={[
                                    { label: "Recarga", value: "recarga" },
                                    { label: "Pedido", value: "pedido" },
                                    { label: "Estorno", value: "estorno" },
                                    { label: "Ajuste", value: "ajuste" },
                                ]}
                            />
                        </FilterDropdown>
                    )}
                    render={(value: string) => (
                        <Tag color={coresTipo[value] || "default"}>
                            {value?.toUpperCase()}
                        </Tag>
                    )}
                />

                {/* Valor */}
                <Table.Column
                    dataIndex="valor"
                    title="Valor"
                    sorter
                    render={(value: number) => {
                        const positivo = Number(value) >= 0;
                        return (
                            <span style={{ color: positivo ? "#2E7D32" : "#C62828", fontWeight: 600 }}>
                                {positivo ? "+" : ""}R$ {Number(value).toFixed(2)}
                            </span>
                        );
                    }}
                />

                {/* Saldo Anterior */}
                <Table.Column
                    dataIndex="saldo_anterior"
                    title="Saldo Anterior"
                    render={(value: number) => `R$ ${Number(value).toFixed(2)}`}
                />

                {/* Saldo Posterior */}
                <Table.Column
                    dataIndex="saldo_posterior"
                    title="Saldo Posterior"
                    render={(value: number) => `R$ ${Number(value).toFixed(2)}`}
                />

                {/* Descrição */}
                <Table.Column dataIndex="descricao" title="Descrição" />

                {/* Admin responsável */}
                <Table.Column
                    dataIndex={["admin", "name"]}
                    title="Admin"
                    render={(value: string) => value || "—"}
                />

                {/* Pedido vinculado */}
                <Table.Column
                    dataIndex={["pedido", "senha_diaria"]}
                    title="Pedido"
                    render={(value: number) => value ? `#${value}` : "—"}
                />

                {/* Data */}
                <Table.Column
                    dataIndex="created_at"
                    title="Data"
                    sorter
                    render={(value: string) => {
                        if (!value) return "—";
                        const d = new Date(value);
                        return `${d.toLocaleDateString("pt-BR")} ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
                    }}
                />

                {/* Ações */}
                <Table.Column
                    title="Ações"
                    dataIndex="actions"
                    render={(_, record: any) => (
                        <Space>
                            {record.tipo === "recarga" && (
                                <Popconfirm
                                    title="Desfazer Recarga"
                                    description="Isso criará um ajuste debitando o saldo do usuário. Continuar?"
                                    onConfirm={() => handleDesfazer(record.id)}
                                    okText="Sim"
                                    cancelText="Não"
                                >
                                    <Button 
                                        size="small" 
                                        danger 
                                        icon={<UndoOutlined />}
                                        loading={loadingId === record.id}
                                    >
                                        Desfazer
                                    </Button>
                                </Popconfirm>
                            )}
                        </Space>
                    )}
                />
            </Table>
        </List>
    );
};
