import React, { useState } from "react";
import {
    List,
    useTable,
    EditButton,
    DeleteButton,
} from "@refinedev/antd";
import {
    Table,
    Tag,
    Select,
    Space,
    Button,
    Modal,
    Card,
    Row,
    Col,
    Typography,
    Divider,
    Descriptions,
    message,
} from "antd";
import {
    EyeOutlined,
    ShoppingOutlined,
    ClockCircleOutlined,
    UserOutlined,
    DollarOutlined,
    CreditCardOutlined,
} from "@ant-design/icons";
import { useInvalidate } from "@refinedev/core";
import { api } from "../../services/api";

const { Title, Text } = Typography;

export const PedidoList: React.FC = () => {
    const { tableProps, setFilters } = useTable({
        syncWithLocation: true,
    });
    const invalidate = useInvalidate();

    const [modalVisible, setModalVisible] = useState<boolean>(false);
    const [pedidoSelecionado, setPedidoSelecionado] = useState<any>(null);
    const [atualizandoStatus, setAtualizandoStatus] = useState<boolean>(false);

    const abrirDetalhes = (record: any) => {
        setPedidoSelecionado(record);
        setModalVisible(true);
    };

    const fecharDetalhes = () => {
        setModalVisible(false);
        setPedidoSelecionado(null);
        // Garante que ao fechar o card a tabela já esteja 100% atualizada
        invalidate({
            resource: "pedidos",
            invalidates: ["list"],
        });
    };

    const alterarStatusPedido = async (novoStatus: string) => {
        if (!pedidoSelecionado) return;
        setAtualizandoStatus(true);
        try {
            await api.put(`/pedidos/${pedidoSelecionado.id}`, {
                status: novoStatus,
            });
            setPedidoSelecionado((prev: any) => ({
                ...prev,
                status: novoStatus,
            }));

            // Atualiza a tabela do Refine imediatamente
            await invalidate({
                resource: "pedidos",
                invalidates: ["list", "detail"],
            });

            message.success(`Status alterado para "${novoStatus.toUpperCase()}" com sucesso!`);
        } catch (err: any) {
            message.error(
                err.response?.data?.message || "Erro ao alterar o status do pedido."
            );
        } finally {
            setAtualizandoStatus(false);
        }
    };

    const renderStatusTag = (status: string) => {
        let color = "default";
        let label = status;

        switch (status) {
            case "pendente":
                color = "gold";
                label = "Pendente";
                break;
            case "preparando":
                color = "orange";
                label = "Preparando";
                break;
            case "pronto":
                color = "green";
                label = "Pronto";
                break;
            case "entregue":
                color = "blue";
                label = "Entregue";
                break;
            case "cancelado":
                color = "red";
                label = "Cancelado";
                break;
        }

        return <Tag color={color} style={{ fontSize: 13, padding: "3px 10px", fontWeight: "bold" }}>{label}</Tag>;
    };

    return (
        <List title="Gerenciamento de Pedidos">
            <div style={{ marginBottom: 16, display: "flex", gap: 12, alignItems: "center" }}>
                <span style={{ fontSize: 15, fontWeight: 600, color: "#3E2723" }}>Filtrar por Status:</span>
                <Select
                    placeholder="Todos os status"
                    allowClear
                    size="middle"
                    style={{ width: 220 }}
                    onChange={(value) => {
                        setFilters([
                            {
                                field: "status",
                                operator: "eq",
                                value,
                            },
                        ]);
                    }}
                    options={[
                        { value: "pendente", label: "🟡 Pendente" },
                        { value: "preparando", label: "🟠 Preparando" },
                        { value: "pronto", label: "🟢 Pronto" },
                        { value: "entregue", label: "🔵 Entregue" },
                        {
                            value: "cancelado",
                            label: "🔴 Cancelado",
                            disabled: pedidoSelecionado.status !== "cancelado",
                        },
                    ]}
                />
            </div>

            <Table {...tableProps} rowKey="id">
                <Table.Column dataIndex="id" title="ID" width={70} sorter />

                <Table.Column
                    dataIndex="senha_diaria"
                    title="Senha Diária"
                    width={130}
                    sorter
                    render={(senha) => (
                        <Tag color="#3E2723" style={{ fontSize: 15, fontWeight: "bold", padding: "4px 12px", borderRadius: 8 }}>
                            #{senha}
                        </Tag>
                    )}
                />

                <Table.Column
                    dataIndex={["user", "name"]}
                    title="Aluno / Cliente"
                    sorter
                    render={(nome, record: any) => (
                        <div>
                            <div style={{ fontWeight: 600, color: "#1E293B" }}>{nome || "Aluno não identificado"}</div>
                            <div style={{ fontSize: 12, color: "#64748B" }}>{record.user?.email || ""}</div>
                        </div>
                    )}
                />

                <Table.Column
                    dataIndex="valor_total"
                    title="Valor Total"
                    sorter
                    render={(value) => (
                        <span style={{ fontWeight: "bold", color: "#16A34A", fontSize: 15 }}>
                            R$ {Number(value || 0).toFixed(2)}
                        </span>
                    )}
                />

                <Table.Column
                    dataIndex="status"
                    title="Status Atual"
                    sorter
                    render={(value) => renderStatusTag(value)}
                />

                <Table.Column
                    dataIndex="created_at"
                    title="Data / Horário"
                    render={(value) => {
                        if (!value) return "-";
                        const d = new Date(value);
                        return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
                    }}
                />

                <Table.Column
                    title="Ações"
                    render={(_, record: any) => (
                        <Space size="middle">
                            <Button
                                type="primary"
                                icon={<EyeOutlined />}
                                size="small"
                                onClick={() => abrirDetalhes(record)}
                                style={{ backgroundColor: "#FF9430", borderColor: "#FF9430" }}
                            >
                                Detalhes
                            </Button>

                            <EditButton
                                hideText
                                size="small"
                                recordItemId={record.id}
                            />

                            <DeleteButton
                                hideText
                                size="small"
                                recordItemId={record.id}
                            />
                        </Space>
                    )}
                />
            </Table>

            {/* MODAL / CARD COM DETALHES COMPLETOS DO PEDIDO */}
            <Modal
                title={
                    <Space align="center">
                        <ShoppingOutlined style={{ color: "#FF9430", fontSize: 22 }} />
                        <span style={{ fontSize: 18, fontWeight: 700, color: "#3E2723" }}>
                            Detalhes Completos do Pedido #{pedidoSelecionado?.id}
                        </span>
                    </Space>
                }
                open={modalVisible}
                onCancel={fecharDetalhes}
                footer={[
                    <Button key="fechar" onClick={fecharDetalhes} size="large">
                        Fechar
                    </Button>,
                ]}
                width={700}
                centered
            >
                {pedidoSelecionado && (
                    <div>
                        {/* CARD DE SENHA E STATUS */}
                        <Card
                            style={{
                                backgroundColor: "#FFF8F0",
                                borderColor: "#FFE6D0",
                                borderRadius: 12,
                                marginBottom: 20,
                            }}
                        >
                            <Row align="middle" justify="space-between">
                                <Col>
                                    <Text style={{ fontSize: 13, color: "#7C2D12", textTransform: "uppercase", fontWeight: 700 }}>
                                        Senha de Retirada
                                    </Text>
                                    <div style={{ fontSize: 36, fontWeight: 900, color: "#EA580C" }}>
                                        #{pedidoSelecionado.senha_diaria}
                                    </div>
                                    <Text style={{ fontSize: 13, color: "#64748B" }}>
                                        Código seguro: <strong>{pedidoSelecionado.codigo_retirada || "—"}</strong>
                                    </Text>
                                </Col>
                                <Col style={{ textAlign: "right" }}>
                                    <div style={{ marginBottom: 8 }}>
                                        {renderStatusTag(pedidoSelecionado.status)}
                                    </div>
                                    <Space direction="vertical" align="end">
                                        <Text style={{ fontSize: 13, color: "#64748B" }}>Alterar Status:</Text>
                                        <Select
                                            value={pedidoSelecionado.status}
                                            style={{ width: 160 }}
                                            loading={atualizandoStatus}
                                            disabled={pedidoSelecionado.status === "cancelado"}
                                            onChange={alterarStatusPedido}
                                            options={[
                                                { value: "pendente", label: "🟡 Pendente" },
                                                { value: "preparando", label: "🟠 Preparando" },
                                                { value: "pronto", label: "🟢 Pronto" },
                                                { value: "entregue", label: "🔵 Entregue" },
                                                { value: "cancelado", label: "🔴 Cancelado" },
                                            ]}
                                        />
                                    </Space>
                                </Col>
                            </Row>
                        </Card>

                        {/* DADOS DO CLIENTE E PAGAMENTO */}
                        <Descriptions
                            bordered
                            size="small"
                            column={{ xs: 1, sm: 2 }}
                            style={{ marginBottom: 20 }}
                        >
                            <Descriptions.Item label={<span><UserOutlined /> Aluno</span>}>
                                <strong>{pedidoSelecionado.user?.name || "Não informado"}</strong>
                            </Descriptions.Item>
                            <Descriptions.Item label="E-mail">
                                {pedidoSelecionado.user?.email || "—"}
                            </Descriptions.Item>
                            <Descriptions.Item label={<span><ClockCircleOutlined /> Realizado em</span>}>
                                {pedidoSelecionado.created_at
                                    ? new Date(pedidoSelecionado.created_at).toLocaleString("pt-BR")
                                    : "—"}
                            </Descriptions.Item>
                            <Descriptions.Item label={<span><CreditCardOutlined /> Entrega da Bebida</span>}>
                                {pedidoSelecionado.momento_bebida === "com_almoco"
                                    ? "Junto com o almoço"
                                    : "Entregar agora"}
                            </Descriptions.Item>
                        </Descriptions>

                        <Divider orientation="left" style={{ fontSize: 15, fontWeight: 700, color: "#3E2723" }}>
                            Itens do Pedido
                        </Divider>

                        {/* TABELA DE ITENS */}
                        <Table
                            dataSource={pedidoSelecionado.itens || []}
                            rowKey="id"
                            pagination={false}
                            size="small"
                            bordered
                        >
                            <Table.Column
                                title="Produto"
                                dataIndex={["produto", "nome"]}
                                render={(nome, record: any) => (
                                    <div>
                                        <div style={{ fontWeight: 600 }}>{nome || "Item da cantina"}</div>
                                        {record.observacao && (
                                            <div style={{ fontSize: 12, color: "#EA580C" }}>
                                                Obs: {record.observacao}
                                            </div>
                                        )}
                                    </div>
                                )}
                            />
                            <Table.Column
                                title="Qtd"
                                dataIndex="quantidade"
                                width={70}
                                align="center"
                                render={(qtd) => <Tag color="blue">{qtd}x</Tag>}
                            />
                            <Table.Column
                                title="Preço Unit."
                                dataIndex={["produto", "preco_atual"]}
                                width={120}
                                align="right"
                                render={(preco) => `R$ ${Number(preco || 0).toFixed(2)}`}
                            />
                            <Table.Column
                                title="Subtotal"
                                width={120}
                                align="right"
                                render={(_, record: any) => {
                                    const preco = Number(record.produto?.preco_atual || 0);
                                    const qtd = Number(record.quantidade || 1);
                                    return (
                                        <strong>R$ {(preco * qtd).toFixed(2)}</strong>
                                    );
                                }}
                            />
                        </Table>

                        {/* TOTAL EM DESTAQUE */}
                        <div
                            style={{
                                marginTop: 18,
                                padding: "14px 18px",
                                backgroundColor: "#F8FAFC",
                                borderRadius: 10,
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                border: "1px solid #E2E8F0",
                            }}
                        >
                            <span style={{ fontSize: 16, fontWeight: 700, color: "#3E2723" }}>
                                Valor Total do Pedido:
                            </span>
                            <span style={{ fontSize: 24, fontWeight: 900, color: "#16A34A" }}>
                                R$ {Number(pedidoSelecionado.valor_total || 0).toFixed(2)}
                            </span>
                        </div>
                    </div>
                )}
            </Modal>
        </List>
    );
};