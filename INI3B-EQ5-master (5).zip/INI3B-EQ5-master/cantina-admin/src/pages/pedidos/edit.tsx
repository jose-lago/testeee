import {
    Edit,
    useForm,
} from "@refinedev/antd";

import {
    Form,
    Select,
    InputNumber,
} from "antd";

export const PedidoEdit = () => {
    const { formProps, saveButtonProps } =
    useForm({
        resource: "pedidos",
    });

    return (
        <Edit saveButtonProps={saveButtonProps}>
            <Form {...formProps} layout="vertical">

                <Form.Item
                    noStyle
                    shouldUpdate={(previous, current) => previous.status !== current.status}
                >
                    {({ getFieldValue }) => (
                        <Form.Item label="Status" name="status">
                            <Select
                                disabled={getFieldValue("status") === "cancelado"}
                                options={[
                                    { value: "pendente", label: "Pendente" },
                                    { value: "preparando", label: "Preparando" },
                                    { value: "pronto", label: "Pronto" },
                                    { value: "entregue", label: "Entregue" },
                                    { value: "cancelado", label: "Cancelado", disabled: true },
                                ]}
                            />
                        </Form.Item>
                    )}
                </Form.Item>
                <Form.Item
                    label="Posição Fila"
                    name="posicao_fila"
                >
                    <InputNumber min={0} style={{ width: "100%" }} />
                </Form.Item>

            </Form>
        </Edit>
    );
};