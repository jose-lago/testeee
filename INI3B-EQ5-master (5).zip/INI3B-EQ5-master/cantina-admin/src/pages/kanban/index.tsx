import React, { useState, useEffect, useCallback } from "react";
import {
    Card,
    Col,
    Row,
    Tag,
    Button,
    Typography,
    Badge,
    Space,
    Modal,
    message,
    Tooltip,
    Divider,
    Empty,
    Spin,
    Select,
} from "antd";
import {
    FireOutlined,
    CoffeeOutlined,
    ClockCircleOutlined,
    CheckCircleOutlined,
    UndoOutlined,
    ExclamationCircleOutlined,
    SyncOutlined,
    UserOutlined,
    ShoppingCartOutlined,
} from "@ant-design/icons";
import api from "../../services/api";

const { Title, Text } = Typography;

// ── Tipos ──────────────────────────────────────────────

interface PedidoItem {
    id: number;
    produto_id: number;
    quantidade: number;
    preco_unitario: string;
    observacao: string | null;
    entregue: boolean;
    produto?: {
        id: number;
        nome: string;
        categoria: string;
    };
}

interface Usuario {
    id: number;
    name: string;
    email: string;
    tipo: string;
}

interface Pedido {
    id: number;
    user_id: number;
    preparador_id: number | null;
    valor_total: string;
    senha_diaria: number;
    status: string;
    momento_bebida: string;
    posicao_fila: number;
    codigo_retirada: string;
    created_at: string;
    updated_at: string;
    itens?: PedidoItem[];
    user?: Usuario;
    preparador?: Usuario;
}

interface FilaResponse {
    bebidas_agora: Pedido[];
    pendentes: Pedido[];
    em_preparo: Pedido[];
    prontos: Pedido[];
    total_fila: number;
}

// ── Componente Principal ───────────────────────────────

export const KanbanPage: React.FC = () => {
    const [fila, setFila] = useState<FilaResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState<number | null>(null);
    const [entregaModal, setEntregaModal] = useState<{
        pedido: Pedido;
        comProximo: boolean;
    } | null>(null);

    // Seleção de preparador
    const [funcionarios, setFuncionarios] = useState<Usuario[]>([]);
    const [preparadorSelecionado, setPreparadorSelecionado] = useState<number | null>(null);

    // ── Buscar dados ───────────────────────────────────

    const carregarDados = useCallback(async () => {
        try {
            const [filaRes, funcRes] = await Promise.all([
                api.get("/pedidos/fila"),
                api.get("/pedidos/preparadores")
            ]);
            setFila(filaRes.data);
            
            // A nova API já traz funcionários e admins juntos
            const listaPreparadores = funcRes.data;
            setFuncionarios(listaPreparadores);
            
            // Se ainda não selecionou, pré-seleciona o usuário logado
            if (!preparadorSelecionado) {
                const userStorage = localStorage.getItem("admin_user");
                if (userStorage) {
                    const userId = JSON.parse(userStorage).id;
                    if (listaPreparadores.some((f: Usuario) => f.id === userId)) {
                        setPreparadorSelecionado(userId);
                    } else if (listaPreparadores.length > 0) {
                        setPreparadorSelecionado(listaPreparadores[0].id);
                    }
                } else if (listaPreparadores.length > 0) {
                    setPreparadorSelecionado(listaPreparadores[0].id);
                }
            }
        } catch (error) {
            console.error("Erro ao carregar dados:", error);
        } finally {
            setLoading(false);
        }
    }, [preparadorSelecionado]);

    useEffect(() => {
        carregarDados();
        const interval = setInterval(async () => {
            try {
                const { data } = await api.get("/pedidos/fila");
                setFila(data);
            } catch (err) {
                console.error(err);
            }
        }, 5000);
        return () => clearInterval(interval);
    }, [carregarDados]);

    // ── Ações do Kanban ────────────────────────────────

    const entregarBebida = async (pedidoId: number) => {
        setActionLoading(pedidoId);
        try {
            await api.post(`/pedidos/${pedidoId}/entregar-bebida`);
            message.success("Bebida entregue!");
            const { data } = await api.get("/pedidos/fila");
            setFila(data);
        } catch (error: any) {
            message.error(
                error.response?.data?.message || "Erro ao entregar bebida."
            );
        } finally {
            setActionLoading(null);
        }
    };

    const prepararPedido = async (pedidoId: number) => {
        if (!preparadorSelecionado) {
            message.warning("Por favor, selecione quem está preparando.");
            return;
        }
        setActionLoading(pedidoId);
        try {
            await api.post(`/pedidos/${pedidoId}/preparar`, {
                preparador_id: preparadorSelecionado,
            });
            message.success("Pedido em preparo!");
            const { data } = await api.get("/pedidos/fila");
            setFila(data);
        } catch (error: any) {
            message.error(
                error.response?.data?.message || "Erro ao preparar pedido."
            );
        } finally {
            setActionLoading(null);
        }
    };

    const marcarPronto = async (pedidoId: number) => {
        setActionLoading(pedidoId);
        try {
            await api.post(`/pedidos/${pedidoId}/pronto`);
            message.success("Pedido marcado como pronto!");
            const { data } = await api.get("/pedidos/fila");
            setFila(data);
        } catch (error: any) {
            message.error(
                error.response?.data?.message || "Erro ao marcar como pronto."
            );
        } finally {
            setActionLoading(null);
        }
    };

    const confirmarEntrega = async () => {
        if (!entregaModal) return;
        setActionLoading(entregaModal.pedido.id);
        try {
            if (entregaModal.comProximo) {
                if (!preparadorSelecionado) {
                    message.warning("Por favor, selecione quem está preparando.");
                    setActionLoading(null);
                    return;
                }
                const { data } = await api.post(
                    `/pedidos/${entregaModal.pedido.id}/entregar-proximo`,
                    {
                        codigo_confirmado: true,
                        preparador_id: preparadorSelecionado,
                    }
                );
                message.success("Pedido entregue!");
                if (data.proximo) {
                    message.info(
                        `Próximo pedido #${data.proximo.senha_diaria} em preparo!`
                    );
                } else {
                    message.info("Não há mais pedidos pendentes na fila.");
                }
            } else {
                await api.post(
                    `/pedidos/${entregaModal.pedido.id}/entregar`,
                    {
                        codigo_confirmado: true,
                    }
                );
                message.success("Pedido entregue com sucesso!");
            }
            setEntregaModal(null);
            const filaData = await api.get("/pedidos/fila");
            setFila(filaData.data);
        } catch (error: any) {
            message.error(
                error.response?.data?.message || "Erro ao entregar pedido."
            );
        } finally {
            setActionLoading(null);
        }
    };

    const desfazerAcao = async (pedidoId: number) => {
        setActionLoading(pedidoId);
        try {
            await api.post(`/pedidos/${pedidoId}/desfazer`);
            message.success("Ação desfeita!");
            const { data } = await api.get("/pedidos/fila");
            setFila(data);
        } catch (error: any) {
            message.error(
                error.response?.data?.message || "Erro ao desfazer ação."
            );
        } finally {
            setActionLoading(null);
        }
    };

    // ── Helpers de renderização ─────────────────────────

    const formatarSenha = (senha: number) =>
        String(senha).padStart(3, "0");

    const formatarHora = (dateStr: string) => {
        const date = new Date(dateStr);
        return date.toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
        });
    };

    // ── Render ─────────────────────────────────────────

    if (loading) {
        return (
            <div
                style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: 400,
                }}
            >
                <Spin size="large" tip="Carregando fila..." />
            </div>
        );
    }

    if (!fila) {
        return <Empty description="Não foi possível carregar a fila." />;
    }

    return (
        <div style={{ padding: 16 }}>
            {/* Header */}
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 16,
                }}
            >
                <Title level={3} style={{ margin: 0 }}>
                    🍽️ Kanban da Cantina
                </Title>
                <Space size="large">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Text strong>Preparador:</Text>
                        <Select
                            value={preparadorSelecionado}
                            onChange={setPreparadorSelecionado}
                            style={{ width: 200 }}
                            placeholder="Selecione o funcionário"
                            options={funcionarios.map(f => ({
                                label: `${f.name} (${f.tipo})`,
                                value: f.id
                            }))}
                        />
                    </div>
                    <Tag
                        icon={<ClockCircleOutlined />}
                        color="processing"
                        style={{ fontSize: 14, padding: "4px 12px" }}
                    >
                        {fila.total_fila} na fila
                    </Tag>
                    <Button
                        icon={<SyncOutlined />}
                        onClick={() => {
                            setLoading(true);
                            carregarDados();
                        }}
                        type="default"
                    >
                        Atualizar
                    </Button>
                </Space>
            </div>

            {/* 3 colunas superiores */}
            <Row gutter={16}>
                {/* ── COLUNA 1: Bebidas Agora ────────── */}
                <Col xs={24} md={8}>
                    <Card
                        title={
                            <Space>
                                <CoffeeOutlined
                                    style={{ color: "#1890ff" }}
                                />
                                <span>Bebidas Agora</span>
                                <Badge
                                    count={fila.bebidas_agora.length}
                                    style={{ backgroundColor: "#1890ff" }}
                                />
                            </Space>
                        }
                        style={{
                            minHeight: 400,
                            borderTop: "3px solid #1890ff",
                        }}
                        bodyStyle={{
                            maxHeight: 500,
                            overflowY: "auto",
                            padding: 12,
                        }}
                    >
                        {fila.bebidas_agora.length === 0 ? (
                            <Empty
                                description="Nenhuma bebida pendente"
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                        ) : (
                            fila.bebidas_agora.map((pedido) => (
                                <Card
                                    key={`bebida-${pedido.id}`}
                                    size="small"
                                    style={{
                                        marginBottom: 8,
                                        borderLeft: "4px solid #1890ff",
                                    }}
                                >
                                    <div
                                        style={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            marginBottom: 4,
                                        }}
                                    >
                                        <Text strong>
                                            Senha{" "}
                                            {formatarSenha(
                                                pedido.senha_diaria
                                            )}
                                        </Text>
                                        <Text
                                            type="secondary"
                                            style={{ fontSize: 11 }}
                                        >
                                            {formatarHora(pedido.created_at)}
                                        </Text>
                                    </div>
                                    <div
                                        style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 6,
                                            backgroundColor: "#E6F4FF",
                                            border: "1px solid #91CAFF",
                                            borderRadius: 6,
                                            padding: "4px 8px",
                                            marginBottom: 8,
                                        }}
                                    >
                                        <UserOutlined style={{ color: "#0958D9", fontSize: 14 }} />
                                        <span style={{ fontSize: 14, fontWeight: "bold", color: "#002C8C", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                            {pedido.user?.name || "Cliente não informado"}
                                        </span>
                                    </div>
                                    {pedido.itens?.map((item) => (
                                        <div
                                            key={item.id}
                                            style={{ marginBottom: 2 }}
                                        >
                                            <Text style={{ fontSize: 13 }}>
                                                {item.quantidade}x{" "}
                                                {item.produto?.nome}
                                            </Text>
                                        </div>
                                    ))}
                                    <Button
                                        type="primary"
                                        size="small"
                                        icon={<CheckCircleOutlined />}
                                        onClick={() =>
                                            entregarBebida(pedido.id)
                                        }
                                        loading={actionLoading === pedido.id}
                                        style={{ marginTop: 8, width: "100%" }}
                                    >
                                        Entregue
                                    </Button>
                                </Card>
                            ))
                        )}
                    </Card>
                </Col>

                {/* ── COLUNA 2: Pendentes ────────────── */}
                <Col xs={24} md={8}>
                    <Card
                        title={
                            <Space>
                                <ShoppingCartOutlined
                                    style={{ color: "#faad14" }}
                                />
                                <span>Pendentes</span>
                                <Badge
                                    count={fila.pendentes.length}
                                    style={{ backgroundColor: "#faad14" }}
                                />
                            </Space>
                        }
                        style={{
                            minHeight: 400,
                            borderTop: "3px solid #faad14",
                        }}
                        bodyStyle={{
                            maxHeight: 500,
                            overflowY: "auto",
                            padding: 12,
                        }}
                    >
                        {fila.pendentes.length === 0 ? (
                            <Empty
                                description="Fila vazia!"
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                        ) : (
                            fila.pendentes.map((pedido, index) => (
                                <Card
                                    key={`pendente-${pedido.id}`}
                                    size="small"
                                    style={{
                                        marginBottom: 8,
                                        borderLeft: "4px solid #faad14",
                                    }}
                                >
                                    <div
                                        style={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            marginBottom: 4,
                                        }}
                                    >
                                        <Space>
                                            <Tag color="gold">
                                                {index + 1}º
                                            </Tag>
                                            <Text strong>
                                                Senha{" "}
                                                {formatarSenha(
                                                    pedido.senha_diaria
                                                )}
                                            </Text>
                                        </Space>
                                        <Text
                                            type="secondary"
                                            style={{ fontSize: 11 }}
                                        >
                                            {formatarHora(pedido.created_at)}
                                        </Text>
                                    </div>
                                    <div
                                        style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 6,
                                            backgroundColor: "#FFFBE6",
                                            border: "1px solid #FFE58F",
                                            borderRadius: 6,
                                            padding: "4px 8px",
                                            marginTop: 4,
                                            marginBottom: 8,
                                        }}
                                    >
                                        <UserOutlined style={{ color: "#D48806", fontSize: 14 }} />
                                        <span style={{ fontSize: 14, fontWeight: "bold", color: "#613400", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                            {pedido.user?.name || "Cliente não informado"}
                                        </span>
                                    </div>
                                    {pedido.itens?.map((item) => (
                                        <div key={item.id}>
                                            <Text style={{ fontSize: 13 }}>
                                                {item.quantidade}x{" "}
                                                {item.produto?.nome}
                                            </Text>
                                            {item.observacao && (
                                                <Text
                                                    type="warning"
                                                    style={{
                                                        fontSize: 11,
                                                        display: "block",
                                                        fontStyle: "italic",
                                                    }}
                                                >
                                                    "{item.observacao}"
                                                </Text>
                                            )}
                                        </div>
                                    ))}
                                    <Text
                                        style={{
                                            fontSize: 12,
                                            display: "block",
                                            marginTop: 4,
                                        }}
                                    >
                                        💰 R${" "}
                                        {Number(pedido.valor_total).toFixed(2)}
                                    </Text>
                                    <Button
                                        type="primary"
                                        size="small"
                                        icon={<FireOutlined />}
                                        onClick={() =>
                                            prepararPedido(pedido.id)
                                        }
                                        loading={actionLoading === pedido.id}
                                        style={{
                                            marginTop: 8,
                                            width: "100%",
                                            background: "#fa8c16",
                                            borderColor: "#fa8c16",
                                        }}
                                    >
                                        Preparar
                                    </Button>
                                </Card>
                            ))
                        )}
                    </Card>
                </Col>

                {/* ── COLUNA 3: Em Preparo ───────────── */}
                <Col xs={24} md={8}>
                    <Card
                        title={
                            <Space>
                                <FireOutlined
                                    style={{ color: "#f5222d" }}
                                />
                                <span>Em Preparo</span>
                                <Badge
                                    count={fila.em_preparo.length}
                                    style={{ backgroundColor: "#f5222d" }}
                                />
                            </Space>
                        }
                        style={{
                            minHeight: 400,
                            borderTop: "3px solid #f5222d",
                        }}
                        bodyStyle={{
                            maxHeight: 500,
                            overflowY: "auto",
                            padding: 12,
                        }}
                    >
                        {fila.em_preparo.length === 0 ? (
                            <Empty
                                description="Nenhum pedido em preparo"
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                        ) : (
                            fila.em_preparo.map((pedido) => (
                                <Card
                                    key={`preparo-${pedido.id}`}
                                    size="small"
                                    style={{
                                        marginBottom: 8,
                                        borderLeft: "4px solid #f5222d",
                                    }}
                                >
                                    <div
                                        style={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            marginBottom: 4,
                                        }}
                                    >
                                        <Text strong>
                                            Senha{" "}
                                            {formatarSenha(
                                                pedido.senha_diaria
                                            )}
                                        </Text>
                                        <Tag color="red">
                                            {pedido.preparador?.name || "—"}
                                        </Tag>
                                    </div>
                                    <div
                                        style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 6,
                                            backgroundColor: "#FFF1F0",
                                            border: "1px solid #FFA39E",
                                            borderRadius: 6,
                                            padding: "4px 8px",
                                            marginTop: 4,
                                            marginBottom: 8,
                                        }}
                                    >
                                        <UserOutlined style={{ color: "#CF1322", fontSize: 14 }} />
                                        <span style={{ fontSize: 14, fontWeight: "bold", color: "#820014", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                            {pedido.user?.name || "Cliente não informado"}
                                        </span>
                                    </div>
                                    {pedido.itens?.map((item) => (
                                        <div key={item.id}>
                                            <Text style={{ fontSize: 13 }}>
                                                {item.quantidade}x{" "}
                                                {item.produto?.nome}
                                                {item.entregue && (
                                                    <Tag
                                                        color="green"
                                                        style={{
                                                            marginLeft: 4,
                                                            fontSize: 10,
                                                        }}
                                                    >
                                                        ✓
                                                    </Tag>
                                                )}
                                            </Text>
                                            {item.observacao && (
                                                <Text
                                                    type="warning"
                                                    style={{
                                                        fontSize: 11,
                                                        display: "block",
                                                        fontStyle: "italic",
                                                    }}
                                                >
                                                    "{item.observacao}"
                                                </Text>
                                            )}
                                        </div>
                                    ))}
                                    <Button
                                        type="primary"
                                        size="small"
                                        icon={<CheckCircleOutlined />}
                                        onClick={() =>
                                            marcarPronto(pedido.id)
                                        }
                                        loading={actionLoading === pedido.id}
                                        style={{
                                            marginTop: 8,
                                            width: "100%",
                                            background: "#52c41a",
                                            borderColor: "#52c41a",
                                        }}
                                    >
                                        Pronto
                                    </Button>
                                </Card>
                            ))
                        )}
                    </Card>
                </Col>
            </Row>

            {/* ── BARRA INFERIOR: Prontos ────────────── */}
            <Card
                title={
                    <Space>
                        <CheckCircleOutlined style={{ color: "#52c41a" }} />
                        <span>Prontos para Retirada</span>
                        <Badge
                            count={fila.prontos.length}
                            style={{ backgroundColor: "#52c41a" }}
                        />
                    </Space>
                }
                style={{
                    marginTop: 16,
                    borderTop: "3px solid #52c41a",
                }}
            >
                {fila.prontos.length === 0 ? (
                    <Empty
                        description="Nenhum pedido pronto"
                        image={Empty.PRESENTED_IMAGE_SIMPLE}
                    />
                ) : (
                    <Row gutter={[12, 12]}>
                        {fila.prontos.map((pedido) => (
                            <Col
                                key={`pronto-${pedido.id}`}
                                xs={24}
                                sm={12}
                                md={8}
                                lg={6}
                            >
                                <Card
                                    size="small"
                                    style={{
                                        borderLeft: "4px solid #52c41a",
                                        textAlign: "center",
                                    }}
                                >
                                    <Text
                                        strong
                                        style={{
                                            fontSize: 18,
                                            display: "block",
                                        }}
                                    >
                                        Senha{" "}
                                        {formatarSenha(pedido.senha_diaria)}
                                    </Text>
                                    <div
                                        style={{
                                            backgroundColor: "#F6FFED",
                                            border: "1.5px solid #52c41a",
                                            borderRadius: 8,
                                            padding: "6px 8px",
                                            margin: "6px 0 10px 0",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            gap: 6,
                                        }}
                                    >
                                        <UserOutlined style={{ color: "#389E0D", fontSize: 15 }} />
                                        <span style={{ fontSize: 15, fontWeight: "800", color: "#135200", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                            {pedido.user?.name || "Cliente não informado"}
                                        </span>
                                    </div>
                                    <Space
                                        wrap
                                        style={{
                                            justifyContent: "center",
                                            width: "100%",
                                        }}
                                    >
                                        <Tooltip title="Entregar este pedido">
                                            <Button
                                                type="primary"
                                                size="small"
                                                icon={
                                                    <CheckCircleOutlined />
                                                }
                                                onClick={() =>
                                                    setEntregaModal({
                                                        pedido,
                                                        comProximo: false,
                                                    })
                                                }
                                                style={{
                                                    background: "#52c41a",
                                                    borderColor: "#52c41a",
                                                }}
                                            >
                                                Entregar
                                            </Button>
                                        </Tooltip>
                                        <Tooltip title="Entregar e pegar próximo pedido">
                                            <Button
                                                type="primary"
                                                size="small"
                                                icon={
                                                    <CheckCircleOutlined />
                                                }
                                                onClick={() =>
                                                    setEntregaModal({
                                                        pedido,
                                                        comProximo: true,
                                                    })
                                                }
                                                style={{
                                                    background: "#13c2c2",
                                                    borderColor: "#13c2c2",
                                                }}
                                            >
                                                Entregar + Próximo
                                            </Button>
                                        </Tooltip>
                                        <Tooltip title="Desfazer (voltar para Em Preparo)">
                                            <Button
                                                size="small"
                                                icon={<UndoOutlined />}
                                                onClick={() =>
                                                    desfazerAcao(pedido.id)
                                                }
                                                loading={
                                                    actionLoading === pedido.id
                                                }
                                            >
                                                Desfazer
                                            </Button>
                                        </Tooltip>
                                    </Space>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                )}
            </Card>

            {/* ── Modal de Confirmação de Entrega ──── */}
            <Modal
                open={entregaModal !== null}
                title={
                    <Space>
                        <ExclamationCircleOutlined
                            style={{ color: "#faad14", fontSize: 20 }}
                        />
                        <span>Confirmar Entrega</span>
                    </Space>
                }
                onCancel={() => setEntregaModal(null)}
                footer={[
                    <Button
                        key="cancel"
                        danger
                        size="large"
                        onClick={() => setEntregaModal(null)}
                    >
                        ❌ Não Confere
                    </Button>,
                    <Button
                        key="confirm"
                        type="primary"
                        size="large"
                        loading={
                            actionLoading === entregaModal?.pedido.id
                        }
                        onClick={confirmarEntrega}
                        style={{
                            background: "#52c41a",
                            borderColor: "#52c41a",
                        }}
                    >
                        ✅ Confere
                    </Button>,
                ]}
                centered
                width={400}
            >
                {entregaModal && (
                    <div style={{ textAlign: "center", padding: "20px 0" }}>
                        <div
                            style={{
                                backgroundColor: "#F8FAFC",
                                borderRadius: 10,
                                padding: "12px 16px",
                                marginBottom: 16,
                                border: "1px solid #E2E8F0",
                                textAlign: "center",
                            }}
                        >
                            <div style={{ fontSize: 12, color: "#64748B", textTransform: "uppercase", fontWeight: 700 }}>
                                Cliente / Aluno
                            </div>
                            <div style={{ fontSize: 19, fontWeight: 900, color: "#0F1A25", marginTop: 4 }}>
                                <UserOutlined style={{ color: "#FF9430", marginRight: 8 }} />
                                {entregaModal.pedido.user?.name || "Cliente não informado"}
                            </div>
                            <div style={{ fontSize: 15, fontWeight: 700, color: "#EA580C", marginTop: 4 }}>
                                Senha #{formatarSenha(entregaModal.pedido.senha_diaria)}
                            </div>
                        </div>
                        <Divider>Código de Retirada</Divider>
                        <div
                            style={{
                                fontSize: 64,
                                fontWeight: "bold",
                                letterSpacing: 16,
                                color: "#1890ff",
                                fontFamily: "monospace",
                                padding: "16px 0",
                                background: "#f0f5ff",
                                borderRadius: 12,
                                border: "2px dashed #1890ff",
                            }}
                        >
                            {entregaModal.pedido.codigo_retirada}
                        </div>
                        <Text
                            type="secondary"
                            style={{
                                display: "block",
                                marginTop: 12,
                                fontSize: 13,
                            }}
                        >
                            Compare com o código exibido no celular do aluno
                        </Text>
                    </div>
                )}
            </Modal>
        </div>
    );
};
