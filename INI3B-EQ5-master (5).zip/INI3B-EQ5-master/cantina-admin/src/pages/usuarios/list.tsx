import {
    List,
    useTable,
    EditButton,
    DeleteButton,
} from "@refinedev/antd";
import { useNavigate } from "react-router";
import { Table, Space, Tag, Button } from "antd";

export const UsuarioList = () => {

    const { tableProps } = useTable({
        resource: "users",
        syncWithLocation: true,
    });
    
    const navigate = useNavigate();

    return (
        <List>
            <Table {...tableProps} rowKey="id">

                <Table.Column
                    dataIndex="id"
                    title="ID"
                    width={80}
                    sorter
                />

                <Table.Column
                    dataIndex="name"
                    title="Nome"
                    sorter
                />

                <Table.Column
                    dataIndex="email"
                    title="Email"
                    sorter
                />

                {/* Tipo do usuário */}
                <Table.Column
                    dataIndex="tipo"
                    title="Tipo"
                    render={(value) => {
                        let color = "default";

                        if (value === "admin") color = "blue";
                        else if (value === "funcionario") color = "purple";
                        else if (value === "aluno") color = "green";

                        return <Tag color={color}>{value}</Tag>;
                    }}
                />

                {/* Saldo do usuário */}
                <Table.Column
                    dataIndex="saldo"
                    title="Saldo"
                    sorter
                    render={(value) => {
                        const formatted = new Intl.NumberFormat("pt-BR", {
                            style: "currency",
                            currency: "BRL",
                        }).format(value || 0);
                        return <span style={{ fontWeight: "bold", color: "#52c41a" }}>{formatted}</span>;
                    }}
                />

                <Table.Column
                    title="Ações"
                    dataIndex="actions"
                    render={(_, record: any) => (
                        <Space>
                            <EditButton
                                hideText
                                size="small"
                                recordItemId={record.id}
                            />

                            <DeleteButton
                                hideText
                                size="small"
                                recordItemId={record.id}
                            />
                        </Space>
                    )}
                />

            </Table>
        </List>
    );
};