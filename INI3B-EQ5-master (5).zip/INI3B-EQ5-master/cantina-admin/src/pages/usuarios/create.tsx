import { Create, useForm } from "@refinedev/antd";
import { Form, Input, Select, InputNumber } from "antd";

// O nome aqui PRECISA ser UsuarioCreate para bater com o seu App.tsx
export const UsuarioCreate = () => {
    const { formProps, saveButtonProps } = useForm();

    return (
        <Create saveButtonProps={saveButtonProps}>
            <Form {...formProps} layout="vertical">
                <Form.Item 
                    label="Nome Completo" 
                    name="name" 
                    rules={[{ required: true, message: "O nome é obrigatório" }]}
                >
                    <Input placeholder="Digite o nome do usuário" />
                </Form.Item>

                <Form.Item 
                    label="E-mail" 
                    name="email" 
                    rules={[
                        { required: true, message: "O e-mail é obrigatório" },
                        { type: "email", message: "Insira um e-mail válido" }
                    ]}
                >
                    <Input placeholder="exemplo@email.com" />
                </Form.Item>

                <Form.Item 
                    label="Senha" 
                    name="password" 
                    rules={[{ required: true, min: 6, message: "A senha deve ter pelo menos 6 caracteres" }]}
                >
                    <Input.Password placeholder="Digite a senha" />
                </Form.Item>

                <Form.Item label="Tipo de Usuário" name="tipo" initialValue="aluno">
                    <Select options={[
                        { label: "Aluno", value: "aluno" },
                        { label: "Admin", value: "admin" },
                    ]} />
                </Form.Item>

                <Form.Item label="Saldo Inicial" name="saldo" initialValue={0}>
                    <InputNumber 
                        prefix="R$" 
                        style={{ width: "100%" }} 
                        precision={2} 
                        min={0}
                    />
                </Form.Item>
            </Form>
        </Create>
    );
};