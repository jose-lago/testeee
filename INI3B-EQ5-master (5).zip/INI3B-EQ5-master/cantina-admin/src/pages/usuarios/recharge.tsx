import { useState } from "react";
import {
    Form,
    Input,
    InputNumber,
    Button,
    Card,
    message,
    notification,
    Modal,
    Alert,
    Result,
    Typography,
    Divider,
    Space,
    Tag,
} from "antd";
import {
    SearchOutlined,
    PlusOutlined,
    CheckCircleOutlined,
    WalletOutlined,
    UserOutlined,
} from "@ant-design/icons";
import api from "../../services/api";

const { Title, Text } = Typography;

interface RecargaSucesso {
    nome: string;
    email: string;
    valor: number;
    saldoAnterior: number;
    saldoPosterior: number;
    descricao?: string;
    dataHora: string;
}

const formatarBRL = (valor: number) => {
    return new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
    }).format(valor || 0);
};

export const UsuarioRecharge = () => {
    const [loadingSearch, setLoadingSearch] = useState(false);
    const [loadingRecharge, setLoadingRecharge] = useState(false);
    const [user, setUser] = useState<any>(null);
    const [recargaSucesso, setRecargaSucesso] = useState<RecargaSucesso | null>(null);
    const [modalSucessoAberto, setModalSucessoAberto] = useState(false);
    const [searchForm] = Form.useForm();
    const [rechargeForm] = Form.useForm();

    const onSearch = async (values: any) => {
        const term = values.searchTerm;
        if (!term) return;

        setLoadingSearch(true);
        setUser(null);
        setRecargaSucesso(null);
        try {
            // Verifica se é um número (ID) ou texto (Email)
            const isId = !isNaN(Number(term));
            
            let url = `/users?${isId ? `id=${term}` : `email=${term}`}`;
            
            const response = await api.get(url);
            
            const users = Array.isArray(response.data) ? response.data : [];
            
            if (users.length > 0) {
                setUser(users[0]);
            } else {
                message.error("Nenhum usuário encontrado com este dado.");
            }
        } catch (error) {
            console.error(error);
            message.error("Erro ao buscar usuário.");
        } finally {
            setLoadingSearch(false);
        }
    };

    const onRecharge = async (values: any) => {
        if (!user) return;
        setLoadingRecharge(true);
        try {
            const saldoAnterior = Number(user.saldo || 0);
            const valorAdicionado = Number(values.valor);

            const response = await api.post(`/users/${user.id}/recarregar`, {
                valor: valorAdicionado,
                descricao: values.descricao || "Recarga de saldo via admin",
            });

            const saldoPosterior =
                response.data?.saldo_atual !== undefined
                    ? Number(response.data.saldo_atual)
                    : response.data?.movimentacao?.saldo_posterior !== undefined
                    ? Number(response.data.movimentacao.saldo_posterior)
                    : saldoAnterior + valorAdicionado;

            const dadosSucesso: RecargaSucesso = {
                nome: user.name,
                email: user.email,
                valor: valorAdicionado,
                saldoAnterior,
                saldoPosterior,
                descricao: values.descricao || "Recarga de saldo via admin",
                dataHora: new Date().toLocaleTimeString("pt-BR", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                }),
            };

            setRecargaSucesso(dadosSucesso);
            setModalSucessoAberto(true);

            // Notificação lateral que fica visível
            notification.success({
                message: "Recarga Efetuada!",
                description: `${formatarBRL(valorAdicionado)} creditado para ${user.name}. Novo saldo: ${formatarBRL(saldoPosterior)}`,
                placement: "topRight",
                duration: 5,
            });

            message.success("Saldo recarregado com sucesso!");

            // Atualizar o usuário na tela com o novo saldo
            const updatedUserResponse = await api.get(`/users/${user.id}`);
            setUser(updatedUserResponse.data);

            rechargeForm.resetFields();
        } catch (error: any) {
            console.error("Erro na recarga:", error);
            message.error(error.response?.data?.message || "Erro ao recarregar saldo.");
        } finally {
            setLoadingRecharge(false);
        }
    };

    return (
        <div style={{ maxWidth: 640, margin: "0 auto" }}>
            <Card
                title={
                    <Space>
                        <WalletOutlined style={{ color: "#52c41a", fontSize: 20 }} />
                        <Title level={4} style={{ margin: 0 }}>
                            Adicionar Saldo
                        </Title>
                    </Space>
                }
            >
                {/* Banner de Sucesso persistente quando a recarga ocorre */}
                {recargaSucesso && (
                    <Alert
                        message={
                            <Space>
                                <CheckCircleOutlined style={{ color: "#52c41a", fontSize: 16 }} />
                                <strong>Recarga de Saldo Confirmada com Sucesso!</strong>
                            </Space>
                        }
                        description={
                            <div style={{ marginTop: 6, lineHeight: 1.6 }}>
                                Foram adicionados <strong>{formatarBRL(recargaSucesso.valor)}</strong> à conta de <strong>{recargaSucesso.nome}</strong> às {recargaSucesso.dataHora}.
                                <br />
                                <span>Saldo anterior: {formatarBRL(recargaSucesso.saldoAnterior)}</span>
                                {" ➔ "}
                                <Text strong style={{ color: "#237804" }}>
                                    Novo saldo: {formatarBRL(recargaSucesso.saldoPosterior)}
                                </Text>
                            </div>
                        }
                        type="success"
                        showIcon={false}
                        closable
                        onClose={() => setRecargaSucesso(null)}
                        style={{
                            marginBottom: 20,
                            backgroundColor: "#f6ffed",
                            border: "1px solid #b7eb8f",
                            borderRadius: 8,
                        }}
                    />
                )}

                <Text type="secondary">Busque o usuário pelo ID ou E-mail para continuar.</Text>

                <Form form={searchForm} layout="inline" onFinish={onSearch} style={{ marginTop: 16 }}>
                    <Form.Item
                        name="searchTerm"
                        rules={[{ required: true, message: "Informe ID ou E-mail." }]}
                    >
                        <Input
                            placeholder="ID ou E-mail do usuário"
                            style={{ width: 320 }}
                            allowClear
                        />
                    </Form.Item>
                    <Form.Item>
                        <Button
                            type="primary"
                            htmlType="submit"
                            loading={loadingSearch}
                            icon={<SearchOutlined />}
                        >
                            Buscar
                        </Button>
                    </Form.Item>
                </Form>

                {user && (
                    <div style={{ marginTop: 28 }}>
                        <Divider />
                        <Space align="center" style={{ marginBottom: 12 }}>
                            <UserOutlined />
                            <Title level={5} style={{ margin: 0 }}>
                                Dados do Usuário
                            </Title>
                            {recargaSucesso && recargaSucesso.email === user.email && (
                                <Tag color="success">Saldo Atualizado ✅</Tag>
                            )}
                        </Space>

                        <div
                            style={{
                                backgroundColor: "#f9f9f9",
                                border: "1px solid #eee",
                                padding: 16,
                                borderRadius: 8,
                                marginBottom: 24,
                            }}
                        >
                            <Space direction="vertical" size={4} style={{ width: "100%" }}>
                                <Text>
                                    <strong>ID:</strong> #{user.id}
                                </Text>
                                <Text>
                                    <strong>Nome:</strong> {user.name}
                                </Text>
                                <Text>
                                    <strong>E-mail:</strong> {user.email}
                                </Text>
                                <Text>
                                    <strong>Tipo:</strong> {user.tipo}
                                </Text>
                                <div style={{ marginTop: 6, paddingTop: 6, borderTop: "1px dashed #e0e0e0" }}>
                                    <Text>
                                        <strong>Saldo Atual: </strong>
                                        <Text strong style={{ color: "#52c41a", fontSize: 18, marginLeft: 6 }}>
                                            {formatarBRL(user.saldo || 0)}
                                        </Text>
                                    </Text>
                                </div>
                            </Space>
                        </div>

                        <Title level={5} style={{ marginBottom: 12 }}>
                            Informações da Recarga
                        </Title>

                        <Form form={rechargeForm} layout="vertical" onFinish={onRecharge}>
                            <Form.Item
                                label="Valor a Adicionar (R$)"
                                name="valor"
                                rules={[
                                    { required: true, message: "Por favor, informe o valor." },
                                    { type: "number", min: 0.01, message: "O valor mínimo é R$ 0,01." },
                                ]}
                            >
                                <InputNumber
                                    prefix="R$"
                                    style={{ width: "100%", maxWidth: 320 }}
                                    precision={2}
                                    min={0.01}
                                    placeholder="0,00"
                                />
                            </Form.Item>

                            <Form.Item
                                label="Descrição/Motivo (opcional)"
                                name="descricao"
                            >
                                <Input placeholder="Ex: Recarga via PIX, dinheiro no caixa, etc." />
                            </Form.Item>

                            <Button
                                type="primary"
                                htmlType="submit"
                                loading={loadingRecharge}
                                icon={<PlusOutlined />}
                                size="large"
                                style={{
                                    backgroundColor: "#52c41a",
                                    borderColor: "#52c41a",
                                    height: 42,
                                    fontWeight: "bold",
                                }}
                            >
                                Confirmar Adição de Saldo
                            </Button>
                        </Form>
                    </div>
                )}
            </Card>

            {/* Modal de Confirmação com Detalhes da Recarga */}
            <Modal
                open={modalSucessoAberto}
                onOk={() => setModalSucessoAberto(false)}
                onCancel={() => setModalSucessoAberto(false)}
                footer={[
                    <Button
                        key="fechar"
                        type="primary"
                        style={{ backgroundColor: "#52c41a", borderColor: "#52c41a" }}
                        onClick={() => setModalSucessoAberto(false)}
                    >
                        Concluir
                    </Button>,
                ]}
                centered
            >
                {recargaSucesso && (
                    <Result
                        status="success"
                        title="Saldo Adicionado com Sucesso!"
                        subTitle={`A conta de ${recargaSucesso.nome} foi creditada com sucesso.`}
                        extra={[
                            <div
                                key="detalhes"
                                style={{
                                    backgroundColor: "#f6ffed",
                                    border: "1px solid #b7eb8f",
                                    padding: 16,
                                    borderRadius: 8,
                                    textAlign: "left",
                                    lineHeight: 1.8,
                                }}
                            >
                                <p style={{ margin: 0 }}>
                                    <strong>Usuário:</strong> {recargaSucesso.nome} ({recargaSucesso.email})
                                </p>
                                <p style={{ margin: 0 }}>
                                    <strong>Valor Adicionado:</strong>{" "}
                                    <Text strong style={{ color: "#52c41a", fontSize: 16 }}>
                                        +{formatarBRL(recargaSucesso.valor)}
                                    </Text>
                                </p>
                                <p style={{ margin: 0 }}>
                                    <strong>Saldo Anterior:</strong> {formatarBRL(recargaSucesso.saldoAnterior)}
                                </p>
                                <Divider style={{ margin: "8px 0" }} />
                                <p style={{ margin: 0, fontSize: 15 }}>
                                    <strong>Novo Saldo Atual:</strong>{" "}
                                    <Text strong style={{ color: "#237804", fontSize: 18 }}>
                                        {formatarBRL(recargaSucesso.saldoPosterior)}
                                    </Text>
                                </p>
                                {recargaSucesso.descricao ? (
                                    <p style={{ margin: "4px 0 0 0", fontSize: 12, color: "#888" }}>
                                        <strong>Descrição:</strong> {recargaSucesso.descricao}
                                    </p>
                                ) : null}
                            </div>,
                        ]}
                    />
                )}
            </Modal>
        </div>
    );
};

