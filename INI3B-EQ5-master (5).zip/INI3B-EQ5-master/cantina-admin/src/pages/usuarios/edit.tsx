import { Edit, useForm } from "@refinedev/antd";
import { Form, Input, Select, InputNumber, Button, Modal, Tag, Space, message, InputRef } from "antd";
import { useState, useRef } from "react";
import * as rfidService from "../../services/rfid";

// O nome aqui PRECISA ser UsuarioEdit
export const UsuarioEdit = () => {
    const { formProps, saveButtonProps } = useForm();
    const [rfidModalOpen, setRfidModalOpen] = useState(false);
    const [rfidInput, setRfidInput] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const inputRef = useRef<InputRef | null>(null);

    const openRfidModal = () => {
        setRfidInput("");
        setRfidModalOpen(true);
        setTimeout(() => inputRef.current?.focus(), 100);
    };

    const handleLink = async (id: any) => {
        if (!rfidInput) {
            message.error('Código RFID é obrigatório');
            return;
        }
        setSubmitting(true);
        try {
            await rfidService.linkRfid(id, rfidInput.trim());
            message.success('Cartão vinculado com sucesso');
            setRfidModalOpen(false);
            window.location.reload();
        } catch (err: any) {
            const msg = err?.response?.data?.message || 'Erro ao vincular cartão';
            message.error(msg);
        } finally {
            setSubmitting(false);
        }
    };

    const handleUnlink = async (id: any) => {
        setSubmitting(true);
        try {
            await rfidService.unlinkRfid(id);
            message.success('Cartão desvinculado');
            window.location.reload();
        } catch (err: any) {
            const msg = err?.response?.data?.message || 'Erro ao desvincular cartão';
            message.error(msg);
        } finally {
            setSubmitting(false);
        }
    };

    const handleBlock = async (id: any) => {
        setSubmitting(true);
        try {
            await rfidService.blockRfid(id);
            message.success('Cartão bloqueado');
            window.location.reload();
        } catch (err: any) {
            const msg = err?.response?.data?.message || 'Erro ao bloquear cartão';
            message.error(msg);
        } finally {
            setSubmitting(false);
        }
    };

    const handleUnblock = async (id: any) => {
        setSubmitting(true);
        try {
            await rfidService.unblockRfid(id);
            message.success('Cartão desbloqueado');
            window.location.reload();
        } catch (err: any) {
            const msg = err?.response?.data?.message || 'Erro ao desbloquear cartão';
            message.error(msg);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Edit saveButtonProps={saveButtonProps}>
            <Form {...formProps} layout="vertical">
                <Form.Item label="Nome" name="name" rules={[{ required: true }]}>
                    <Input />
                </Form.Item>

                <Form.Item label="E-mail" name="email" rules={[{ required: true, type: "email" }]}>
                    <Input />
                </Form.Item>

                <Form.Item 
                    label="Nova Senha (deixe vazio para não alterar)" 
                    name="password"
                    help="Só preencha se quiser mudar a senha do usuário"
                >
                    <Input.Password placeholder="********" />
                </Form.Item>

                <Form.Item label="Tipo de Usuário" name="tipo">
                    <Select options={[
                        { label: "Aluno", value: "aluno" },
                        { label: "Admin", value: "admin" },
                    ]} />
                </Form.Item>

                <Form.Item label="Saldo Atual (Somente Leitura)" name="saldo">
                    <InputNumber 
                        prefix="R$" 
                        style={{ width: "100%" }} 
                        precision={2}
                        disabled
                    />
                </Form.Item>

                {/* RFID management */}
                <Form.Item shouldUpdate noStyle>
                    {() => {
                        const id = (formProps as any).initialValues?.id || (formProps as any).values?.id;
                        const rfid = (formProps as any).initialValues?.rfid_code || (formProps as any).values?.rfid_code;
                        const blocked = (formProps as any).initialValues?.rfid_blocked || (formProps as any).values?.rfid_blocked;

                        return (
                            <div style={{ marginTop: 16 }}>
                                <Space direction="vertical" style={{ width: '100%' }}>
                                    <div>
                                        <strong>Cartão RFID:</strong> {rfid ? <Tag color={blocked ? 'red' : 'green'}>{rfid}</Tag> : <Tag>Não vinculado</Tag>}
                                    </div>
                                    <Space>
                                        <Button onClick={() => openRfidModal()} type="primary">Vincular cartão</Button>
                                        <Button danger onClick={() => handleUnlink(id)} disabled={!rfid}>Desvincular</Button>
                                        {blocked ? (
                                            <Button onClick={() => handleUnblock(id)}>Desbloquear</Button>
                                        ) : (
                                            <Button danger onClick={() => handleBlock(id)} disabled={!rfid}>Bloquear</Button>
                                        )}
                                    </Space>
                                </Space>
                            </div>
                        );
                    }}
                </Form.Item>
            </Form>

            <Modal
                title="Vincular Cartão RFID"
                open={rfidModalOpen}
                onCancel={() => setRfidModalOpen(false)}
                onOk={() => handleLink((formProps as any).initialValues?.id)}
                confirmLoading={submitting}
            >
                <p>Modo de leitura: aproxime o cartão ao leitor. Se o leitor emula teclado, o código irá aparecer automaticamente neste campo.</p>
                <Input
                    ref={inputRef}
                    placeholder="Aproxime o cartão ou cole o código aqui"
                    value={rfidInput}
                    onChange={(e) => setRfidInput(e.target.value)}
                    onPressEnter={() => handleLink((formProps as any).initialValues?.id)}
                />
            </Modal>
        </Edit>
    );
};