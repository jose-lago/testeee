import React from "react";
import { useLogin } from "@refinedev/core";
import { Form, Input, Button, Card, Typography, Checkbox } from "antd";
import { UserOutlined, LockOutlined, LoginOutlined } from "@ant-design/icons";

const { Title, Text } = Typography;

export const Login: React.FC = () => {
  const loginResult = useLogin();
  const login = loginResult.mutate;
  const isLoading = (loginResult as any).isPending ?? (loginResult as any).isLoading ?? false;

  const onFinish = (values: any) => {
    login(values);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#0F1A25",
        padding: "20px",
      }}
    >
      <Card
        style={{
          width: "100%",
          maxWidth: 440,
          borderRadius: 16,
          boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
          border: "1px solid #1E293B",
          backgroundColor: "#FFFFFF",
          padding: "20px 12px",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <Title
            level={1}
            style={{
              margin: 0,
              fontSize: 38,
              fontWeight: 900,
              fontStyle: "italic",
              color: "#3E2723",
            }}
          >
            Saviore
          </Title>
          <Text
            style={{
              fontSize: 15,
              fontWeight: 600,
              color: "#FF9430",
              textTransform: "uppercase",
              letterSpacing: 1,
            }}
          >
            Painel Administrativo
          </Text>
          <div style={{ marginTop: 8, fontSize: 14, color: "#64748B" }}>
            Acesse com sua conta de funcionário ou administrador
          </div>
        </div>

        <Form
          name="loginForm"
          layout="vertical"
          initialValues={{ remember: true }}
          onFinish={onFinish}
          size="large"
          requiredMark={false}
        >
          <Form.Item
            label={<span style={{ fontWeight: 600, color: "#334155" }}>E-mail de Acesso</span>}
            name="email"
            rules={[
              { required: true, message: "Por favor, informe seu e-mail!" },
              { type: "email", message: "Informe um endereço de e-mail válido!" },
            ]}
          >
            <Input
              prefix={<UserOutlined style={{ color: "#94A3B8" }} />}
              placeholder="ex: saulo@gmail.com"
              style={{ height: 46, borderRadius: 10 }}
            />
          </Form.Item>

          <Form.Item
            label={<span style={{ fontWeight: 600, color: "#334155" }}>Senha</span>}
            name="password"
            rules={[{ required: true, message: "Por favor, digite sua senha!" }]}
          >
            <Input.Password
              prefix={<LockOutlined style={{ color: "#94A3B8" }} />}
              placeholder="Digite sua senha"
              style={{ height: 46, borderRadius: 10 }}
            />
          </Form.Item>

          <Form.Item name="remember" valuePropName="checked">
            <Checkbox style={{ color: "#64748B", fontSize: 14 }}>
              Lembrar-me neste dispositivo
            </Checkbox>
          </Form.Item>

          <Form.Item style={{ marginBottom: 12 }}>
            <Button
              type="primary"
              htmlType="submit"
              block
              icon={<LoginOutlined />}
              loading={isLoading}
              style={{
                height: 48,
                fontSize: 16,
                fontWeight: "bold",
                borderRadius: 10,
                backgroundColor: "#FF9430",
                borderColor: "#FF9430",
                boxShadow: "0 4px 12px rgba(255, 148, 48, 0.35)",
              }}
            >
              {isLoading ? "Entrando..." : "Entrar no Painel"}
            </Button>
          </Form.Item>
        </Form>

        <div style={{ textAlign: "center", marginTop: 20, fontSize: 12, color: "#94A3B8" }}>
          Saviore &bull; Sistema de Gestão de Cantina UNESP
        </div>
      </Card>
    </div>
  );
};
export default Login;
