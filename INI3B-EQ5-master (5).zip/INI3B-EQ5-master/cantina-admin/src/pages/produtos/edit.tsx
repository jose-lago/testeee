import { Edit, useForm } from "@refinedev/antd";
import { Form, Input, InputNumber, Switch, Select, Upload, Button } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";

export const ProdutoEdit = () => {
    const { formProps, saveButtonProps, query } = useForm();
    const [fileList, setFileList] = useState<any[]>([]);
    const produto = query?.data?.data;

    // Se o produto já tem uma imagem, mostra como preview
    useEffect(() => {
        if (produto?.imagem_url) {
            setFileList([
                {
                    uid: '-1',
                    name: 'imagem-atual',
                    status: 'done' as const,
                    url: produto.imagem_url,
                },
            ]);
        }
    }, [produto?.imagem_url]);

    // Intercepta o onFinish do formProps para injetar o arquivo
    const originalOnFinish = formProps.onFinish;
    const handleFinish = async (values: any) => {
        const submitValues = { ...values };

        // Se escolheu um novo arquivo, envia-o
        if (fileList.length > 0 && fileList[0].originFileObj) {
            submitValues.imagem = fileList[0].originFileObj;
        }

        return originalOnFinish?.(submitValues);
    };

    return (
        <Edit saveButtonProps={saveButtonProps}>
            <Form {...formProps} layout="vertical" onFinish={handleFinish}>
                <Form.Item
                    label="Nome do Produto"
                    name="nome"
                    rules={[{ required: true, message: 'O nome é obrigatório' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Descrição"
                    name="descricao"
                >
                    <Input.TextArea rows={4} />
                </Form.Item>

                <Form.Item
                    label="Preço Atual"
                    name="preco_atual"
                    rules={[{ required: true, message: 'O preço é obrigatório' }]}
                >
                    <InputNumber min={0} step="0.01" style={{ width: '100%' }} prefix="R$" />
                </Form.Item>

                <Form.Item
                    label="Categoria"
                    name="categoria"
                    rules={[{ required: true, message: 'A categoria é obrigatória' }]}
                >
                    <Select
                        options={[
                            { label: "Almoço", value: "almoco" },
                            { label: "Bebida", value: "bebida" },
                            { label: "Doce", value: "doce" },
                            { label: "Salgado", value: "salgado" },
                        ]}
                    />
                </Form.Item>

                <Form.Item label="Imagem do Produto">
                    {produto?.imagem_url && fileList.length > 0 && !fileList[0].originFileObj && (
                        <div style={{ marginBottom: 12 }}>
                            <img
                                src={produto.imagem_url}
                                alt={produto.nome}
                                style={{ width: 120, borderRadius: 8 }}
                            />
                        </div>
                    )}
                    <Upload
                        listType="picture"
                        maxCount={1}
                        beforeUpload={() => false}
                        fileList={fileList.filter(f => f.originFileObj)}
                        onChange={({ fileList: newFileList }) => setFileList(newFileList)}
                        accept="image/jpeg,image/png,image/webp"
                    >
                        <Button icon={<UploadOutlined />}>
                            {produto?.imagem_url ? 'Trocar Imagem' : 'Selecionar Imagem'}
                        </Button>
                    </Upload>
                </Form.Item>

                <Form.Item
                    label="Disponível para venda?"
                    name="disponivel"
                    valuePropName="checked"
                >
                    <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                </Form.Item>
            </Form>
        </Edit>
    );
};