import { Create, useForm } from "@refinedev/antd";
import { Form, Input, InputNumber, Switch, Select, Upload, Button } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import { useState } from "react";

export const ProdutoCreate = () => {
    const { formProps, saveButtonProps } = useForm();
    const [fileList, setFileList] = useState<any[]>([]);

    // Intercepta o onFinish do formProps para injetar o arquivo
    const originalOnFinish = formProps.onFinish;
    const handleFinish = async (values: any) => {
        const submitValues = { ...values };

        // Pega o arquivo real do componente Upload
        if (fileList.length > 0 && fileList[0].originFileObj) {
            submitValues.imagem = fileList[0].originFileObj;
        }

        return originalOnFinish?.(submitValues);
    };

    return (
        <Create saveButtonProps={saveButtonProps}>
            <Form {...formProps} layout="vertical" onFinish={handleFinish}>
                <Form.Item
                    label="Nome do Produto"
                    name="nome"
                    rules={[{ required: true, message: 'O nome é obrigatório' }]}
                >
                    <Input placeholder="Ex: Coxinha de Frango" />
                </Form.Item>

                <Form.Item
                    label="Descrição"
                    name="descricao"
                >
                    <Input.TextArea rows={4} placeholder="Detalhes do produto..." />
                </Form.Item>

                <Form.Item
                    label="Preço Atual"
                    name="preco_atual"
                    rules={[{ required: true, message: 'O preço é obrigatório' }]}
                >
                    <InputNumber min={0} step="0.01" style={{ width: '100%' }} prefix="R$" />
                </Form.Item>

                <Form.Item
                    label="Categoria"
                    name="categoria"
                    rules={[{ required: true, message: 'A categoria é obrigatória' }]}
                    initialValue="almoco"
                >
                    <Select
                        options={[
                            { label: "Almoço", value: "almoco" },
                            { label: "Bebida", value: "bebida" },
                            { label: "Doce", value: "doce" },
                            { label: "Salgado", value: "salgado" },
                        ]}
                    />
                </Form.Item>

                <Form.Item
                    label="Imagem do Produto"
                >
                    <Upload
                        listType="picture"
                        maxCount={1}
                        beforeUpload={() => false}
                        fileList={fileList}
                        onChange={({ fileList: newFileList }) => setFileList(newFileList)}
                        accept="image/jpeg,image/png,image/webp"
                    >
                        <Button icon={<UploadOutlined />}>Selecionar Imagem</Button>
                    </Upload>
                </Form.Item>

                <Form.Item
                    label="Disponível para venda?"
                    name="disponivel"
                    valuePropName="checked"
                    initialValue={true}
                >
                    <Switch checkedChildren="Sim" unCheckedChildren="Não" />
                </Form.Item>
            </Form>
        </Create>
    );
};