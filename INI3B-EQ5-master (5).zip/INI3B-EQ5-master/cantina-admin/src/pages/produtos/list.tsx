import {
    List,
    useTable,
    EditButton,
    DeleteButton,
    FilterDropdown, // <-- 1. Importe o FilterDropdown
} from "@refinedev/antd";
import { Table, Space, Tag, Input, Select, Image } from "antd"; // <-- 2. Importe o Input, Select e Image

export const ProdutoList = () => {
    const { tableProps } = useTable({
        syncWithLocation: true,
    });

    return (
        <List>
            <Table {...tableProps} rowKey="id">
                <Table.Column dataIndex="id" title="ID" width={80} sorter />
                
                <Table.Column
                    dataIndex="imagem_url"
                    title="Imagem"
                    width={90}
                    render={(value) =>
                        value ? (
                            <Image
                                src={value}
                                alt="Produto"
                                width={60}
                                height={60}
                                style={{ borderRadius: 8, objectFit: 'cover' }}
                                fallback="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mN88P/BfwAJhAPk3KFb2AAAAABJRU5ErkJggg=="
                            />
                        ) : (
                            <div style={{ width: 60, height: 60, borderRadius: 8, background: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#bbb', fontSize: 11 }}>
                                Sem foto
                            </div>
                        )
                    }
                />
                
                {/* ---> COLUNA MODIFICADA COM O CAMPO DE PESQUISA <--- */}
                <Table.Column 
                    dataIndex="nome" 
                    title="Nome do Produto" 
                    sorter 
                    filterDropdown={(props) => (
                        <FilterDropdown {...props}>
                            <Input placeholder="Buscar por ex: x-burguer" />
                        </FilterDropdown>
                    )}
                />
                
                <Table.Column 
                    dataIndex="categoria" 
                    title="Categoria" 
                    sorter
                    filterDropdown={(props) => (
                        <FilterDropdown {...props}>
                            <Select
                                style={{ minWidth: 120 }}
                                placeholder="Filtrar Categoria"
                                options={[
                                    { label: "Almoço", value: "almoco" },
                                    { label: "Bebida", value: "bebida" },
                                    { label: "Doce", value: "doce" },
                                    { label: "Salgado", value: "salgado" },
                                ]}
                            />
                        </FilterDropdown>
                    )}
                    render={(value) => (
                        <Tag color="blue">{String(value).toUpperCase()}</Tag>
                    )}
                />
                
                <Table.Column dataIndex="descricao" title="Descrição" />
                
                <Table.Column 
                    dataIndex="preco_atual" 
                    title="Preço" 
                    sorter 
                    render={(value) => `R$ ${Number(value).toFixed(2)}`}
                />
                
                <Table.Column
                    dataIndex="disponivel"
                    title="Status"
                    sorter
                    render={(value) => (
                        <Tag color={value ? "green" : "red"}>
                            {value ? "Disponível" : "Indisponível"}
                        </Tag>
                    )}
                />
                
                <Table.Column
                    title="Ações"
                    dataIndex="actions"
                    render={(_, record: any) => (
                        <Space>
                            <EditButton hideText size="small" recordItemId={record.id} />
                            <DeleteButton hideText size="small" recordItemId={record.id} />
                        </Space>
                    )}
                />
            </Table>
        </List>
    );
};