import React, { useState, useEffect } from "react";
import {
  Card,
  Switch,
  Typography,
  Space,
  Row,
  Col,
  Statistic,
  Alert,
  Button,
  message,
  Spin,
  Tag,
  Divider,
} from "antd";
import {
  CreditCardOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  UsergroupAddOutlined,
  DollarOutlined,
  SafetyCertificateOutlined,
  SaveOutlined,
} from "@ant-design/icons";
import { api } from "../../services/api";

const { Title, Text, Paragraph } = Typography;

export const ConfiguracoesPage: React.FC = () => {
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [creditoAtivo, setCreditoAtivo] = useState<boolean>(true);
  const [metricas, setMetricas] = useState({
    total_alunos_com_credito: 0,
    total_divida_acumulada: 0,
    limite_padrao: 50.0,
  });

  const carregarConfiguracoes = async () => {
    setLoading(true);
    try {
      const response = await api.get("/configuracoes/credito");
      if (response.data?.success) {
        setCreditoAtivo(Boolean(response.data.credito_ativo));
        if (response.data.metricas) {
          setMetricas(response.data.metricas);
        }
      }
    } catch (err: any) {
      console.error("Erro ao carregar configurações:", err);
      message.error("Não foi possível carregar as configurações do servidor.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarConfiguracoes();
  }, []);

  const handleSalvar = async () => {
    setSaving(true);
    try {
      const response = await api.post("/configuracoes/credito", {
        ativo: creditoAtivo,
      });

      if (response.data?.success) {
        message.success(
          creditoAtivo
            ? "Módulo de Devedores ATIVADO com sucesso!"
            : "Módulo de Devedores DESATIVADO com sucesso!"
        );
      }
    } catch (err: any) {
      const msg =
        err.response?.data?.mensagem ||
        err.response?.data?.message ||
        "Erro ao salvar configuração.";
      message.error(msg);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: "center", padding: "60px 0" }}>
        <Spin size="large" />
        <div style={{ marginTop: 16, fontSize: 16, color: "#666" }}>
          Carregando configurações do sistema...
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: "10px 0" }}>
      <div style={{ marginBottom: 24 }}>
        <Title level={2} style={{ margin: 0, color: "#3E2723" }}>
          ⚙️ Configurações Gerais do Sistema
        </Title>
        <Text style={{ fontSize: 16, color: "#666" }}>
          Gerencie o funcionamento de módulos, limites e recursos disponíveis na cantina.
        </Text>
      </div>

      {/* CARD PRINCIPAL: CONTROLE DE DEVEDORES */}
      <Card
        style={{
          borderRadius: 14,
          boxShadow: "0 4px 14px rgba(0,0,0,0.06)",
          border: "1px solid #E2E8F0",
          marginBottom: 24,
        }}
        title={
          <Space align="center" size="middle">
            <CreditCardOutlined style={{ fontSize: 24, color: "#FF9430" }} />
            <span style={{ fontSize: 18, fontWeight: 700, color: "#3E2723" }}>
              Módulo de Crédito e Devedores
            </span>
          </Space>
        }
        extra={
          <Tag
            color={creditoAtivo ? "green" : "red"}
            style={{ fontSize: 14, padding: "4px 12px" }}
          >
            {creditoAtivo ? (
              <>
                <CheckCircleOutlined /> Ativado
              </>
            ) : (
              <>
                <CloseCircleOutlined /> Desativado
              </>
            )}
          </Tag>
        }
      >
        <Row gutter={[24, 24]} align="middle">
          <Col xs={24} md={16}>
            <Title level={4} style={{ margin: "0 0 8px 0", color: "#1E293B" }}>
              Status da Funcionalidade no Aplicativo e Totem
            </Title>
            <Paragraph style={{ fontSize: 15, color: "#475569", marginBottom: 16, lineHeight: 1.6 }}>
              Ative ou desative globalmente o recurso para <strong>Devedores</strong>.
              Quando desativado, a opção de ativar crédito deixa de estar disponível e novas compras
              a prazo para devedores são bloqueadas imediatamente pelo sistema.
            </Paragraph>

            <Alert
              type={creditoAtivo ? "info" : "warning"}
              showIcon
              message={
                creditoAtivo
                  ? "O serviço está operacional. Cadastros de devedores verificados podem utilizar o limite autorizado."
                  : "O serviço está desativado. Novos cadastros de devedores e novos pedidos a prazo estão bloqueados."
              }
              style={{ fontSize: 14 }}
            />
          </Col>

          <Col xs={24} md={8} style={{ textAlign: "center" }}>
            <div
              style={{
                backgroundColor: "#F8FAFC",
                padding: "24px 20px",
                borderRadius: 12,
                border: "1px solid #E2E8F0",
              }}
            >
              <div style={{ marginBottom: 12, fontSize: 15, fontWeight: 600, color: "#334155" }}>
                Permitir Módulo de Devedores
              </div>
              <Switch
                checked={creditoAtivo}
                onChange={(checked) => setCreditoAtivo(checked)}
                checkedChildren="LIGADO"
                unCheckedChildren="DESLIGADO"
                style={{
                  transform: "scale(1.3)",
                  backgroundColor: creditoAtivo ? "#52c41a" : "#ff4d4f",
                }}
              />
              <div style={{ marginTop: 24 }}>
                <Button
                  type="primary"
                  icon={<SaveOutlined />}
                  loading={saving}
                  onClick={handleSalvar}
                  size="large"
                  style={{
                    width: "100%",
                    height: 44,
                    fontWeight: "bold",
                    backgroundColor: "#FF9430",
                    borderColor: "#FF9430",
                  }}
                >
                  Salvar Alteração
                </Button>
              </div>
            </div>
          </Col>
        </Row>

        <Divider style={{ margin: "28px 0 20px 0" }} />

        {/* MÉTRICAS DE DEVEDORES */}
        <Title level={5} style={{ color: "#3E2723", marginBottom: 16 }}>
          📊 Indicadores Gerais de Devedores
        </Title>
        <Row gutter={[16, 16]}>
          <Col xs={24} sm={8}>
            <Card
              bordered
              style={{
                borderRadius: 10,
                backgroundColor: "#FFF8F0",
                borderColor: "#FFE6D0",
              }}
            >
              <Statistic
                title={<span style={{ fontSize: 14, color: "#7C2D12" }}>Devedores Cadastrados</span>}
                value={metricas.total_alunos_com_credito}
                prefix={<UsergroupAddOutlined style={{ color: "#EA580C" }} />}
                valueStyle={{ color: "#EA580C", fontWeight: "bold" }}
              />
            </Card>
          </Col>

          <Col xs={24} sm={8}>
            <Card
              bordered
              style={{
                borderRadius: 10,
                backgroundColor: "#FEF2F2",
                borderColor: "#FEE2E2",
              }}
            >
              <Statistic
                title={<span style={{ fontSize: 14, color: "#991B1B" }}>Total em Débitos Pendentes</span>}
                value={metricas.total_divida_acumulada}
                precision={2}
                prefix={<DollarOutlined style={{ color: "#DC2626" }} />}
                suffix="R$"
                valueStyle={{ color: "#DC2626", fontWeight: "bold" }}
              />
            </Card>
          </Col>

          <Col xs={24} sm={8}>
            <Card
              bordered
              style={{
                borderRadius: 10,
                backgroundColor: "#F0FDF4",
                borderColor: "#DCFCE7",
              }}
            >
              <Statistic
                title={<span style={{ fontSize: 14, color: "#166534" }}>Limite Padrão por Devedor</span>}
                value={metricas.limite_padrao}
                precision={2}
                prefix={<SafetyCertificateOutlined style={{ color: "#16A34A" }} />}
                suffix="R$"
                valueStyle={{ color: "#16A34A", fontWeight: "bold" }}
              />
            </Card>
          </Col>
        </Row>
      </Card>
    </div>
  );
};
export default ConfiguracoesPage;
