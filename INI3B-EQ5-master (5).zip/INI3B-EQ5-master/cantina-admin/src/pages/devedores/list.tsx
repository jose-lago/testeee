import {
    List,
    useTable,
    FilterDropdown,
} from "@refinedev/antd";
import { useInvalidate } from "@refinedev/core";
import { Table, Space, Tag, Input, Button } from "antd";
import { useState } from "react";
import { DevedoresEdit } from "./edit";

export const DevedoresList = () => {
    const { tableProps } = useTable({
        resource: "credito/devedores",
        syncWithLocation: true,
    });

    const invalidate = useInvalidate();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [alunoSelecionado, setAlunoSelecionado] = useState<any>(null);

    const handleOpenModal = (record: any) => {
        setAlunoSelecionado(record);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setAlunoSelecionado(null);

        // Atualiza a lista depois do pagamento
        invalidate({
            resource: "credito/devedores",
            invalidates: ["list"],
        });
    };

    return (
        <List>
            <Table
                {...tableProps}
                rowKey="id"
            >
                <Table.Column
                    dataIndex="nome"
                    title="Nome"
                    sorter
                    filterDropdown={(props) => (
                        <FilterDropdown {...props}>
                            <Input placeholder="Buscar aluno..." />
                        </FilterDropdown>
                    )}
                />

                <Table.Column
                    dataIndex="ra"
                    title="RA"
                />

                <Table.Column
                    dataIndex="telefone"
                    title="Telefone"
                />

                <Table.Column
                    dataIndex="divida_atual"
                    title="Dívida"
                    sorter
                    render={(value) => (
                        <Tag color="red">
                            R$ {Number(value || 0).toFixed(2)}
                        </Tag>
                    )}
                />

                <Table.Column
                    title="Ações"
                    render={(_, record: any) => (
                        <Space>
                            <Button
                                type="primary"
                                size="small"
                                onClick={() =>
                                    handleOpenModal(record)
                                }
                            >
                                Registrar Pagamento
                            </Button>
                        </Space>
                    )}
                />
            </Table>

            <DevedoresEdit
                open={isModalOpen}
                onClose={handleCloseModal}
                aluno={alunoSelecionado}
            />
        </List>
    );
};