import {
    Modal,
    Form,
    InputNumber,
    Button,
    Space,
    Alert,
} from "antd";
import { useCustomMutation } from "@refinedev/core";
import { useEffect } from "react";

interface RegistrarPagamentoModalProps {
    open: boolean;
    onClose: () => void;
    aluno: any;
}

export const DevedoresEdit = ({
    open,
    onClose,
    aluno,
}: RegistrarPagamentoModalProps) => {
    const { mutate, mutation } = useCustomMutation();

    const [form] = Form.useForm();

    const isLoading = mutation.isPending;

    useEffect(() => {
        if (open) {
            form.resetFields();
        }
    }, [open, form]);

    const dividaAtual = Number(
        aluno?.divida_atual || 0
    );

    const handleFinish = (values: any) => {
        mutate(
            {
                url: "/credito/pagar-divida",
                method: "post",

                // A API Laravel espera user_id
                // e não aluno_id
                values: {
                    user_id: aluno?.user_id,
                    valor: values.valor,
                },
            },
            {
                onSuccess: () => {
                    onClose();
                },
            }
        );
    };

    return (
        <Modal
            title="Registrar Pagamento em Dinheiro"
            open={open}
            onCancel={onClose}
            footer={null}
            destroyOnClose
        >
            {aluno && (
                <>
                    <div
                        style={{
                            marginBottom: 24,
                            padding: 12,
                            background: "#f5f5f5",
                            borderRadius: 8,
                        }}
                    >
                        <p
                            style={{
                                margin: 0,
                                marginBottom: 4,
                            }}
                        >
                            <strong>Aluno:</strong>{" "}
                            {aluno.nome ?? aluno.name}
                        </p>

                        <p
                            style={{
                                margin: 0,
                                marginBottom: 4,
                            }}
                        >
                            <strong>RA:</strong>{" "}
                            {aluno.ra}
                        </p>

                        <p
                            style={{
                                margin: 0,
                                color: "red",
                                fontWeight: "bold",
                            }}
                        >
                            Dívida Atual: R${" "}
                            {dividaAtual.toFixed(2)}
                        </p>
                    </div>

                    <Alert
                        message="Pagamento em dinheiro"
                        description="Informe o valor recebido no balcão."
                        type="info"
                        showIcon
                        style={{
                            marginBottom: 20,
                        }}
                    />
                </>
            )}

            <Form
                layout="vertical"
                form={form}
                onFinish={handleFinish}
            >
                <Form.Item
                    label="Valor Pago no Balcão (R$)"
                    name="valor"
                    rules={[
                        {
                            required: true,
                            message:
                                "O valor é obrigatório",
                        },
                        {
                            type: "number",
                            min: 0.01,
                            message:
                                "O valor deve ser maior que R$ 0,00",
                        },
                        ({
                            validator(_, value) {
                                if (
                                    value !== undefined &&
                                    value !== null &&
                                    Number(value) >
                                        dividaAtual
                                ) {
                                    return Promise.reject(
                                        new Error(
                                            "O valor não pode ser maior que a dívida atual."
                                        )
                                    );
                                }

                                return Promise.resolve();
                            },
                        }),
                    ]}
                >
                    <InputNumber
                        min={0.01}
                        max={dividaAtual}
                        step={0.01}
                        precision={2}
                        style={{
                            width: "100%",
                        }}
                        prefix="R$"
                        autoFocus
                    />
                </Form.Item>

                <Form.Item
                    style={{
                        marginTop: 24,
                        marginBottom: 0,
                        textAlign: "right",
                    }}
                >
                    <Space>
                        <Button
                            onClick={onClose}
                            disabled={isLoading}
                        >
                            Cancelar
                        </Button>

                        <Button
                            type="primary"
                            htmlType="submit"
                            loading={isLoading}
                        >
                            Confirmar Baixa
                        </Button>
                    </Space>
                </Form.Item>
            </Form>
        </Modal>
    );
};