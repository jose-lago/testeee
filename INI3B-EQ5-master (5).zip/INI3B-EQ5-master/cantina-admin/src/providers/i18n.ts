import type { I18nProvider } from "@refinedev/core";

const ptBRTranslations: Record<string, string> = {
    // Botões
    "buttons.create": "Novo",
    "buttons.edit": "Editar",
    "buttons.delete": "Excluir",
    "buttons.save": "Salvar",
    "buttons.cancel": "Cancelar",
    "buttons.filter": "Filtrar",
    "buttons.clear": "Limpar",
    "buttons.show": "Visualizar",
    "buttons.actions": "Ações",
    "buttons.refresh": "Atualizar",
    "buttons.confirm": "Confirmar",
    "buttons.clone": "Clonar",
    "buttons.import": "Importar",
    "buttons.export": "Exportar",
    "buttons.undo": "Desfazer",
    "buttons.redo": "Refazer",
    "buttons.logout": "Sair",
    "buttons.login": "Entrar",
    
    // Ações
    "actions.create": "Criar",
    "actions.edit": "Editar",
    "actions.delete": "Excluir",
    "actions.show": "Visualizar",
    "actions.list": "Listagem",
    "actions.clone": "Clonar",

    // Tabela e Filtros
    "table.actions": "Ações",
    "table.filter.title": "Filtrar",
    "table.filter.clear": "Limpar",
    "table.filter.search": "Buscar",
    "table.filter.confirm": "OK",
    "table.sorter.asc": "Crescente",
    "table.sorter.desc": "Decrescente",
    "table.empty": "Nenhum registro encontrado",

    // Notificações
    "notifications.success": "Sucesso",
    "notifications.error": "Erro",
    "notifications.createSuccess": "Registro criado com sucesso!",
    "notifications.createError": "Erro ao criar o registro.",
    "notifications.editSuccess": "Registro atualizado com sucesso!",
    "notifications.editError": "Erro ao atualizar o registro.",
    "notifications.deleteSuccess": "Registro excluído com sucesso!",
    "notifications.deleteError": "Erro ao excluir o registro.",
    "notifications.undoable": "Você tem {seconds} segundos para desfazer.",

    // Alertas e Confirmações
    "warnWhenUnsavedChanges": "Você possui alterações não salvas. Tem certeza de que deseja sair?",
    "popconfirm.title": "Tem certeza de que deseja excluir este item?",
    "popconfirm.ok": "Sim, excluir",
    "popconfirm.cancel": "Não",

    // Autenticação / Login
    "pages.login.title": "Entrar no Painel",
    "pages.login.signin": "Entrar",
    "pages.login.fields.email": "E-mail de Acesso",
    "pages.login.fields.password": "Senha",
    "pages.login.rememberMe": "Lembrar-me neste dispositivo",
    "pages.login.buttons.submit": "Entrar no Painel",
    "pages.login.errors.validEmail": "Informe um e-mail válido",
    "pages.login.errors.requiredEmail": "O e-mail é obrigatório",
    "pages.login.errors.requiredPassword": "A senha é obrigatória",

    // Páginas de Erro
    "pages.error.404": "Página não encontrada",
    "pages.error.info": "Desculpe, a página solicitada não existe.",
    "pages.error.backHome": "Voltar para o Início",

    // Recursos do Menu e Títulos
    "produtos.produtos": "Produtos",
    "produtos.titles.list": "Produtos",
    "produtos.titles.create": "Novo Produto",
    "produtos.titles.edit": "Editar Produto",
    "produtos.titles.show": "Detalhes do Produto",

    "users.users": "Usuários",
    "users.titles.list": "Usuários",
    "users.titles.create": "Novo Usuário",
    "users.titles.edit": "Editar Usuário",
    "users.titles.show": "Detalhes do Usuário",

    "pedidos.pedidos": "Pedidos",
    "pedidos.titles.list": "Pedidos",
    "pedidos.titles.edit": "Editar Pedido",
    "pedidos.titles.show": "Detalhes do Pedido",

    "kanban.kanban": "Kanban",
    "kanban.titles.list": "Kanban de Pedidos",

    "movimentacoes.movimentacoes": "Movimentações",
    "movimentacoes.titles.list": "Extrato de Movimentações",

    "recarga.recarga": "Adicionar Saldo",
    "recarga.titles.list": "Adicionar Saldo",

    "credito/devedores.credito/devedores": "Devedores",
    "credito/devedores.titles.list": "Devedores",

    "configuracoes.configuracoes": "Configurações",
    "configuracoes.titles.list": "Configurações Gerais",
};

export const i18nProvider: I18nProvider = {
    translate: (key: string, _params?: any, defaultMessage?: string) => {
        return ptBRTranslations[key] || defaultMessage || key;
    },
    changeLocale: async (locale: string) => locale,
    getLocale: () => "pt-BR",
};
