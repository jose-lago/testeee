import { DataProvider } from "@refinedev/core";
import api from "../services/api";

export const dataProvider: DataProvider = {
    // =====================================================
    // LISTAR (Refine Table)
    // =====================================================
    getList: async ({ resource, pagination, sorters, filters }) => {
        const params = new URLSearchParams();

        // PAGINAÇÃO
        const page = (pagination as any)?.current ?? 1;
        const perPage = (pagination as any)?.pageSize ?? 10;

        params.append("page", String(page));
        params.append("per_page", String(perPage));

        // ORDENAÇÃO
        if (sorters && sorters.length > 0) {
            params.append("_sort", sorters[0].field);
            params.append("_order", sorters[0].order ?? "asc");
        }

        // FILTROS
        if (filters && filters.length > 0) {
            filters.forEach((filter: any) => {
                if (filter.field && filter.value !== undefined && filter.value !== null) {
                    params.append(filter.field, String(filter.value));
                }
            });
        }

        // CHAMADA DA API (Laravel)
        const { data: response } = await api.get(
            `/${resource}?${params.toString()}`
        );

        // Lógica flexível para aceitar retorno direto (Master) ou objeto com data (Crédito)
        const lista = Array.isArray(response?.data)
            ? response.data
            : Array.isArray(response)
                ? response
                : [];

        const total = response?.total_devedores ?? lista.length;

        return {
            data: lista,
            total: total,
        };
    },

    // =====================================================
    // PEGAR UM
    // =====================================================
    getOne: async ({ resource, id }) => {
        const { data } = await api.get(`/${resource}/${id}`);
        return { data };
    },

    // =====================================================
    // CRIAR (suporta upload de arquivo via FormData)
    // =====================================================
    create: async ({ resource, variables }) => {
        const vars = variables as Record<string, any>;
        const hasFile = vars.imagem instanceof File || (vars.imagem && vars.imagem[0] instanceof File);

        if (hasFile) {
            const formData = new FormData();
            Object.entries(vars).forEach(([key, value]) => {
                if (key === 'imagem') {
                    const file = value instanceof File ? value : value[0];
                    if (file) formData.append('imagem', file);
                } else if (key === 'disponivel') {
                    formData.append(key, value ? '1' : '0');
                } else if (value !== undefined && value !== null) {
                    formData.append(key, String(value));
                }
            });
            const { data } = await api.post(`/${resource}`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            return { data };
        }

        const { data } = await api.post(`/${resource}`, vars);
        return { data };
    },

    // =====================================================
    // EDITAR (suporta upload de arquivo via FormData com POST + _method=PUT)
    // =====================================================
    update: async ({ resource, id, variables }) => {
        const vars = variables as Record<string, any>;
        
        // Remove campos que a API não aceita no update (são read-only)
        const camposIgnorados = ['id', 'imagem_url', 'created_at', 'updated_at'];
        const varsLimpos: Record<string, any> = {};
        Object.entries(vars).forEach(([key, value]) => {
            if (!camposIgnorados.includes(key)) {
                varsLimpos[key] = value;
            }
        });

        const hasFile = varsLimpos.imagem instanceof File || (varsLimpos.imagem && varsLimpos.imagem[0] instanceof File);

        if (hasFile) {
            const formData = new FormData();
            formData.append('_method', 'PUT');
            Object.entries(varsLimpos).forEach(([key, value]) => {
                if (key === 'imagem') {
                    const file = value instanceof File ? value : value[0];
                    if (file) formData.append('imagem', file);
                } else if (key === 'disponivel') {
                    formData.append(key, value ? '1' : '0');
                } else if (value !== undefined && value !== null) {
                    formData.append(key, String(value));
                }
            });
            const { data } = await api.post(`/${resource}/${id}`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            return { data };
        }

        const { data } = await api.put(`/${resource}/${id}`, varsLimpos);
        return { data };
    },

    // =====================================================
    // DELETAR
    // =====================================================
    deleteOne: async ({ resource, id }) => {
        const { data } = await api.delete(`/${resource}/${id}`);
        return { data };
    },

    // =====================================================
    // CUSTOM (Necessário para registrar pagamentos de crédito)
    // =====================================================
    custom: async ({ url, method, payload, query, headers }) => {
        const { data } = await api.request({
            url,
            method: method?.toUpperCase(),
            data: payload,
            params: query,
            headers,
        });

        return { data };
    },

    // =====================================================
    // URL base da API
    // =====================================================
    getApiUrl: () => (api.defaults.baseURL || "http://127.0.0.1:8000/api"),
};
