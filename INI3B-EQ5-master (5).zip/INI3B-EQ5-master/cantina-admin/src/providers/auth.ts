import api from "../services/api";

export const authProvider = {
    login: async ({ email, password }: any) => {
        try {
            const response = await api.post("/login", {
                email,
                password,
            });

            const { token, user } = response.data;

            // 🔥 padronizando nome do campo (evita bug tipo/status)
            const role = user.tipo || user.status;

            if (role !== "admin" && role !== "funcionario") {
                return {
                    success: false,
                    error: {
                        name: "Acesso negado",
                        message: "Apenas funcionários ou administradores",
                    },
                };
            }

            localStorage.setItem("admin_token", token);
            localStorage.setItem("admin_user", JSON.stringify(user));

            return {
                success: true,
                redirectTo: "/",
            };
        } catch (error) {
            return {
                success: false,
                error: {
                    name: "Erro",
                    message: "Email ou senha inválidos",
                },
            };
        }
    },

    logout: async () => {
        localStorage.removeItem("admin_token");
        localStorage.removeItem("admin_user");

        return {
            success: true,
            redirectTo: "/login",
        };
    },

    check: async () => {
        const token = localStorage.getItem("admin_token");

        if (!token) {
            return {
                authenticated: false,
                redirectTo: "/login",
            };
        }

        return {
            authenticated: true,
        };
    },

    getIdentity: async () => {
        const user = localStorage.getItem("admin_user");

        if (user) {
            return JSON.parse(user);
        }

        return null;
    },

    onError: async (error: any) => {
        if (error?.response?.status === 401) {
            return {
                logout: true,
                redirectTo: "/login",
            };
        }

        return {};
    },
};