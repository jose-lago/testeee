import api from './api';

export async function linkRfid(userId: number | string, rfidCode: string) {
    return api.post(`/users/${userId}/rfid/link`, { rfid_code: rfidCode });
}

export async function unlinkRfid(userId: number | string) {
    return api.post(`/users/${userId}/rfid/unlink`);
}

export async function blockRfid(userId: number | string) {
    return api.post(`/users/${userId}/rfid/block`);
}

export async function unblockRfid(userId: number | string) {
    return api.post(`/users/${userId}/rfid/unblock`);
}

export default { linkRfid, unlinkRfid, blockRfid, unblockRfid };
