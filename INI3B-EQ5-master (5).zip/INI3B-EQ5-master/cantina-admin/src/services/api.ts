import axios from "axios";

// Permite customizar via VITE_API_URL em ambiente local ou produção
const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000/api";

const api = axios.create({
    baseURL: API_URL, 
});

api.interceptors.request.use((config) => {
    const token = localStorage.getItem("admin_token");

    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }

    config.headers["Accept"] = "application/json";

    return config;
});

export { api };
export default api;