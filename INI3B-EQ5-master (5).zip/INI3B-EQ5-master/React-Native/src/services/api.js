import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

// API usada pelo aplicativo. Pode ser customizada por EXPO_PUBLIC_API_URL (.env).
// Sem a variável, mantém o padrão de desenvolvimento local (navegador/emulador).
const API_URL = (
  process.env.EXPO_PUBLIC_API_URL ||
  'http://127.0.0.1:8000/api'
).replace(/\/$/, '');

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// interceptor
api.interceptors.request.use( // cria um interceptor
  async (config) => {
    const token = await AsyncStorage.getItem('token'); // pega o token que você salvou antes

    if (token) { // se existir adiciona no header da requisição
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

export default api;