import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from './api';

// Configuração de comportamento quando o app está aberto (foreground)
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Dispara uma notificação local instantânea no aparelho (com som, vibração e banner).
 */
export async function dispararNotificacaoLocal(titulo, corpo, dados = {}) {
  try {
    if (Platform.OS === 'web') return;

    await Notifications.scheduleNotificationAsync({
      content: {
        title: titulo,
        body: corpo,
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.MAX,
        vibrate: [0, 250, 250, 250],
        data: dados,
        channelId: 'pedidos',
      },
      trigger: null, // dispara imediatamente
    });
  } catch (err) {
    console.log('Erro ao disparar notificação local:', err);
  }
}

/**
 * Solicita permissões, configura canal Android e obtém o Expo Push Token do dispositivo.
 */
export async function registrarPushNotificationsAsync() {
  let token = null;

  try {
    if (Platform.OS === 'web') {
      return null;
    }

    // Configuração obrigatória de Canal para Android (Android 8.0+)
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('pedidos', {
        name: 'Status dos Pedidos',
        description: 'Notificações de preparo e entrega dos seus pedidos na cantina',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF9430',
        enableLights: true,
        enableVibrate: true,
        showBadge: true,
      });
    }

    // Verifica permissão existente
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    // Se ainda não concedida, solicita ao usuário
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.log('Permissão para notificações não concedida pelo usuário.');
      return null;
    }

    // Obtém o projectId configurado no EAS / app.json
    const projectId =
      Constants?.expoConfig?.extra?.eas?.projectId ??
      Constants?.easConfig?.projectId ??
      '90a90b8c-a42e-4729-86f0-449e29998485';

    const tokenResponse = await Notifications.getExpoPushTokenAsync({
      projectId,
    });

    token = tokenResponse.data;
    console.log('Expo Push Token obtido com sucesso:', token);

    // Salva localmente
    await AsyncStorage.setItem('push_token', token);

    return token;
  } catch (error) {
    console.log('Erro ao obter Expo Push Token:', error.message || error);
    return null;
  }
}

/**
 * Envia o token para a API Laravel para vincular ao usuário logado.
 */
export async function sincronizarPushTokenComBackend(tokenParam = null) {
  try {
    let pushToken = tokenParam;

    if (!pushToken) {
      pushToken = await AsyncStorage.getItem('push_token');
    }

    // Se ainda não tem no storage, tenta registrar
    if (!pushToken) {
      pushToken = await registrarPushNotificationsAsync();
    }

    if (!pushToken) {
      console.log('Não foi possível obter push token do aparelho.');
      return false;
    }

    const userToken = await AsyncStorage.getItem('token');
    if (!userToken) {
      console.log('Usuário não autenticado; adiando envio do push token.');
      return false;
    }

    await api.post('/push-token', {
      push_token: pushToken,
    }, {
      headers: {
        Authorization: `Bearer ${userToken}`,
      }
    });

    console.log('Push token sincronizado com a API Laravel com sucesso:', pushToken);
    return true;
  } catch (error) {
    console.log('Erro ao sincronizar push token com o backend:', error.response?.data || error.message);
    return false;
  }
}

/**
 * Remove o push token no backend e localmente ao fazer Logout.
 */
export async function removerPushTokenDoBackend() {
  try {
    const userToken = await AsyncStorage.getItem('token');
    if (userToken) {
      await api.delete('/push-token').catch(() => {});
    }
    await AsyncStorage.removeItem('push_token');
    console.log('Push token removido com sucesso.');
  } catch (error) {
    console.log('Erro ao remover push token:', error.message);
  }
}
