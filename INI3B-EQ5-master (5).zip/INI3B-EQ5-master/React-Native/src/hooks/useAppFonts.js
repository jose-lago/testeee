import { useState, useEffect } from 'react';
import { Platform, Text, TextInput } from 'react-native';
import * as Font from 'expo-font';

export function useAppFonts() {
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    async function loadFonts() {
      try {
        await Font.loadAsync({
          Ahkio: require('../../assets/fonts/Ahkio.ttf'),
          HammersmithOne: require('../../assets/fonts/HammersmithOne-Regular.ttf'),
        });

        // Configura fonte padrão para componentes de texto caso não especificado
        if (Text.defaultProps == null) Text.defaultProps = {};
        Text.defaultProps.style = [{ fontFamily: 'HammersmithOne' }, Text.defaultProps.style];

        if (TextInput.defaultProps == null) TextInput.defaultProps = {};
        TextInput.defaultProps.style = [{ fontFamily: 'HammersmithOne' }, TextInput.defaultProps.style];

        // Injeta fallback CSS na web para garantir renderização perfeita
        if (Platform.OS === 'web' && typeof document !== 'undefined') {
          const styleId = 'saviore-custom-fonts';
          if (!document.getElementById(styleId)) {
            const style = document.createElement('style');
            style.id = styleId;
            style.textContent = `
              body, input, button, textarea, select, div, span, p {
                font-family: 'HammersmithOne', sans-serif !important;
              }
              .font-ahkio {
                font-family: 'Ahkio', cursive, sans-serif !important;
              }
            `;
            document.head.appendChild(style);
          }
        }
      } catch (e) {
        console.warn('Erro ao carregar fontes customizadas:', e);
      } finally {
        setFontsLoaded(true);
      }
    }
    loadFonts();
  }, []);

  return fontsLoaded;
}
