import React, { useState } from 'react';
import api from '../services/api';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  TextInput,
  Alert,
  Platform
} from 'react-native';

export default function TelaCarrinho({ navigation, carrinho, setCarrinho }) {
  const [modalMomentoBebida, setModalMomentoBebida] = useState(false);
  const [momentoBebida, setMomentoBebida] = useState('agora');
  const [modalPagamento, setModalPagamento] = useState(false);
  const [modalCredito, setModalCredito] = useState(false);
  const [pin, setPin] = useState('');

  // Identifica se no carrinho tem almoco e bebida simultaneamente
  const temAlmoco = carrinho.some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('almoc') || cat.includes('almoç') || cat.includes('refeicao');
  });

  const temBebida = carrinho.some(item => {
    const cat = (item.categoria || '').toLowerCase();
    return cat.includes('bebid');
  });

  function removerItem(index) {
    const item = carrinho[index];
    if (item.quantidade > 1) {
      const novoCarrinho = carrinho.map((produto, i) => {
        if (i === index) return { ...produto, quantidade: produto.quantidade - 1 };
        return produto;
      });
      setCarrinho(novoCarrinho);
    } else {
      const novoCarrinho = carrinho.filter((_, i) => i !== index);
      setCarrinho(novoCarrinho);
    }
  }

  function calcularTotal() {
    return carrinho.reduce((total, item) => {
      const preco = parseFloat(String(item.preco).replace(',', '.')) || 0;
      const quantidade = Number(item.quantidade) || 1;
      return total + preco * quantidade;
    }, 0);
  }

  // Ponto de entrada do botão "Finalizar Pedido"
  function iniciarFechamento() {
    if (carrinho.length === 0) return;

    if (temAlmoco && temBebida) {
      // Se tem ambos, pede para o aluno escolher o momento da bebida
      setModalMomentoBebida(true);
    } else {
      // Se só tem bebida ou só tem almoço, define o padrão e vai para pagamento
      setMomentoBebida(temBebida ? 'agora' : 'com_almoco');
      setModalPagamento(true);
    }
  }

  function selecionarMomentoBebida(opcao) {
    setMomentoBebida(opcao);
    setModalMomentoBebida(false);
    setModalPagamento(true);
  }

  async function finalizarPedido(metodoPagamento = 'saldo') {
    try {
      const token = await AsyncStorage.getItem('token');
      const usuarioResponse = await api.get('/me');
      const total = calcularTotal();

      if (metodoPagamento === 'saldo') {
        if (Number(usuarioResponse.data.saldo) < total) {
          alert("Saldo insuficiente!");
          return;
        }
      } else if (metodoPagamento === 'credito') {
        const limite = Number(usuarioResponse.data.credito?.limite || 0);
        const divida = Number(usuarioResponse.data.credito?.divida_atual || 0);
        if ((limite - divida) < total) {
          alert("Limite de crédito insuficiente!");
          return;
        }
      }

      const itens = carrinho.map(item => ({
        produto_id: item.id,
        quantidade: Number(item.quantidade) || 1,
        observacao: item.observacao || null
      }));

      const dadosDoPedido = {
        momento_bebida: momentoBebida,
        forma_pagamento: metodoPagamento,
        pin: metodoPagamento === 'credito' ? pin : null,
        itens: itens
      };

      const response = await api.post('/pedidos/criar', dadosDoPedido, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert('Pedido realizado com sucesso!');
      await AsyncStorage.setItem('pedidoAtual', JSON.stringify(response.data));
      setCarrinho([]);
      await AsyncStorage.removeItem('carrinho');
      navigation.navigate('Fila');

    } catch (error) {
      console.log("ERRO AO FINALIZAR:", error.response?.data || error.message);
      const msg = error.response?.data?.message || "Erro ao finalizar pedido";
      alert(msg);
    }
  }

  function abrirCredito() {
    setModalPagamento(false);
    setPin('');
    setModalCredito(true);
  }

  function confirmarCredito() {
    if (pin.length < 4) {
      alert("Digite um PIN válido.");
      return;
    }
    setModalCredito(false);
    finalizarPedido('credito');
  }

  function pagamentoPresencial() {
    setModalPagamento(false);
    alert(`Pagamento presencial\nValor: R$ ${calcularTotal().toFixed(2)}`);
  }

  return (
    <>
      <ScrollView style={styles.container}>
        <TouchableOpacity onPress={() => navigation.navigate('ProdutosTab')} style={styles.areaVoltar}>
          <Text style={styles.linkText}>← Produtos</Text>
        </TouchableOpacity>
        <Text style={styles.titulo}>Carrinho</Text>
        {carrinho.length === 0 ? (
          <Text style={styles.vazio}>Seu carrinho está vazio</Text>
        ) : (
          carrinho.map((item, index) => (
            <View key={index} style={styles.card}>
              <View>
                <Text style={styles.nome}>{item.nome}</Text>
                <Text>R$ {(Number(item.preco) || Number(item.preco_atual) || 0).toFixed(2)}</Text>
                <Text>Qtd: {item.quantidade || 1}</Text>
              </View>
              <TouchableOpacity onPress={() => removerItem(index)}><Text style={styles.remover}>Remover</Text></TouchableOpacity>
            </View>
          ))
        )}
        <Text style={styles.total}>Total: R$ {calcularTotal().toFixed(2)}</Text>
        <TouchableOpacity style={styles.botaoFinalizar} onPress={iniciarFechamento}>
          <Text style={styles.textoBotao}>Finalizar Pedido</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* MODAL PARA ESCOLHA DO MOMENTO DA BEBIDA (QUANDO TEM ALMOÇO + BEBIDA) */}
      <Modal visible={modalMomentoBebida} transparent={true} animationType="fade">
        <View style={styles.modalFundo}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitulo}>🥤 Entrega da Bebida</Text>
            <Text style={styles.modalDescricao}>
              Identificamos que seu pedido possui <Text style={{ fontWeight: 'bold' }}>almoço</Text> e <Text style={{ fontWeight: 'bold' }}>bebida</Text>. Como você prefere retirar?
            </Text>

            <TouchableOpacity
              style={styles.botaoOpcaoBebida}
              onPress={() => selecionarMomentoBebida('agora')}
            >
              <Text style={styles.tituloOpcao}>🥤 Pegar Bebida Agora</Text>
              <Text style={styles.subtituloOpcao}>
                Retire sua bebida no balcão imediatamente enquanto seu prato é preparado.
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.botaoOpcaoBebida}
              onPress={() => selecionarMomentoBebida('com_almoco')}
            >
              <Text style={styles.tituloOpcao}>🍽️ Junto com o Almoço</Text>
              <Text style={styles.subtituloOpcao}>
                Sua bebida será entregue na bandeja junto com o seu prato quando estiver pronto.
              </Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setModalMomentoBebida(false)}>
              <Text style={styles.cancelar}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* MODAL DE PAGAMENTO */}
      <Modal visible={modalPagamento} transparent={true} animationType="fade">
        <View style={styles.modalFundo}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitulo}>Forma de Pagamento</Text>
            <Text style={styles.modalResumoMomento}>
              Bebida: {momentoBebida === 'agora' ? '🥤 Retirar agora' : '🍽️ Junto com almoço'}
            </Text>
            <TouchableOpacity style={styles.botaoSaldo} onPress={() => { setModalPagamento(false); finalizarPedido('saldo'); }}>
              <Text style={styles.textoBotaoModal}>💰 Saldo da conta</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.botaoCredito} onPress={abrirCredito}>
              <Text style={styles.textoBotaoModal}>💳 Crédito</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.botaoPresencial} onPress={pagamentoPresencial}>
              <Text style={styles.textoBotaoModal}>🏪 Presencial</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setModalPagamento(false)}><Text style={styles.cancelar}>Cancelar</Text></TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* MODAL DE PIN DE CRÉDITO */}
      <Modal visible={modalCredito} transparent={true} animationType="fade">
        <View style={styles.modalFundo}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitulo}>PIN de Crédito</Text>
            <TextInput
              style={styles.inputPin}
              placeholder="PIN"
              keyboardType="numeric"
              secureTextEntry
              maxLength={6}
              value={pin}
              onChangeText={setPin}
              autoComplete="off"
              textContentType="none"
              importantForAutofill="no"
            />
            <TouchableOpacity style={styles.botaoCredito} onPress={confirmarCredito}><Text style={styles.textoBotaoModal}>Confirmar</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => setModalCredito(false)}><Text style={styles.cancelar}>Cancelar</Text></TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: "#FFF8F0" 
  },
  titulo: { 
    fontFamily: "Ahkio",
    fontSize: 32, 
    fontWeight: "bold", 
    textAlign: "center", 
    marginVertical: 10, 
    color: "#3E2723" 
  },
  areaVoltar: { 
    marginTop: 10, 
    marginBottom: 5 
  },
  linkText: { 
    fontFamily: "HammersmithOne",
    color: "#0F1A25", 
    textDecorationLine: "underline", 
    fontSize: 15, 
    fontWeight: "bold" 
  },
  vazio: { 
    fontFamily: "HammersmithOne",
    textAlign: "center", 
    marginTop: 30, 
    fontSize: 16, 
    color: "#555" 
  },
  card: { 
    backgroundColor: "#FAD6A9", 
    padding: 15, 
    borderRadius: 12, 
    marginVertical: 6, 
    flexDirection: "row", 
    justifyContent: "space-between", 
    alignItems: "center" 
  },
  nome: { 
    fontFamily: "HammersmithOne",
    fontSize: 18, 
    fontWeight: "bold", 
    color: "#3E2723", 
    marginBottom: 4 
  },
  remover: { 
    fontFamily: "HammersmithOne",
    color: "#D32F2F", 
    fontWeight: "bold" 
  },
  total: { 
    fontFamily: "Ahkio",
    fontSize: 28, 
    fontWeight: "bold", 
    marginTop: 20, 
    textAlign: "center", 
    color: "#3E2723" 
  },
  botaoFinalizar: { 
    backgroundColor: "#FF7A00", 
    padding: 15, 
    borderRadius: 12, 
    alignItems: "center", 
    marginTop: 15, 
    marginBottom: 30
  },
  textoBotao: { 
    fontFamily: "HammersmithOne",
    color: "#FFF", 
    fontWeight: "bold", 
    fontSize: 17 
  },
  modalFundo: { 
    flex: 1, backgroundColor: "rgba(0,0,0,0.45)", 
    justifyContent: "center", 
    alignItems: "center" 
  },
  modalContainer: { 
    width: "88%", 
    backgroundColor: "#FFF8F0", 
    borderRadius: 18, 
    padding: 22, 
    elevation: 10 
  },
  modalTitulo: { 
    fontSize: 22, 
    fontWeight: "bold", 
    textAlign: "center", 
    color: "#3E2723", 
    marginBottom: 8 
  },
  modalDescricao: {
    fontSize: 14,
    color: "#475569",
    textAlign: "center",
    marginBottom: 16,
    lineHeight: 20
  },
  modalResumoMomento: {
    fontSize: 13,
    color: "#C85B00",
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 14,
    backgroundColor: "#FFF3E0",
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 8
  },
  botaoOpcaoBebida: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1.5,
    borderColor: "#FF9430",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    elevation: 1
  },
  tituloOpcao: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#3E2723",
    marginBottom: 4
  },
  subtituloOpcao: {
    fontSize: 12,
    color: "#64748B",
    lineHeight: 17
  },
  botaoSaldo: { 
    backgroundColor: "#2E7D32", 
    padding: 15, 
    borderRadius: 12, 
    marginBottom: 12 
  },
  botaoCredito: { 
    backgroundColor: "#1565C0", 
    padding: 15, 
    borderRadius: 12, 
    marginBottom: 12 
  },
  botaoPresencial: { 
    backgroundColor: "#FF9800", 
    padding: 15, borderRadius: 12, 
    marginBottom: 15 
  },
  textoBotaoModal: { 
    color: "#FFF", 
    textAlign: "center", 
    fontWeight: "bold", 
    fontSize: 16 
  },
  inputPin: { 
    borderWidth: 1, 
    borderColor: "#DDD", 
    backgroundColor: "#FFF", 
    borderRadius: 10, 
    padding: 15, 
    textAlign: "center", 
    fontSize: 18, 
    marginBottom: 20 
  },
  cancelar: { 
    color: "#D32F2F", 
    textAlign: "center", 
    fontWeight: "bold", 
    fontSize: 15,
    marginTop: 6
  }
});
