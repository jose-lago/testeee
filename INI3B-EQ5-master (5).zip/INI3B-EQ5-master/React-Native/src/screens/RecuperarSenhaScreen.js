import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import api from '../services/api';

export default function RecuperarSenhaScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [codigo, setCodigo] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmacao, setConfirmacao] = useState('');
  const [codigoSolicitado, setCodigoSolicitado] = useState(false);
  const [carregando, setCarregando] = useState(false);
  const [sucesso, setSucesso] = useState(false);

  const exibirErro = (error, fallback) => {
    const errosValidacao = Object.values(error.response?.data?.errors || {})
      .flat()
      .join('\n');
    const mensagem = [
      error.response?.data?.message || fallback,
      errosValidacao,
    ].filter(Boolean).join('\n');

    Alert.alert(
      'Não foi possível concluir',
      mensagem
    );
  };

  async function solicitarCodigo() {
    setCarregando(true);
    try {
      await api.post('/password/forgot', { email: email.trim() });
      setCodigoSolicitado(true);
      Alert.alert(
        'Solicitação recebida',
        'Se houver uma conta associada a esse e-mail, enviaremos um código de recuperação.'
      );
    } catch (error) {
      exibirErro(error, 'Verifique o e-mail e tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  async function redefinirSenha() {
    if (!/^\d{6}$/.test(codigo.trim())) {
      Alert.alert('Código inválido', 'Informe o código de 6 dígitos recebido por e-mail.');
      return;
    }

    if ([...senha].length !== 6) {
      Alert.alert('Senha inválida', 'A nova senha deve ter exatamente 6 caracteres.');
      return;
    }

    if (senha !== confirmacao) {
      Alert.alert('Senhas diferentes', 'A confirmação da senha não corresponde.');
      return;
    }

    setCarregando(true);
    try {
      await api.post('/password/reset', {
        email: email.trim(),
        codigo: codigo.trim(),
        password: senha,
        password_confirmation: confirmacao,
      });
      setSucesso(true);
      setTimeout(() => navigation.replace('Login'), 1200);
    } catch (error) {
      exibirErro(error, 'Confira o código e os dados da nova senha.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Recuperar senha</Text>
        <Text style={styles.subtitle}>
          Informe seu e-mail para receber um código de recuperação.
        </Text>
      </View>

      <View style={styles.form}>
        {sucesso && (
          <Text style={styles.successText}>
            Senha atualizada. Você já pode entrar com a nova senha.
          </Text>
        )}

        <TextInput
          placeholder="E-mail"
          placeholderTextColor="#999"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          editable={!carregando}
        />

        {codigoSolicitado && (
          <>
            <TextInput
              placeholder="Código de 6 dígitos"
              placeholderTextColor="#999"
              style={styles.input}
              value={codigo}
              onChangeText={setCodigo}
              keyboardType="number-pad"
              maxLength={6}
              editable={!carregando}
            />
            <TextInput
              placeholder="Nova senha (mínimo 8 caracteres)"
              placeholderTextColor="#999"
              style={styles.input}
              value={senha}
              onChangeText={setSenha}
              secureTextEntry
              autoComplete="new-password"
              editable={!carregando}
            />
            <TextInput
              placeholder="Confirme a nova senha"
              placeholderTextColor="#999"
              style={styles.input}
              value={confirmacao}
              onChangeText={setConfirmacao}
              secureTextEntry
              autoComplete="new-password"
              editable={!carregando}
            />
          </>
        )}

        <Pressable
          style={[styles.button, carregando && styles.buttonDisabled]}
          onPress={codigoSolicitado ? redefinirSenha : solicitarCodigo}
          disabled={carregando || sucesso}
        >
          {carregando ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.buttonText}>
              {sucesso ? 'Senha atualizada' : codigoSolicitado ? 'Redefinir senha' : 'Enviar código'}
            </Text>
          )}
        </Pressable>

        {codigoSolicitado && (
          <Pressable
            style={styles.secondaryButton}
            onPress={solicitarCodigo}
            disabled={carregando}
          >
            <Text style={styles.secondaryText}>Enviar outro código</Text>
          </Pressable>
        )}
      </View>

      <Pressable
        style={styles.backContainer}
        onPress={() => navigation.navigate('Login')}
      >
        <Text style={styles.backText}>Voltar para o login</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  header: {
    marginBottom: 32,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Ahkio',
    fontSize: 34,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'HammersmithOne',
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
  },
  form: {
    width: '100%',
  },
  input: {
    fontFamily: 'HammersmithOne',
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginBottom: 16,
    fontSize: 16,
    color: '#333',
    elevation: 2,
  },
  button: {
    backgroundColor: '#FF9430',
    minHeight: 54,
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 10,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
  },
  buttonDisabled: {
    opacity: 0.65,
  },
  buttonText: {
    fontFamily: 'HammersmithOne',
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  successText: {
    fontFamily: 'HammersmithOne',
    color: '#2E7D32',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 12,
  },
  secondaryButton: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  secondaryText: {
    fontFamily: 'HammersmithOne',
    color: '#FF9430',
    fontWeight: 'bold',
  },
  backContainer: {
    marginTop: 28,
    alignItems: 'center',
  },
  backText: {
    fontFamily: 'HammersmithOne',
    color: '#666666',
    fontSize: 15,
  },
});
