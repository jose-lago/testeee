import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { typography, colors } from '../tokens/colors';

export default function TelaProdutos({ navigation }) {
  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Produtos</Text>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Almoco')}
      >
        <Text style={styles.textoBotao}>Almoço</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Bebidas')}
      >
        <Text style={styles.textoBotao}>Bebidas</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoCarrinho}
        onPress={() => navigation.navigate('Carrinho')}
      >
        <Text style={styles.textoBotao}>Carrinho</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "#FFF8F0"
  },
  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 44,
    fontWeight: 'bold',
    marginBottom: 40,
    color: "#3E2723"
  },
  botao: {
    backgroundColor: "#FDB368",
    padding: 20, 
    borderRadius: 12,
    marginVertical: 12,
    width: 250,
    alignItems: 'center'
  },
  botaoCarrinho: {
    backgroundColor: "#FF7A00",
    padding: 20, 
    borderRadius: 12,
    marginTop: 25,
    width: 250, 
    alignItems: 'center',
    elevation: 3,
  },
  botaoPerfil: {
    backgroundColor: "#3E2723",
    padding: 20, 
    borderRadius: 12,
    marginTop: 15,
    width: 250, 
    alignItems: 'center',
    elevation: 3,
  },
  textoBotao: {
    fontFamily: typography.fontBody,
    color: "#0F1A25",
    fontWeight: 'bold',
    fontSize: 20 
  },
  textoBotaoPerfil: {
    fontFamily: typography.fontBody,
    color: "#FFF8F0",
    fontWeight: 'bold',
    fontSize: 20 
  }
});