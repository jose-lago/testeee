import { View, Text, TextInput, TouchableOpacity, StyleSheet, Pressable } from 'react-native';
import { useState } from 'react';
import api from '../services/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { sincronizarPushTokenComBackend, registrarPushNotificationsAsync } from '../services/notificationService';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function handleLogin() {
    try {
      let pushToken = await AsyncStorage.getItem('push_token');
      if (!pushToken) {
        pushToken = await registrarPushNotificationsAsync();
      }
      
      const response = await api.post('/login', {
        email: email.trim(),
        password: senha,
        push_token: pushToken || undefined,
      });
  
      await AsyncStorage.setItem('token', response.data.token);
      await AsyncStorage.setItem('user', JSON.stringify(response.data.user));

      // Sincroniza o token de notificações push com o backend
      await sincronizarPushTokenComBackend();
  
      alert('Login realizado com sucesso!');
  
      navigation.navigate("MainTabs");
  
    } catch (error) {
      console.log('Erro login:', error.response?.data || error.message);
      const msg = error.response?.data?.message || (typeof error.response?.data === 'string' ? error.response.data : null) || error.message || 'Erro ao fazer login';
      alert(msg);
    }
  }

  return (
    <View style={styles.container}>
      
      <View style={styles.header}>
        <Text style={styles.title}>Bem-vindo!</Text>
        <Text style={styles.subtitle}>Faça login para continuar</Text>
      </View>

      <View style={styles.form}>
        <TextInput
          placeholder="E-mail"
          placeholderTextColor="#999"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <TextInput
          placeholder="Senha"
          placeholderTextColor="#999"
          style={styles.input}
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />

        <TouchableOpacity style={styles.button} onPress={handleLogin} activeOpacity={0.8}>
          <Text style={styles.buttonText}>Fazer Login</Text>
        </TouchableOpacity>
      </View>

      <Pressable
        style={styles.forgotContainer}
        onPress={() => navigation.navigate('RecuperarSenha')}
      >
        <Text style={styles.forgotText}>Esqueci a senha</Text>
      </Pressable>

      <Pressable style={styles.registerContainer} onPress={() => navigation.navigate("Cadastro")}>
        <Text style={styles.registerText}>
          Não possui uma conta? <Text style={styles.registerLink}>Cadastre-se</Text>
        </Text>
      </Pressable>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0', // Fundo creme
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  header: {
    marginBottom: 40,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Ahkio',
    fontSize: 40,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'HammersmithOne',
    fontSize: 16,
    color: '#666666',
  },
  form: {
    width: '100%',
  },
  input: {
    fontFamily: 'HammersmithOne',
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginBottom: 16,
    fontSize: 16,
    color: '#333',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  button: {
    backgroundColor: '#FF9430',
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 10,
    alignItems: 'center',
    shadowColor: '#FF9430',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
  buttonText: {
    fontFamily: 'HammersmithOne',
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  registerContainer: {
    marginTop: 40,
    alignItems: 'center',
  },
  forgotContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  forgotText: {
    fontFamily: 'HammersmithOne',
    color: '#FF9430',
    fontSize: 15,
    fontWeight: 'bold',
  },
  registerText: {
    fontFamily: 'HammersmithOne',
    fontSize: 15,
    color: '#666666',
  },
  registerLink: {
    fontFamily: 'HammersmithOne',
    color: '#FF9430',
    fontWeight: 'bold',
  }
});