import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api';
import { sincronizarPushTokenComBackend } from '../services/notificationService';
import { typography, colors } from '../tokens/colors';

export default function TelaAlmoco({ navigation, carrinho, setCarrinho }) {

  const [usuario, setUsuario] = useState(null);
  const [pratos, setPratos] = useState([]);
  const [quantidades, setQuantidades] = useState({});

  function handleQuantidade(id, delta) {
    setQuantidades(prev => {
      const current = prev[id] || 1;
      const next = current + delta;
      return { ...prev, [id]: next < 1 ? 1 : next };
    });
  }
  useEffect(() => {
    async function carregarDados() {
      const dados = await AsyncStorage.getItem('user');
      if (dados) {
        setUsuario(JSON.parse(dados));
      }
      sincronizarPushTokenComBackend();
    }
    carregarDados();

  }, []);

  // carrega produtos API
  useEffect(() => {
    async function carregarProdutos() {
      try {
        const response = await api.get('/produtos?disponivel=1');
        const almocos = response.data.filter(
          (item) => item.categoria === 'almoco' && item.disponivel
        );
        setPratos(almocos);
      } catch (error) {
        console.log('ERRO API:', error);
      }
    }
    carregarProdutos();

  }, []);

  function adicionarItem(item) {
    const qtdSelecionada = quantidades[item.id] || 1;
    const index = carrinho.findIndex(c => c.id === item.id);

    if (index >= 0) {
      const novoCarrinho = [...carrinho];
      novoCarrinho[index].quantidade = (novoCarrinho[index].quantidade || 1) + qtdSelecionada;
      setCarrinho(novoCarrinho);
    } else {
      const itemComPreco = {
        ...item,
        preco: Number(item.preco_atual),
        quantidade: qtdSelecionada
      };
      setCarrinho([...carrinho, itemComPreco]);
    }

    alert(`${qtdSelecionada}x ${item.nome} adicionado(s)!`);
    setQuantidades(prev => ({ ...prev, [item.id]: 1 }));
  }

  return (

    <ScrollView style={styles.container}>

      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.areaVoltar}
      >
        <Text style={styles.linkText}>
          ← Produtos
        </Text>
      </TouchableOpacity>

      <Text
        style={{
          fontFamily: typography.fontBody,
          textAlign: 'center',
          color: '#FF7A00',
          fontWeight: 'bold',
          marginTop: 10
        }}
      >
        Bem-vindo(a), {usuario ? (usuario.name || usuario.nome) : 'Usuário'}!
      </Text>

      <Text style={styles.titulo}>Almoço</Text>



      {pratos.map((item) => {
        const precoBase = Number(item.preco_atual);

        return (

          <View key={item.id} style={styles.card}>

            {/* Imagem do produto (real ou placeholder) */}
            {item.imagem_url ? (
              <Image 
                source={{ 
                  uri: item.imagem_url,
                  headers: { 'Bypass-Tunnel-Reminder': 'true' }
                }} 
                style={styles.fotoProdutoLateral} 
                resizeMode="cover"
              />
            ) : (
              <View style={styles.fotoProdutoLateral} />
            )}

            <View style={styles.containerDireita}>

              <Text style={styles.nome}>
                {item.nome}
              </Text>

              <Text>
                {item.descricao}
              </Text>

              <Text style={styles.preco}>
                R$ {precoBase.toFixed(2)}
              </Text>

              <View style={styles.linhaAcao}>
                <View style={styles.stepperContainer}>
                  <TouchableOpacity onPress={() => handleQuantidade(item.id, -1)} style={styles.stepperBotao}>
                    <Text style={styles.stepperTexto}>-</Text>
                  </TouchableOpacity>
                  <Text style={styles.stepperValor}>{quantidades[item.id] || 1}</Text>
                  <TouchableOpacity onPress={() => handleQuantidade(item.id, 1)} style={styles.stepperBotao}>
                    <Text style={styles.stepperTexto}>+</Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity
                  style={styles.botaoAdd}
                  onPress={() => adicionarItem(item)}
                >
                  <Text style={styles.textoBotao}>
                    Adicionar
                  </Text>
                </TouchableOpacity>
              </View>

            </View>

          </View>

        );

      })}

    </ScrollView>

  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#FFF8F0"
  },

  areaVoltar: {
    marginTop: 10,
    marginBottom: 5,
  },

  linkText: {
    fontFamily: typography.fontBody,
    color: '#0F1A25',
    textDecorationLine: 'underline',
    fontSize: 15,
    fontWeight: 'bold'
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 34,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',
    color: "#3E2723"
  },



  card: {
    padding: 15,
    marginVertical: 5,
    backgroundColor: "#FFF8F0",
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FDB368'
  },

  fotoProdutoLateral: {
    width: 90,
    height: 90,
    borderRadius: 10,
    marginRight: 15,
    backgroundColor: '#FDB368'
  },

  containerDireita: {
    flex: 1,
  },

  nome: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    fontWeight: 'bold',
    color: "#0F1A25"
  },

  preco: {
    fontFamily: typography.fontHeading,
    fontSize: 18,
    marginTop: 5,
    fontWeight: 'bold',
    color: "#FF7A00"
  },

  linhaAcao: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
    flexWrap: 'wrap'
  },

  stepperContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDB368',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 2,
    marginRight: 10
  },

  stepperBotao: {
    paddingHorizontal: 10,
    paddingVertical: 5
  },

  stepperTexto: {
    fontFamily: typography.fontBody,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0F1A25'
  },

  stepperValor: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0F1A25',
    marginHorizontal: 10
  },

  botaoAdd: {
    backgroundColor: "#FF9430",
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignItems: 'center'
  },

  textoBotao: {
    fontFamily: typography.fontBody,
    color: "#0F1A25",
    fontWeight: 'bold',
    fontSize: 13
  }

});