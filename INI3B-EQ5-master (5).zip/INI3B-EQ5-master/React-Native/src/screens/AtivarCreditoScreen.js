import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import api from '../services/api';
import { typography, colors } from '../tokens/colors';

export default function AtivarCreditoScreen({ navigation }) {
  const [step, setStep] = useState(1);
  const [cpf, setCpf] = useState('');
  const [ra, setRa] = useState('');
  const [telefone, setTelefone] = useState('');
  const [emailInstitucional, setEmailInstitucional] = useState('');
  const [otp, setOtp] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [verificandoInicial, setVerificandoInicial] = useState(true);

  // Verificação inicial: se o aluno já tem crédito ativo ou se fiado está desativado
  useEffect(() => {
    async function verificarStatusInicial() {
      try {
        const [userRes, configRes] = await Promise.all([
          api.get('/me'),
          api.get('/configuracoes/credito').catch(() => ({ data: { credito_ativo: true } }))
        ]);

        if (configRes.data && configRes.data.credito_ativo === false) {
          alert('A funcionalidade de crédito / fiado está temporariamente desativada pela cantina.');
          navigation.goBack();
          return;
        }

        if (userRes.data?.credito?.verificado) {
          alert('Você já possui uma conta de crédito / fiado ativada!');
          navigation.goBack();
          return;
        }
      } catch (err) {
        console.log('Erro ao verificar status inicial de crédito:', err);
      } finally {
        setVerificandoInicial(false);
      }
    }
    verificarStatusInicial();
  }, [navigation]);

  const formatNumericInput = (value) => value.replace(/[^0-9]/g, '');

  /**
   * Validação matemática oficial do CPF brasileiro (Módulo 11 da Receita Federal).
   */
  const validarCpf = (cpfStr) => {
    const clean = cpfStr.replace(/\D/g, '');
    if (clean.length !== 11) return false;
    // Rejeita sequências com 11 números idênticos
    if (/^(\d)\1{10}$/.test(clean)) return false;

    // 1º dígito verificador
    let soma = 0;
    for (let i = 0; i < 9; i++) {
      soma += parseInt(clean.charAt(i), 10) * (10 - i);
    }
    let resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(clean.charAt(9), 10)) return false;

    // 2º dígito verificador
    soma = 0;
    for (let i = 0; i < 10; i++) {
      soma += parseInt(clean.charAt(i), 10) * (11 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(clean.charAt(10), 10)) return false;

    return true;
  };

  /**
   * Validação de RA: deve conter exatamente 7 dígitos numéricos.
   */
  const validarRa = (raStr) => /^\d{7}$/.test(raStr.trim());

  const validateEmailInstitucional = (value) => /^[a-zA-Z0-9._%+-]+@unesp\.br$/i.test(value.trim());

  const handleSolicitarOtp = async () => {
    const cpfDigits = cpf.replace(/\D/g, '');
    const raDigits = ra.replace(/\D/g, '');
    const telefoneDigits = telefone.replace(/\D/g, '');

    if (!validarCpf(cpfDigits)) {
      alert('Informe um CPF válido de acordo com as regras oficiais brasileiras.');
      return;
    }

    if (!validarRa(raDigits)) {
      alert('O RA deve conter exatamente 7 dígitos numéricos.');
      return;
    }

    if (telefoneDigits.length < 8) {
      alert('Informe um telefone de contato válido.');
      return;
    }

    if (!emailInstitucional.trim() || !validateEmailInstitucional(emailInstitucional)) {
      alert('Informe um e-mail institucional válido do domínio @unesp.br.');
      return;
    }

    setLoading(true);

    try {
      const response = await api.post('/credito/solicitar', {
        email_institucional: emailInstitucional.trim().toLowerCase(),
        cpf: cpfDigits,
        ra: raDigits,
        telefone: telefoneDigits,
      });

      alert(response.data?.mensagem || 'Código OTP enviado para o e-mail institucional.');
      setStep(2);
    } catch (error) {
      const msg =
        error.response?.data?.mensagem ||
        error.response?.data?.message ||
        error.message ||
        'Erro ao solicitar o código OTP.';
      alert(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleVerificarOtp = async () => {
    const cpfDigits = cpf.replace(/\D/g, '');
    const raDigits = ra.replace(/\D/g, '');
    const telefoneDigits = telefone.replace(/\D/g, '');

    if (otp.length !== 6) {
      alert('Digite o código OTP de 6 dígitos.');
      return;
    }

    if (pin.length !== 6) {
      alert('O PIN deve ter exatamente 6 dígitos.');
      return;
    }

    if (pin !== confirmPin) {
      alert('Os PINs digitados não coincidem.');
      return;
    }

    setLoading(true);

    try {
      const response = await api.post('/credito/verificar', {
        cpf: cpfDigits,
        ra: raDigits,
        telefone: telefoneDigits,
        email_institucional: emailInstitucional.trim().toLowerCase(),
        otp,
        pin,
      });

      alert(response.data?.mensagem || 'Crédito / Fiado ativado com sucesso! Limite disponível.');
      navigation.goBack();
    } catch (error) {
      const msg =
        error.response?.data?.mensagem ||
        error.response?.data?.message ||
        error.message ||
        'Erro ao verificar o código OTP.';
      alert(msg);
    } finally {
      setLoading(false);
    }
  };

  if (verificandoInicial) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#FF9430" />
        <Text style={{ marginTop: 12, color: '#3E2723', fontWeight: '600' }}>Verificando disponibilidade...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 80 : 20}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
        nestedScrollEnabled
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Ativar Crédito / Fiado</Text>
          <Text style={styles.subtitle}>
            {step === 1
              ? 'Informe seus dados cadastrais para receber o código OTP no e-mail institucional.'
              : 'Digite o código OTP recebido e crie seu PIN de 6 dígitos para autorizar compras.'}
          </Text>
          <View style={styles.stepBadge}>
            <Text style={styles.stepText}>Etapa {step} de 2</Text>
          </View>
        </View>

        <View style={styles.form}>
          {step === 1 ? (
            <>
              <Text style={styles.fieldLabel}>CPF (11 dígitos)</Text>
              <TextInput
                placeholder="000.000.000-00"
                placeholderTextColor="#999"
                style={styles.input}
                value={cpf}
                onChangeText={(value) => setCpf(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={11}
              />

              <Text style={styles.fieldLabel}>RA Institucional (Exatamente 7 dígitos)</Text>
              <TextInput
                placeholder="Ex: 2457003"
                placeholderTextColor="#999"
                style={styles.input}
                value={ra}
                onChangeText={(value) => setRa(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={7}
              />

              <Text style={styles.fieldLabel}>Telefone Celular / WhatsApp</Text>
              <TextInput
                placeholder="Ex: 14999999999"
                placeholderTextColor="#999"
                style={styles.input}
                value={telefone}
                onChangeText={(value) => setTelefone(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={11}
              />

              <Text style={styles.fieldLabel}>E-mail Institucional UNESP</Text>
              <TextInput
                placeholder="seu.nome@unesp.br"
                placeholderTextColor="#999"
                style={styles.input}
                value={emailInstitucional}
                onChangeText={setEmailInstitucional}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <TouchableOpacity
                style={styles.button}
                onPress={handleSolicitarOtp}
                activeOpacity={0.8}
                disabled={loading}
              >
                <Text style={styles.buttonText}>{loading ? 'Validando e Enviando...' : 'Enviar Código OTP'}</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={styles.fieldLabel}>Código OTP de 6 dígitos (recebido por e-mail)</Text>
              <TextInput
                placeholder="000000"
                placeholderTextColor="#999"
                style={[styles.input, { letterSpacing: 6, textAlign: 'center', fontSize: 24, fontWeight: 'bold' }]}
                value={otp}
                onChangeText={(value) => setOtp(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={6}
                autoComplete="off"
                textContentType="none"
                importantForAutofill="no"
              />

              <Text style={styles.fieldLabel}>Criar PIN de Segurança (6 dígitos numéricos)</Text>
              <TextInput
                placeholder="••••••"
                placeholderTextColor="#999"
                style={[styles.input, { letterSpacing: 4, textAlign: 'center', fontSize: 20 }]}
                value={pin}
                onChangeText={(value) => setPin(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={6}
                secureTextEntry
                autoComplete="off"
                textContentType="none"
                importantForAutofill="no"
              />

              <Text style={styles.fieldLabel}>Confirmar PIN de Segurança</Text>
              <TextInput
                placeholder="••••••"
                placeholderTextColor="#999"
                style={[styles.input, { letterSpacing: 4, textAlign: 'center', fontSize: 20 }]}
                value={confirmPin}
                onChangeText={(value) => setConfirmPin(formatNumericInput(value))}
                keyboardType="numeric"
                maxLength={6}
                secureTextEntry
                autoComplete="off"
                textContentType="none"
                importantForAutofill="no"
              />

              <TouchableOpacity
                style={styles.button}
                onPress={handleVerificarOtp}
                activeOpacity={0.8}
                disabled={loading}
              >
                <Text style={styles.buttonText}>{loading ? 'Verificando e Ativando...' : 'Confirmar e Ativar Crédito'}</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.button, { backgroundColor: '#E0E0E0', marginTop: 10 }]}
                onPress={() => setStep(1)}
                disabled={loading}
              >
                <Text style={[styles.buttonText, { color: '#3E2723' }]}>Voltar / Corrigir Dados</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    paddingHorizontal: 24,
    paddingVertical: 30,
  },
  header: {
    marginBottom: 24,
    alignItems: 'center',
  },
  title: {
    fontFamily: typography.fontHeading,
    fontSize: 34,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 22,
  },
  stepBadge: {
    backgroundColor: '#FFE6D0',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 999,
  },
  stepText: {
    fontFamily: typography.fontBody,
    fontSize: 13,
    fontWeight: '700',
    color: '#C85B00',
  },
  form: {
    width: '100%',
  },
  fieldLabel: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    fontWeight: '700',
    color: '#3E2723',
    marginBottom: 6,
    marginTop: 4,
  },
  input: {
    fontFamily: typography.fontBody,
    backgroundColor: '#FFFFFF',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 14,
    fontSize: 16,
    color: '#333',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  button: {
    backgroundColor: '#FF9430',
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 10,
    alignItems: 'center',
    shadowColor: '#FF9430',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  buttonText: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});