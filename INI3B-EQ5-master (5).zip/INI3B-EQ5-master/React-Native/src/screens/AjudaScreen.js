import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { typography, colors } from '../tokens/colors';

export default function AjudaScreen({ navigation }) {

  return (

    <ScrollView style={styles.container}>

      {/* HEADER */}
      <View style={styles.headerContainer}>

        <Text style={styles.titulo}>
          Ajuda
        </Text>

      </View>

      {/* Botão Voltar */}
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.areaVoltar}
      >
        <Text style={styles.linkText}>← Voltar</Text>
      </TouchableOpacity>

      {/* INFORMAÇÕES */}
      <View style={styles.card}>

        <Text style={styles.sectionTitle}>
          Contato
        </Text>

        <Text style={styles.texto}>
          Em caso de dúvidas ou problemas, entre em contato:
        </Text>

        <Text style={styles.contato}>
          Nome Exemplo
        </Text>

        <Text style={styles.email}>
          email@email.com
        </Text>

        <Text style={styles.contato}>
          Nome Exemplo
        </Text>

        <Text style={styles.email}>
          email@email.com
        </Text>

      </View>

    </ScrollView>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    paddingHorizontal: 25,
  },

  headerContainer: {
    alignItems: 'center',
    marginTop: 50,
    marginBottom: 30,
  },

  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 48,
    fontWeight: '900',
    color: '#3E2723',
  },

  areaVoltar: {
    marginBottom: 20,
  },

  linkText: {
    fontFamily: typography.fontBody,
    color: '#0F1A25',
    textDecorationLine: 'underline',
    fontSize: 15,
    fontWeight: 'bold',
  },

  card: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 18,
    marginBottom: 25,

    elevation: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },

  sectionTitle: {
    fontFamily: typography.fontHeading,
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 15,
  },

  texto: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#0F1A25',
    marginBottom: 8,
  },

  contato: {
    fontFamily: typography.fontHeading,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF9430',
    marginTop: 12,
  },

  email: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    color: '#0F1A25',
    marginBottom: 8,
  },

});
