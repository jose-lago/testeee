import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  RefreshControl,
  TouchableOpacity
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api';
import { sincronizarPushTokenComBackend, dispararNotificacaoLocal } from '../services/notificationService';
import { typography, colors, spacing, radii, shadows } from '../tokens/colors';

const STATUS_PEDIDO_ATIVO = ['pendente', 'preparando', 'pronto'];

export default function FilaScreen({ navigation }) {
  const [pedido, setPedido] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [atualizandoManual, setAtualizandoManual] = useState(false);
  const ultimoStatusRef = useRef(null);

  async function carregarStatusPedido(pedidoId) {
    const response = await api.get(`/pedidos/${pedidoId}/status`);
    const novoStatus = response.data.status;

    if (ultimoStatusRef.current && ultimoStatusRef.current !== novoStatus) {
      if (novoStatus === 'preparando') {
        dispararNotificacaoLocal(
          '👨‍🍳 Pedido em preparo!',
          'Seu pedido começou a ser preparado pela cantina.',
          { status: 'preparando' }
        );
      } else if (novoStatus === 'pronto') {
        dispararNotificacaoLocal(
          '🎉 Pedido pronto!',
          `Seu pedido está pronto para retirada! Código de segurança: ${response.data.codigo_retirada || ''}`,
          { status: 'pronto' }
        );
      } else if (novoStatus === 'entregue') {
        dispararNotificacaoLocal(
          '✅ Pedido entregue!',
          'Seu pedido foi entregue. Bom apetite!',
          { status: 'entregue' }
        );
      }
    }

    ultimoStatusRef.current = novoStatus;

    if (!STATUS_PEDIDO_ATIVO.includes(novoStatus)) {
      return false;
    }

    setPedido(response.data);
    return true;
  }

  async function carregarPedido() {
    try {
      const dados = await AsyncStorage.getItem('pedidoAtual');
      let pedidoSalvo = null;

      if (dados) {
        try {
          pedidoSalvo = JSON.parse(dados);
        } catch {
          pedidoSalvo = null;
        }
      }

      if (pedidoSalvo?.id) {
        try {
          if (await carregarStatusPedido(pedidoSalvo.id)) {
            return;
          }
        } catch {
          // Ponteiro local desatualizado, buscar do backend
        }
      }

      const response = await api.get('/pedidos/meus');
      const pedidosAtivos = (Array.isArray(response.data) ? response.data : [])
        .filter((p) => p?.id && STATUS_PEDIDO_ATIVO.includes(p.status))
        .sort((a, b) => {
          const dataA = Date.parse(a.created_at || '') || 0;
          const dataB = Date.parse(b.created_at || '') || 0;
          return dataB - dataA || Number(b.id) - Number(a.id);
        });

      const pedidoMaisRecente = pedidosAtivos[0];

      if (!pedidoMaisRecente) {
        await AsyncStorage.removeItem('pedidoAtual');
        ultimoStatusRef.current = null;
        setPedido(null);
        return;
      }

      await AsyncStorage.setItem('pedidoAtual', JSON.stringify(pedidoMaisRecente));
      ultimoStatusRef.current = null;
      const carregado = await carregarStatusPedido(pedidoMaisRecente.id);

      if (!carregado) {
        await AsyncStorage.removeItem('pedidoAtual');
        setPedido(null);
      }
    } catch (error) {
      console.log('Erro ao carregar fila:', error.response?.data || error.message);
    } finally {
      setCarregando(false);
      setAtualizandoManual(false);
    }
  }

  const onRefresh = () => {
    setAtualizandoManual(true);
    carregarPedido();
  };

  useEffect(() => {
    sincronizarPushTokenComBackend();
    carregarPedido();
    const interval = setInterval(carregarPedido, 3500);
    return () => clearInterval(interval);
  }, []);

  if (carregando) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.brandPrimary} />
        <Text style={styles.loadingText}>Atualizando fila...</Text>
      </View>
    );
  }

  // Identificação de itens de bebida e status
  const itens = Array.isArray(pedido?.itens) ? pedido.itens : [];
  const itensBebida = itens.filter(
    (item) => (item.produto?.categoria || '').toLowerCase().includes('bebid')
  );
  const temBebida = itensBebida.length > 0;
  const todasBebidasEntregues = temBebida && itensBebida.every((i) => i.entregue);
  const temAlmoco = itens.some((item) => {
    const cat = (item.produto?.categoria || '').toLowerCase();
    return cat.includes('almoc') || cat.includes('almoç') || cat.includes('refeicao');
  });

  const getStatusEtapa = () => {
    if (!pedido) return 1;
    if (pedido.status === 'pronto') return 3;
    if (pedido.status === 'preparando') return 2;
    return 1;
  };

  const etapaAtual = getStatusEtapa();

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={atualizandoManual}
          onRefresh={onRefresh}
          colors={[colors.brandPrimary]}
          tintColor={colors.brandPrimary}
        />
      }
    >
      {/* Cabeçalho */}
      <View style={styles.header}>
        <Text style={styles.titulo}>Fila da Cantina</Text>
        <Text style={styles.subtitulo}>Acompanhe o preparo do seu pedido em tempo real</Text>
      </View>

      {!pedido ? (
        <View style={styles.emptyCard}>
          <View style={styles.emptyIconCircle}>
            <Ionicons name="receipt-outline" size={48} color={colors.brandPrimary} />
          </View>
          <Text style={styles.emptyTitulo}>Nenhum pedido ativo</Text>
          <Text style={styles.emptySubtitulo}>
            Você não possui pedidos na fila no momento. Quando fizer um pedido, ele aparecerá aqui com sua senha e código de retirada.
          </Text>
          <TouchableOpacity
            style={styles.botaoCardapio}
            onPress={() => navigation?.navigate('ProdutosTab')}
            activeOpacity={0.8}
          >
            <Ionicons name="restaurant-outline" size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
            <Text style={styles.botaoCardapioTexto}>Ver Cardápio</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.mainWrapper}>
          {/* Card Principal: Senha Diária e Posição */}
          <View style={styles.cardSenha}>
            <View style={styles.cardSenhaHeader}>
              <View>
                <Text style={styles.senhaLabel}>SUA SENHA DO DIA</Text>
                <Text style={styles.senhaDestaque}>
                  #{pedido.senha_diaria || pedido.senha || pedido.id}
                </Text>
              </View>
              <View style={styles.posicaoBadge}>
                {pedido.status === 'pronto' ? (
                  <View style={styles.badgePronto}>
                    <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                    <Text style={styles.badgeProntoTexto}>PRONTO</Text>
                  </View>
                ) : (
                  <View style={styles.badgeFila}>
                    <Ionicons name="people" size={16} color={colors.brandSecondary} />
                    <Text style={styles.badgeFilaTexto}>
                      {pedido.posicao === 1 ? 'É o próximo!' : `${pedido.posicao}º na fila`}
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Linha de Progresso Visual (Timeline) */}
            <View style={styles.timeline}>
              {/* Etapa 1: Pendente */}
              <View style={styles.timelineStep}>
                <View
                  style={[
                    styles.stepCircle,
                    etapaAtual >= 1 && styles.stepCircleActive,
                    etapaAtual > 1 && styles.stepCircleCompleted,
                  ]}
                >
                  <Ionicons
                    name={etapaAtual > 1 ? "checkmark" : "hourglass-outline"}
                    size={16}
                    color={etapaAtual >= 1 ? "#FFFFFF" : colors.textMuted}
                  />
                </View>
                <Text style={[styles.stepLabel, etapaAtual >= 1 && styles.stepLabelActive]}>
                  Na Fila
                </Text>
              </View>

              <View
                style={[
                  styles.timelineBar,
                  etapaAtual >= 2 && styles.timelineBarActive,
                ]}
              />

              {/* Etapa 2: Preparando */}
              <View style={styles.timelineStep}>
                <View
                  style={[
                    styles.stepCircle,
                    etapaAtual >= 2 && styles.stepCircleActive,
                    etapaAtual > 2 && styles.stepCircleCompleted,
                  ]}
                >
                  <Ionicons
                    name={etapaAtual > 2 ? "checkmark" : "flame-outline"}
                    size={16}
                    color={etapaAtual >= 2 ? "#FFFFFF" : colors.textMuted}
                  />
                </View>
                <Text style={[styles.stepLabel, etapaAtual >= 2 && styles.stepLabelActive]}>
                  Cozinha
                </Text>
              </View>

              <View
                style={[
                  styles.timelineBar,
                  etapaAtual >= 3 && styles.timelineBarActive,
                ]}
              />

              {/* Etapa 3: Pronto */}
              <View style={styles.timelineStep}>
                <View
                  style={[
                    styles.stepCircle,
                    etapaAtual === 3 && styles.stepCircleReady,
                  ]}
                >
                  <Ionicons
                    name="gift-outline"
                    size={16}
                    color={etapaAtual === 3 ? "#FFFFFF" : colors.textMuted}
                  />
                </View>
                <Text style={[styles.stepLabel, etapaAtual === 3 && styles.stepLabelReady]}>
                  Pronto
                </Text>
              </View>
            </View>

            {/* Aviso de Chamada */}
            {pedido.status === 'pronto' ? (
              <View style={styles.avisoProntoContainer}>
                <Ionicons name="megaphone" size={24} color={colors.feedbackSuccess} />
                <Text style={styles.avisoProntoTexto}>
                  SEU PRATO ESTÁ PRONTO! Retire no balcão apresentando o código abaixo.
                </Text>
              </View>
            ) : (
              <Text style={styles.avisoPreparoTexto}>
                {pedido.status === 'preparando'
                  ? '👨‍🍳 O cozinheiro já está preparando sua refeição na cozinha!'
                  : '⏳ Seu pedido aguarda início do preparo na fila da cozinha.'}
              </Text>
            )}
          </View>

          {/* Card de Segurança Anti-Fraude: Código de Retirada */}
          <View style={styles.cardSeguranca}>
            <View style={styles.cardSegurancaHeader}>
              <View style={styles.shieldIconWrapper}>
                <Ionicons name="shield-checkmark" size={20} color="#FFFFFF" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardSegurancaTitulo}>CÓDIGO DE RETIRADA (CONFIRMAÇÃO)</Text>
                <Text style={styles.cardSegurancaSub}>Segurança anti-fraude na entrega</Text>
              </View>
            </View>

            <View style={styles.codigoBox}>
              <Text style={styles.codigoTexto}>
                {pedido.codigo_retirada || '----'}
              </Text>
            </View>

            <View style={styles.codigoInstrucao}>
              <Ionicons name="information-circle-outline" size={16} color={colors.brandSecondary} />
              <Text style={styles.codigoInstrucaoTexto}>
                Apresente este código exclusivo de 4 dígitos ao atendente para receber seu pedido. Isso garante que ninguém retire em seu lugar.
              </Text>
            </View>
          </View>

          {/* Destaque para Bebida (Quando há bebida no pedido) */}
          {temBebida && (
            <View
              style={[
                styles.cardBebida,
                pedido.momento_bebida === 'agora' ? styles.cardBebidaAgora : styles.cardBebidaJunto,
              ]}
            >
              <View style={styles.cardBebidaTop}>
                <Ionicons
                  name={pedido.momento_bebida === 'agora' ? 'flash' : 'restaurant'}
                  size={20}
                  color={pedido.momento_bebida === 'agora' ? '#1565C0' : colors.brandSecondary}
                />
                <Text style={styles.cardBebidaTitulo}>
                  {pedido.momento_bebida === 'agora'
                    ? 'Bebida: Retirada Imediata'
                    : 'Bebida: Junto com o Almoço'}
                </Text>
              </View>

              {pedido.momento_bebida === 'agora' ? (
                todasBebidasEntregues ? (
                  <View style={styles.bebidaStatusEntregue}>
                    <Ionicons name="checkmark-circle" size={18} color={colors.feedbackSuccess} />
                    <Text style={styles.bebidaStatusTextoEntregue}>
                      Bebida já retirada no balcão com sucesso!
                    </Text>
                  </View>
                ) : (
                  <View style={styles.bebidaStatusPendente}>
                    <Ionicons name="alert-circle" size={18} color="#1565C0" />
                    <Text style={styles.bebidaStatusTextoPendente}>
                      Você optou por pegar sua bebida agora! Pode ir até a cantina e apresentar o código de retirada para pegar sua bebida gelada.
                    </Text>
                  </View>
                )
              ) : (
                <Text style={styles.bebidaStatusTextoJunto}>
                  Sua bebida será servida na bandeja junto com o almoço assim que o prato for finalizado pela cozinha.
                </Text>
              )}
            </View>
          )}

          {/* Lista de Itens do Pedido */}
          <View style={styles.cardItens}>
            <Text style={styles.itensTitulo}>Itens do Pedido</Text>
            <View style={styles.divisor} />

            {itens.length === 0 ? (
              <Text style={styles.itemNomeVazio}>Nenhum detalhe de itens disponível.</Text>
            ) : (
              itens.map((item, index) => {
                const isBebida = item.produto?.categoria?.toLowerCase() === 'bebida';
                return (
                  <View key={item.id || index} style={styles.itemLinha}>
                    <View style={styles.itemIconContainer}>
                      <Ionicons
                        name={isBebida ? 'beer-outline' : 'fast-food-outline'}
                        size={20}
                        color={colors.brandSecondary}
                      />
                    </View>
                    <View style={styles.itemInfo}>
                      <Text style={styles.itemNome}>
                        {item.quantidade}x {item.produto?.nome || 'Item do Pedido'}
                      </Text>
                      {item.observacao ? (
                        <Text style={styles.itemObs}>Obs: {item.observacao}</Text>
                      ) : null}
                    </View>
                    <View style={styles.itemTag}>
                      {item.entregue ? (
                        <View style={styles.tagEntregue}>
                          <Ionicons name="checkmark" size={12} color="#FFFFFF" />
                          <Text style={styles.tagEntregueTexto}>Entregue</Text>
                        </View>
                      ) : pedido.status === 'pronto' ? (
                        <View style={styles.tagPronto}>
                          <Text style={styles.tagProntoTexto}>Pronto</Text>
                        </View>
                      ) : (
                        <View style={styles.tagAguardando}>
                          <Text style={styles.tagAguardandoTexto}>
                            {isBebida && pedido.momento_bebida === 'agora' ? 'Disponível' : 'Preparo'}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                );
              })
            )}
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgScreen,
  },
  contentContainer: {
    paddingHorizontal: spacing.pagePadding,
    paddingTop: 45,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.bgScreen,
  },
  loadingText: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeBase,
    color: colors.textSecondary,
    marginTop: spacing.s3,
  },
  header: {
    marginBottom: spacing.s5,
  },
  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 34,
    color: colors.textPrimary,
    fontWeight: 'bold',
  },
  subtitulo: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeBase,
    color: colors.textSecondary,
    marginTop: 2,
  },
  emptyCard: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.lg,
    padding: spacing.insetXl,
    alignItems: 'center',
    marginTop: spacing.s6,
    ...shadows.sm,
  },
  emptyIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFF0DE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.s4,
  },
  emptyTitulo: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    color: colors.textPrimary,
    marginBottom: spacing.s2,
  },
  emptySubtitulo: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeBase,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: spacing.s6,
  },
  botaoCardapio: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.s6,
    paddingVertical: spacing.s3,
    borderRadius: radii.sm,
    ...shadows.brand,
  },
  botaoCardapioTexto: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeBase,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  mainWrapper: {
    gap: spacing.s4,
  },
  // Card Senha Principal
  cardSenha: {
    backgroundColor: colors.bgCard,
    borderRadius: radii.lg,
    padding: spacing.insetLg,
    ...shadows.md,
  },
  cardSenhaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.s4,
  },
  senhaLabel: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.brandSecondaryLight,
    letterSpacing: 1,
  },
  senhaDestaque: {
    fontFamily: typography.fontHeading,
    fontSize: 48,
    fontWeight: 'bold',
    color: colors.brandSecondary,
    lineHeight: 52,
    marginTop: 2,
  },
  posicaoBadge: {
    alignItems: 'flex-end',
  },
  badgeFila: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: spacing.s3,
    paddingVertical: spacing.s2,
    borderRadius: radii.full,
    gap: 6,
    ...shadows.sm,
  },
  badgeFilaTexto: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.brandSecondary,
  },
  badgePronto: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.feedbackSuccess,
    paddingHorizontal: spacing.s3,
    paddingVertical: spacing.s2,
    borderRadius: radii.full,
    gap: 6,
  },
  badgeProntoTexto: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  // Linha do tempo de progresso
  timeline: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: spacing.s3,
    paddingHorizontal: spacing.s2,
  },
  timelineStep: {
    alignItems: 'center',
    width: 60,
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  stepCircleActive: {
    backgroundColor: colors.brandPrimary,
  },
  stepCircleCompleted: {
    backgroundColor: colors.brandSecondary,
  },
  stepCircleReady: {
    backgroundColor: colors.feedbackSuccess,
  },
  stepLabel: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.textMuted,
  },
  stepLabelActive: {
    color: colors.brandSecondary,
    fontWeight: 'bold',
  },
  stepLabelReady: {
    color: colors.feedbackSuccess,
    fontWeight: 'bold',
  },
  timelineBar: {
    flex: 1,
    height: 3,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 4,
    marginBottom: 16,
  },
  timelineBarActive: {
    backgroundColor: colors.brandPrimary,
  },
  avisoProntoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    borderRadius: radii.md,
    padding: spacing.s3,
    gap: spacing.s3,
    marginTop: spacing.s3,
    borderWidth: 1,
    borderColor: '#C8E6C9',
  },
  avisoProntoTexto: {
    flex: 1,
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.feedbackSuccess,
    lineHeight: 18,
  },
  avisoPreparoTexto: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    color: colors.brandSecondaryLight,
    textAlign: 'center',
    marginTop: spacing.s2,
  },
  // Card de Segurança
  cardSeguranca: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.lg,
    padding: spacing.insetLg,
    borderWidth: 1.5,
    borderColor: '#FFE0B2',
    ...shadows.sm,
  },
  cardSegurancaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.s3,
    marginBottom: spacing.s3,
  },
  shieldIconWrapper: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.feedbackSuccess,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardSegurancaTitulo: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  cardSegurancaSub: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.textMuted,
  },
  codigoBox: {
    backgroundColor: '#FFF8F0',
    borderRadius: radii.md,
    paddingVertical: spacing.s3,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.brandPrimary,
    borderStyle: 'dashed',
    marginBottom: spacing.s3,
  },
  codigoTexto: {
    fontFamily: typography.fontHeading,
    fontSize: 36,
    fontWeight: 'bold',
    color: colors.brandPrimary,
    letterSpacing: 6,
  },
  codigoInstrucao: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  codigoInstrucaoTexto: {
    flex: 1,
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.textSecondary,
    lineHeight: 16,
  },
  // Card Bebida
  cardBebida: {
    borderRadius: radii.md,
    padding: spacing.insetMd,
  },
  cardBebidaAgora: {
    backgroundColor: '#E3F2FD',
    borderLeftWidth: 4,
    borderLeftColor: '#1565C0',
  },
  cardBebidaJunto: {
    backgroundColor: '#FFF3E0',
    borderLeftWidth: 4,
    borderLeftColor: colors.brandPrimary,
  },
  cardBebidaTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  cardBebidaTitulo: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  bebidaStatusEntregue: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bebidaStatusTextoEntregue: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.feedbackSuccess,
    fontWeight: '600',
  },
  bebidaStatusPendente: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
  },
  bebidaStatusTextoPendente: {
    flex: 1,
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: '#0D47A1',
    lineHeight: 16,
  },
  bebidaStatusTextoJunto: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.brandSecondaryLight,
    lineHeight: 16,
  },
  // Card Itens
  cardItens: {
    backgroundColor: colors.bgSurface,
    borderRadius: radii.lg,
    padding: spacing.insetLg,
    ...shadows.sm,
  },
  itensTitulo: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeMd,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: spacing.s2,
  },
  divisor: {
    height: 1,
    backgroundColor: colors.borderDefault,
    opacity: 0.4,
    marginBottom: spacing.s3,
  },
  itemLinha: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.s2,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
  },
  itemIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFF8F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.s3,
  },
  itemInfo: {
    flex: 1,
  },
  itemNome: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    fontWeight: 'bold',
    color: colors.textBody,
  },
  itemObs: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeXs,
    color: colors.textMuted,
    fontStyle: 'italic',
  },
  itemNomeVazio: {
    fontFamily: typography.fontBody,
    fontSize: typography.fontSizeSm,
    color: colors.textMuted,
    textAlign: 'center',
    paddingVertical: spacing.s3,
  },
  itemTag: {
    marginLeft: spacing.s2,
  },
  tagEntregue: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.feedbackSuccess,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radii.full,
    gap: 4,
  },
  tagEntregueTexto: {
    fontFamily: typography.fontBody,
    fontSize: 10,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  tagPronto: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radii.full,
  },
  tagProntoTexto: {
    fontFamily: typography.fontBody,
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.feedbackSuccess,
  },
  tagAguardando: {
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radii.full,
  },
  tagAguardandoTexto: {
    fontFamily: typography.fontBody,
    fontSize: 10,
    color: colors.textSecondary,
  },
});