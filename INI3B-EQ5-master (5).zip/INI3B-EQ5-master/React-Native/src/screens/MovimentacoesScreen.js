import React, { useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import api from '../services/api';
import { typography, colors } from '../tokens/colors';

export default function MovimentacoesScreen({ navigation }) {

  const [movimentacoes, setMovimentacoes] = useState([]);
  const [saldoAtual, setSaldoAtual] = useState(0);
  const [carregando, setCarregando] = useState(true);
  const [atualizando, setAtualizando] = useState(false);

  async function buscarMovimentacoes() {
    try {
      const response = await api.get('/movimentacoes/minhas');
      setSaldoAtual(response.data.saldo_atual);
      setMovimentacoes(response.data.movimentacoes);
    } catch (error) {
      console.log('Erro ao buscar movimentações:', error.response?.data || error.message);
    } finally {
      setCarregando(false);
      setAtualizando(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      buscarMovimentacoes();
    }, [])
  );

  const aoAtualizar = useCallback(() => {
    setAtualizando(true);
    buscarMovimentacoes();
  }, []);

  // Retorna a cor e o ícone baseado no tipo da movimentação
  function obterEstilo(tipo, valor) {
    switch (tipo) {
      case 'recarga':
        return { cor: '#2E7D32', icone: '💰', label: 'Recarga' };
      case 'pedido':
        return { cor: '#C62828', icone: '🛒', label: 'Pedido' };
      case 'estorno':
        return { cor: '#1565C0', icone: '↩️', label: 'Estorno' };
      case 'ajuste':
        return { cor: '#F57F17', icone: '⚙️', label: 'Ajuste' };
      default:
        return { cor: '#555', icone: '•', label: tipo };
    }
  }

  function formatarData(dataStr) {
    const data = new Date(dataStr);
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const hora = String(data.getHours()).padStart(2, '0');
    const minuto = String(data.getMinutes()).padStart(2, '0');
    return `${dia}/${mes} às ${hora}:${minuto}`;
  }

  function renderItem({ item }) {
    const estilo = obterEstilo(item.tipo, item.valor);
    const valorPositivo = Number(item.valor) >= 0;

    return (
      <View style={styles.card}>
        <View style={styles.cardEsquerda}>
          <Text style={styles.icone}>{estilo.icone}</Text>
          <View style={styles.cardInfo}>
            <Text style={styles.tipoLabel}>{estilo.label}</Text>
            <Text style={styles.descricao} numberOfLines={1}>
              {item.descricao || '—'}
            </Text>
            <Text style={styles.data}>{formatarData(item.created_at)}</Text>
          </View>
        </View>
        <View style={styles.cardDireita}>
          <Text style={[styles.valor, { color: estilo.cor }]}>
            {valorPositivo ? '+' : ''}R$ {Number(item.valor).toFixed(2)}
          </Text>
          <Text style={styles.saldoResultante}>
            Saldo: R$ {Number(item.saldo_posterior).toFixed(2)}
          </Text>
        </View>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={[styles.container, styles.centro]}>
        <ActivityIndicator size="large" color="#FF7A00" />
        <Text style={{ marginTop: 10, color: '#3E2723' }}>Carregando...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>

      {/* Botão Voltar */}
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.areaVoltar}
      >
        <Text style={styles.linkText}>← Voltar</Text>
      </TouchableOpacity>

      {/* Card de Saldo */}
      <View style={styles.cardSaldo}>
        <Text style={styles.saldoLabel}>Saldo Atual</Text>
        <Text style={styles.saldoValor}>R$ {Number(saldoAtual).toFixed(2)}</Text>
      </View>

      {/* Título */}
      <Text style={styles.titulo}>Histórico de Movimentações</Text>

      {/* Lista */}
      {movimentacoes.length === 0 ? (
        <Text style={styles.vazio}>Nenhuma movimentação encontrada.</Text>
      ) : (
        <FlatList
          data={movimentacoes}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          refreshControl={
            <RefreshControl
              refreshing={atualizando}
              onRefresh={aoAtualizar}
              colors={['#FF7A00']}
            />
          }
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    padding: 20,
    paddingTop: 40,
  },
  centro: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  areaVoltar: {
    marginBottom: 10,
  },
  linkText: {
    fontFamily: typography.fontBody,
    color: '#0F1A25',
    textDecorationLine: 'underline',
    fontSize: 15,
    fontWeight: 'bold',
  },
  cardSaldo: {
    backgroundColor: '#FF7A00',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  saldoLabel: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    color: '#FFF8F0',
    fontWeight: '600',
  },
  saldoValor: {
    fontFamily: typography.fontHeading,
    fontSize: 36,
    color: '#FFFFFF',
    fontWeight: 'bold',
    marginTop: 4,
  },
  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 12,
  },
  vazio: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    marginTop: 40,
    color: '#888',
    fontSize: 15,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
  },
  cardEsquerda: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  icone: {
    fontSize: 24,
    marginRight: 12,
  },
  cardInfo: {
    flex: 1,
  },
  tipoLabel: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#3E2723',
  },
  descricao: {
    fontFamily: typography.fontBody,
    fontSize: 12,
    color: '#777',
    marginTop: 2,
  },
  data: {
    fontFamily: typography.fontBody,
    fontSize: 11,
    color: '#AAA',
    marginTop: 2,
  },
  cardDireita: {
    alignItems: 'flex-end',
    marginLeft: 10,
  },
  valor: {
    fontFamily: typography.fontHeading,
    fontSize: 18,
    fontWeight: 'bold',
  },
  saldoResultante: {
    fontFamily: typography.fontBody,
    fontSize: 11,
    color: '#AAA',
    marginTop: 2,
  },
});
