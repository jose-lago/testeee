import { View, Text, TextInput, TouchableOpacity, StyleSheet, Pressable, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useState } from 'react';
import api from '../services/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { sincronizarPushTokenComBackend, registrarPushNotificationsAsync } from '../services/notificationService';
import { typography, colors } from '../tokens/colors';

export default function CadastroScreen({ navigation }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function handleCadastro() {
    try {
      let pushToken = await AsyncStorage.getItem('push_token');
      if (!pushToken) {
        pushToken = await registrarPushNotificationsAsync();
      }

      const response = await api.post('/registrar', {
        nome: nome,
        email: email,
        password: senha,
        push_token: pushToken || undefined,
      });
      
      await AsyncStorage.setItem('token', response.data.token);
      await AsyncStorage.setItem('user', JSON.stringify(response.data.user));

      // Sincroniza o token de notificações push com o backend
      await sincronizarPushTokenComBackend();

      alert('Cadastro realizado com sucesso!');
      navigation.navigate("MainTabs");
    } catch (error) {
      console.log('ERRO Cadastro:', error.response?.data || error.message);
      
      let msg = 'Erro ao cadastrar';
      if (error.response?.data?.errors?.email) {
        msg = 'Este e-mail já está cadastrado no sistema.';
      } else if (error.response?.data?.message) {
        msg = error.response.data.message;
      } else if (error.message) {
        msg = error.message;
      }
      
      alert(msg);
    }
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView 
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
      >
        
        <View style={styles.header}>
          <Text style={styles.title}>Crie sua conta</Text>
          <Text style={styles.subtitle}>Preencha os dados abaixo para começar</Text>
        </View>

        <View style={styles.form}>
          <TextInput
            placeholder="Nome"
            placeholderTextColor="#999"
            style={styles.input}
            value={nome}
            onChangeText={setNome}
          />

          <TextInput
            placeholder="E-mail"
            placeholderTextColor="#999"
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            placeholder="Senha"
            placeholderTextColor="#999"
            style={styles.input}
            secureTextEntry
            value={senha}
            onChangeText={setSenha}
          />

          <TouchableOpacity style={styles.button} onPress={handleCadastro} activeOpacity={0.8}>
            <Text style={styles.buttonText}>Criar Conta</Text>
          </TouchableOpacity>
        </View>

        <Pressable style={styles.loginContainer} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.loginText}>
            Já possui uma conta? <Text style={styles.loginLink}>Entrar</Text>
          </Text>
        </Pressable>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    backgroundColor: '#FFF8F0', // Fundo creme idêntico ao Login
    justifyContent: 'center',
    paddingHorizontal: 30,
    paddingVertical: 40,
  },
  header: {
    marginBottom: 40,
    alignItems: 'center',
  },
  title: {
    fontFamily: typography.fontHeading,
    fontSize: 38,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
  },
  form: {
    width: '100%',
  },
  input: {
    fontFamily: typography.fontBody,
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    marginBottom: 16,
    fontSize: 16,
    color: '#333',
    // Sombras leves padrão card
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  button: {
    backgroundColor: '#FF9430', // Seu Laranja
    paddingVertical: 16,
    borderRadius: 12,
    marginTop: 10,
    alignItems: 'center',
    // Sombra do botão
    shadowColor: '#FF9430',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
  buttonText: {
    fontFamily: typography.fontBody,
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loginContainer: {
    marginTop: 40,
    alignItems: 'center',
  },
  loginText: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    color: '#666666',
  },
  loginLink: {
    fontFamily: typography.fontBody,
    color: '#FF9430',
    fontWeight: 'bold',
  }
});