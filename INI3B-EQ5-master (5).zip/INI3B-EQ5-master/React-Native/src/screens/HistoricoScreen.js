import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, RefreshControl, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import api from '../services/api';
import { typography, colors } from '../tokens/colors';

export default function HistoricoScreen({ navigation }) {
  const [pedidos, setPedidos] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [atualizando, setAtualizando] = useState(false);

  async function buscarPedidos() {
    try {
      const response = await api.get('/pedidos/meus');
      setPedidos(response.data);
    } catch (error) {
      console.log('Erro ao buscar pedidos:', error.response?.data || error.message);
    } finally {
      setCarregando(false);
      setAtualizando(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      buscarPedidos();
    }, [])
  );

  const aoAtualizar = useCallback(() => {
    setAtualizando(true);
    buscarPedidos();
  }, []);

  function formatarData(dataStr) {
    const data = new Date(dataStr);
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const ano = data.getFullYear();
    const hora = String(data.getHours()).padStart(2, '0');
    const minuto = String(data.getMinutes()).padStart(2, '0');
    return `${dia}/${mes}/${ano} às ${hora}:${minuto}`;
  }

  function getStatusCor(status) {
    switch (status) {
      case 'pendente': return '#F57F17'; // Amarelo/Laranja
      case 'preparando': return '#1976D2'; // Azul
      case 'pronto': return '#388E3C'; // Verde
      case 'entregue': return '#757575'; // Cinza
      case 'cancelado': return '#D32F2F'; // Vermelho
      default: return '#3E2723';
    }
  }

  if (carregando) {
    return (
      <View style={[styles.container, styles.centro]}>
        <ActivityIndicator size="large" color="#FF7A00" />
        <Text style={{ marginTop: 10, color: '#3E2723' }}>Carregando...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>

      {/* Botão Voltar pill */}
      <View style={styles.headerTop}>
        <TouchableOpacity style={styles.botaoVoltarPill} onPress={() => navigation.goBack()}>
          <Text style={styles.textoVoltarPill}>Voltar</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.tituloSecao}>Histórico</Text>

      <ScrollView
        contentContainerStyle={{ paddingBottom: 40 }}
        refreshControl={<RefreshControl refreshing={atualizando} onRefresh={aoAtualizar} colors={['#FF7A00']} />}
      >
        {pedidos.length === 0 ? (
          <Text style={styles.vazio}>Nenhum pedido encontrado.</Text>
        ) : (
          pedidos.map((pedido) => (
            <View key={pedido.id} style={styles.cardPedido}>

              <View style={styles.cabecalhoPedido}>
                <Text style={styles.textoData}>Data {formatarData(pedido.created_at)}</Text>
                <Text style={[styles.textoStatus, { color: getStatusCor(pedido.status) }]}>
                  {pedido.status.toUpperCase()}
                </Text>
              </View>

              {pedido.itens.map((item, index) => {
                const isAlmoco = item.produto?.categoria === 'almoco';

                return (
                  <View key={item.id || index} style={styles.itemContainer}>
                    <View style={styles.categoriaBadge}>
                      <Text style={styles.categoriaTexto}>
                        {isAlmoco ? 'Almoço' : 'Bebidas'}
                      </Text>
                      <Ionicons
                        name={isAlmoco ? 'restaurant-outline' : 'cafe-outline'}
                        size={24}
                        color="#0F1A25"
                      />
                    </View>
                    <Text style={styles.produtoNome}>{item.produto?.nome || 'Produto'}</Text>
                    <Text style={styles.produtoQtd}>Quantidade: {item.quantidade}</Text>
                  </View>
                );
              })}

              <View style={styles.rodapePedido}>
                <Text style={styles.textoTotal}>R$ {Number(pedido.valor_total).toFixed(2).replace('.', ',')}</Text>
              </View>

            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8F0',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  centro: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTop: {
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  botaoVoltarPill: {
    backgroundColor: '#FDB368',
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  textoVoltarPill: {
    fontFamily: typography.fontBody,
    color: '#0F1A25',
    fontWeight: 'bold',
    fontSize: 16,
  },
  tituloSecao: {
    fontFamily: typography.fontHeading,
    fontSize: 42,
    fontWeight: '900',
    color: '#3E2723',
    textAlign: 'center',
    marginBottom: 30,
  },
  vazio: {
    fontFamily: typography.fontBody,
    textAlign: 'center',
    marginTop: 40,
    color: '#888',
    fontSize: 16,
  },
  cardPedido: {
    marginBottom: 30,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    paddingBottom: 15,
  },
  cabecalhoPedido: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  textoData: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0F1A25',
  },
  textoStatus: {
    fontFamily: typography.fontBody,
    fontSize: 13,
    fontWeight: 'bold',
  },
  itemContainer: {
    marginBottom: 15,
  },
  categoriaBadge: {
    backgroundColor: '#FDB368',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
    alignSelf: 'flex-start',
    minWidth: 160,
  },
  categoriaTexto: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0F1A25',
  },
  produtoNome: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0F1A25',
    marginLeft: 2,
  },
  produtoQtd: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0F1A25',
    marginLeft: 2,
  },
  rodapePedido: {
    alignItems: 'flex-end',
    marginTop: 5,
  },
  textoTotal: {
    fontFamily: typography.fontHeading,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FF7A00',
  }
});
