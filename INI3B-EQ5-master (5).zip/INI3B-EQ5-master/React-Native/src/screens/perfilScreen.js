import React, { useState, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
    Alert,
    Platform
} from 'react-native';

import { useFocusEffect, CommonActions } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { removerPushTokenDoBackend } from '../services/notificationService';

import api from '../services/api';

export default function PerfilScreen({ navigation }) {
    const [user, setUser] = useState(null);
    const [creditoAtivoSistema, setCreditoAtivoSistema] = useState(true);

    useFocusEffect(
        useCallback(() => {
            async function carregarUsuario() {
                try {
                    const response = await api.get('/me');
                    setUser(response.data);
                    await AsyncStorage.setItem('user', JSON.stringify(response.data));
                } catch (error) {
                    const userStorage = await AsyncStorage.getItem('user');
                    if (userStorage) {
                        setUser(JSON.parse(userStorage));
                    }
                }

                try {
                    const configRes = await api.get('/configuracoes/credito');
                    if (configRes.data && typeof configRes.data.credito_ativo === 'boolean') {
                        setCreditoAtivoSistema(configRes.data.credito_ativo);
                    }
                } catch (e) {
                    // Fallback silencioso
                }
            }
            carregarUsuario();
        }, [])
    );

    const handleSair = async () => {
        const confirmar = Platform.OS === 'web' 
            ? window.confirm("Deseja realmente sair da conta?")
            : await new Promise((resolve) => {
                Alert.alert("Sair da conta", "Deseja realmente sair da conta?", [
                    { text: "Não", onPress: () => resolve(false) },
                    { text: "Sim", onPress: () => resolve(true) }
                ]);
            });

        if (confirmar) {
            await removerPushTokenDoBackend();
            await AsyncStorage.clear();
            navigation.dispatch(
                CommonActions.reset({
                    index: 0,
                    routes: [{ name: 'Login' }],
                })
            );
        }
    };

    return (
        <ScrollView style={styles.container}>
            <View style={styles.headerContainer}>
                <Text style={styles.titulo}>Saviore</Text>
            </View>

            {/* CARD DE IDENTIFICAÇÃO DO ALUNO COM O PRÓPRIO ID */}
            <View style={styles.userInfoContainer}>
                <View style={styles.userHeaderRow}>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.saudacao}>Olá, {user?.name || 'Carregando...'}</Text>
                        <Text style={styles.emailTexto}>{user?.email || '—'}</Text>
                    </View>
                    {user?.id ? (
                        <View style={styles.idBadge}>
                            <Text style={styles.idBadgeLabel}>SEU ID</Text>
                            <Text style={styles.idBadgeNumero}>#{user.id}</Text>
                        </View>
                    ) : null}
                </View>

                {/* Linha destacada com o ID exclusivo do próprio aluno */}
                <View style={styles.idInfoBar}>
                    <Text style={styles.idInfoLabel}>🆔 ID do Aluno:</Text>
                    <Text style={styles.idInfoValor}>#{user?.id || '—'}</Text>
                </View>

                <Text style={styles.saldoTexto}>Saldo: R$ {(Number(user?.saldo) || 0).toFixed(2)}</Text>
                
                {/* Exibe o limite de crédito usando a cor marrom da paleta */}
                {user?.credito?.verificado && (
                    <Text style={[styles.saldoTexto, { fontSize: 18, color: '#3E2723', marginTop: 5 }]}>
                        Limite de Crédito: R$ {(Number(user.credito.limite) - Number(user.credito.divida_atual)).toFixed(2)}
                    </Text>
                )}
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Minha Conta</Text>
                <TouchableOpacity style={styles.botao} onPress={() => navigation.navigate('HistoricoPedidos')}>
                    <Text style={styles.textoBotao}>Histórico de Compras</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.botao} onPress={() => navigation.navigate('Movimentacoes')}>
                    <Text style={styles.textoBotao}>Minhas Recargas</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Configurações</Text>
                <TouchableOpacity style={styles.botao} onPress={() => navigation.navigate('Configuracoes')}>
                    <Text style={styles.textoBotao}>Dados da Conta</Text>
                </TouchableOpacity>

                {/* Se o crédito já estiver ativado pelo aluno ou desativado globalmente pelo admin, o botão NÃO aparece */}
                {(!user?.credito?.verificado && creditoAtivoSistema) && (
                    <TouchableOpacity
                        style={styles.botao}
                        onPress={() => navigation.navigate('AtivarCredito')}
                    >
                        <Text style={styles.textoBotao}>Ativar Crédito / Devedores</Text>
                    </TouchableOpacity>
                )}

                <TouchableOpacity style={styles.botao} onPress={() => navigation.navigate('Ajuda')}>
                    <Text style={styles.textoBotao}>Ajuda e Suporte</Text>
                </TouchableOpacity>
            </View>

            {/* Botão Sair usando a cor laranja padrão da sua paleta */}
            <TouchableOpacity style={styles.botao} onPress={handleSair}>
                <Text style={styles.textoBotao}>Sair da Conta</Text>
            </TouchableOpacity>

            <View style={styles.bottomSpacer} />
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#FFF8F0', paddingHorizontal: 25 },
    headerContainer: { alignItems: 'center', marginTop: 50, marginBottom: 30 },
    titulo: { fontFamily: 'Ahkio', fontSize: 52, fontWeight: '900', color: '#3E2723', fontStyle: 'italic' },
    userInfoContainer: { 
        marginBottom: 30, backgroundColor: '#FFFFFF', padding: 20, borderRadius: 18,
        elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15, shadowRadius: 4 
    },
    userHeaderRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 14,
    },
    saudacao: {
        fontFamily: 'HammersmithOne',
        fontSize: 18,
        fontWeight: 'bold',
        color: '#0F1A25',
    },
    emailTexto: {
        fontFamily: 'HammersmithOne',
        fontSize: 13,
        color: '#64748B',
        marginTop: 2,
    },
    idBadge: {
        backgroundColor: '#FFF3E0',
        borderColor: '#FF9430',
        borderWidth: 1.5,
        borderRadius: 10,
        paddingVertical: 4,
        paddingHorizontal: 12,
        alignItems: 'center',
        justifyContent: 'center',
    },
    idBadgeLabel: {
        fontFamily: 'HammersmithOne',
        fontSize: 10,
        fontWeight: 'bold',
        color: '#FF9430',
        letterSpacing: 0.5,
    },
    idBadgeNumero: {
        fontFamily: 'HammersmithOne',
        fontSize: 17,
        fontWeight: '900',
        color: '#3E2723',
    },
    idInfoBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#F8FAFC',
        borderRadius: 10,
        paddingVertical: 10,
        paddingHorizontal: 14,
        marginTop: 4,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    idInfoLabel: {
        fontFamily: 'HammersmithOne',
        fontSize: 14,
        fontWeight: 'bold',
        color: '#475569',
    },
    idInfoValor: {
        fontFamily: 'HammersmithOne',
        fontSize: 16,
        fontWeight: '900',
        color: '#EA580C',
    },
    saldoTexto: { fontFamily: 'Ahkio', fontSize: 32, fontWeight: 'bold', color: '#3E2723', marginTop: 10, textAlign: 'center' },
    section: { marginBottom: 25 },
    sectionTitle: { fontFamily: 'Ahkio', fontSize: 24, fontWeight: 'bold', color: '#3E2723', marginBottom: 12 },
    botao: { 
        backgroundColor: '#FF9430', paddingVertical: 15, borderRadius: 12, 
        alignItems: 'center', marginBottom: 12, elevation: 2 
    },
    textoBotao: { fontFamily: 'HammersmithOne', color: '#0F1A25', fontWeight: 'bold', fontSize: 16 },
    bottomSpacer: { height: 40 }
});
