import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
  ActivityIndicator,
} from "react-native";

import { useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import api from "../services/api";
import { typography, colors } from "../tokens/colors";

export default function ConfigContaScreen({ navigation }) {
  // ------------ Conta ------------
  const [email, setEmail] = useState("");
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  // ------------ RFID PIN ------------
  const [user, setUser] = useState(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [pinAtual, setPinAtual] = useState("");
  const [novoPin, setNovoPin] = useState("");
  const [confirmarPin, setConfirmarPin] = useState("");
  const [salvandoPin, setSalvandoPin] = useState(false);

  // Carrega dados do usuário toda vez que a tela ganha foco
  useFocusEffect(
    useCallback(() => {
      async function carregarUsuario() {
        setLoadingUser(true);
        try {
          const res = await api.get("/me");
          setUser(res.data);
          await AsyncStorage.setItem("user", JSON.stringify(res.data));
        } catch {
          const cache = await AsyncStorage.getItem("user");
          if (cache) setUser(JSON.parse(cache));
        } finally {
          setLoadingUser(false);
        }
      }
      carregarUsuario();
    }, [])
  );

  const formatNumerico = (v) => v.replace(/[^0-9]/g, "");

  // ------------ Handlers de conta ------------
  const alterarEmail = async () => {
    if (!email.trim()) {
      Alert.alert("Atenção", "Informe um e-mail válido.");
      return;
    }
    try {
      const response = await api.put("/me/email", { email });
      if (response.data?.user) {
        await AsyncStorage.setItem("user", JSON.stringify(response.data.user));
      }
      Alert.alert("Sucesso", "E-mail alterado com sucesso!");
      setEmail("");
    } catch (error) {
      const msg = error.response?.data?.message || "Não foi possível alterar o e-mail.";
      Alert.alert("Erro", msg);
    }
  };

  const alterarSenha = async () => {
    if (novaSenha !== confirmarSenha) {
      Alert.alert("Erro", "As senhas não coincidem.");
      return;
    }
    if (novaSenha.length < 6) {
      Alert.alert("Erro", "A nova senha deve ter ao menos 6 caracteres.");
      return;
    }
    try {
      await api.put("/me/senha", {
        senha_atual: senhaAtual,
        nova_senha: novaSenha,
      });
      Alert.alert("Sucesso", "Senha alterada com sucesso!");
      setSenhaAtual("");
      setNovaSenha("");
      setConfirmarSenha("");
    } catch (error) {
      const msg = error.response?.data?.message || "Não foi possível alterar a senha.";
      Alert.alert("Erro", msg);
    }
  };

  // ------------ Handler do PIN RFID ------------
  const handleSalvarPin = async () => {
    if (novoPin.length !== 6) {
      Alert.alert("Atenção", "A senha do cartão deve ter exatamente 6 dígitos numéricos.");
      return;
    }
    if (novoPin !== confirmarPin) {
      Alert.alert("Atenção", "As senhas digitadas não coincidem.");
      return;
    }

    const jaTemPin = user?.tem_pin_cadastrado ?? false;

    if (jaTemPin && pinAtual.length !== 6) {
      Alert.alert("Atenção", "Informe sua senha atual do cartão para poder trocá-la.");
      return;
    }

    setSalvandoPin(true);
    try {
      const payload = {
        novo_pin: novoPin,
        novo_pin_confirmation: confirmarPin,
      };
      if (jaTemPin) {
        payload.pin_atual = pinAtual;
      }

      const res = await api.post("/me/rfid/pin", payload);

      // Atualiza o dado local de tem_pin_cadastrado
      const userAtualizado = { ...user, tem_pin_cadastrado: true };
      setUser(userAtualizado);
      await AsyncStorage.setItem("user", JSON.stringify(userAtualizado));

      Alert.alert("✅ Sucesso", res.data?.message || "Senha do cartão salva com sucesso!");
      setPinAtual("");
      setNovoPin("");
      setConfirmarPin("");
    } catch (error) {
      const msg = error.response?.data?.message || "Erro ao salvar a senha do cartão.";
      Alert.alert("Erro", msg);
    } finally {
      setSalvandoPin(false);
    }
  };

  // ------------ Renderização da seção RFID ------------
  const renderSecaoRfid = () => {
    if (loadingUser) {
      return (
        <View style={[styles.card, { alignItems: "center", paddingVertical: 30 }]}>
          <ActivityIndicator size="small" color="#FF9430" />
          <Text style={[styles.label, { marginTop: 10, textAlign: "center" }]}>
            Carregando dados do cartão...
          </Text>
        </View>
      );
    }

    const temCartao = !!user?.rfid_code;
    const jaTemPin = user?.tem_pin_cadastrado ?? false;

    if (!temCartao) {
      return (
        <View style={styles.card}>
          <View style={styles.rfidSemCartao}>
            <Text style={styles.rfidIcone}>💳</Text>
            <Text style={styles.rfidSemCartaoTitulo}>Cartão RFID não vinculado</Text>
            <Text style={styles.rfidSemCartaoTexto}>
              Você ainda não possui um cartão RFID vinculado à sua conta.{"\n"}
              Procure a cantina para solicitar a vinculação.
            </Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.card}>
        {/* Badge de status */}
        <View style={styles.rfidStatusBadge}>
          <Text style={styles.rfidStatusTexto}>
            {jaTemPin ? "🔒 Senha cadastrada — cartão pronto para o totem" : "⚠️ Sem senha — cadastre para usar o totem"}
          </Text>
        </View>

        {jaTemPin && (
          <>
            <Text style={styles.label}>Senha Atual do Cartão</Text>
            <TextInput
              style={styles.input}
              placeholder="••••••"
              placeholderTextColor="#999"
              value={pinAtual}
              onChangeText={(v) => setPinAtual(formatNumerico(v))}
              keyboardType="numeric"
              maxLength={6}
              secureTextEntry
              autoComplete="off"
              textContentType="none"
            />
          </>
        )}

        <Text style={styles.label}>
          {jaTemPin ? "Nova Senha do Cartão (6 dígitos)" : "Criar Senha do Cartão (6 dígitos)"}
        </Text>
        <TextInput
          style={styles.input}
          placeholder="••••••"
          placeholderTextColor="#999"
          value={novoPin}
          onChangeText={(v) => setNovoPin(formatNumerico(v))}
          keyboardType="numeric"
          maxLength={6}
          secureTextEntry
          autoComplete="off"
          textContentType="none"
        />

        <Text style={styles.label}>Confirmar Nova Senha</Text>
        <TextInput
          style={styles.input}
          placeholder="••••••"
          placeholderTextColor="#999"
          value={confirmarPin}
          onChangeText={(v) => setConfirmarPin(formatNumerico(v))}
          keyboardType="numeric"
          maxLength={6}
          secureTextEntry
          autoComplete="off"
          textContentType="none"
        />

        <Text style={styles.rfidDica}>
          Esta senha de 6 dígitos será usada exclusivamente ao pagar no totem.
        </Text>

        <TouchableOpacity
          style={[styles.botao, salvandoPin && styles.botaoDesabilitado]}
          onPress={handleSalvarPin}
          disabled={salvandoPin}
        >
          <Text style={styles.textoBotao}>
            {salvandoPin
              ? "Salvando..."
              : jaTemPin
              ? "Alterar Senha do Cartão"
              : "Cadastrar Senha do Cartão"}
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>Configurações da Conta</Text>

      {/* Botão Voltar */}
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.areaVoltar}>
        <Text style={styles.linkText}>← Voltar</Text>
      </TouchableOpacity>

      {/* -------- IDENTIFICAÇÃO DO ALUNO -------- */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>🆔 Identificação da Conta</Text>
        <View style={styles.idContainer}>
          <Text style={styles.idLabelTexto}>Seu ID de Aluno:</Text>
          <View style={styles.idValorBadge}>
            <Text style={styles.idValorTexto}>#{user?.id ?? "..."}</Text>
          </View>
        </View>
        <Text style={styles.idDescricaoTexto}>
          Informe este número no caixa da cantina para recargas presenciais de saldo.
        </Text>
      </View>

      {/* -------- EMAIL -------- */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>📧 Alterar E-mail</Text>
        <Text style={styles.label}>Novo E-mail</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite o novo e-mail"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.botao} onPress={alterarEmail}>
          <Text style={styles.textoBotao}>Alterar E-mail</Text>
        </TouchableOpacity>
      </View>

      {/* -------- SENHA DO APP -------- */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>🔑 Alterar Senha do App</Text>
        <Text style={styles.label}>Senha Atual</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite sua senha atual"
          secureTextEntry
          value={senhaAtual}
          onChangeText={setSenhaAtual}
        />
        <Text style={styles.label}>Nova Senha</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite a nova senha"
          secureTextEntry
          value={novaSenha}
          onChangeText={setNovaSenha}
        />
        <Text style={styles.label}>Confirmar Nova Senha</Text>
        <TextInput
          style={styles.input}
          placeholder="Confirme a nova senha"
          secureTextEntry
          value={confirmarSenha}
          onChangeText={setConfirmarSenha}
        />
        <TouchableOpacity style={styles.botao} onPress={alterarSenha}>
          <Text style={styles.textoBotao}>Alterar Senha</Text>
        </TouchableOpacity>
      </View>

      {/* -------- SENHA RFID DO TOTEM -------- */}
      <Text style={styles.sectionHeader}>💳 Senha do Cartão RFID (Totem)</Text>
      {renderSecaoRfid()}

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF8F0",
    padding: 20,
  },
  titulo: {
    fontFamily: typography.fontHeading,
    fontSize: 36,
    fontWeight: "bold",
    marginBottom: 25,
    color: "#3E2723",
    textAlign: "center",
  },
  sectionHeader: {
    fontFamily: typography.fontHeading,
    fontSize: 20,
    fontWeight: "bold",
    color: "#3E2723",
    marginBottom: 8,
    marginTop: 8,
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.07,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionTitle: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    fontWeight: "bold",
    color: "#3E2723",
    marginBottom: 12,
  },
  label: {
    fontFamily: typography.fontBody,
    fontWeight: "bold",
    marginBottom: 6,
    marginTop: 10,
    color: "#3E2723",
    fontSize: 14,
  },
  input: {
    fontFamily: typography.fontBody,
    borderWidth: 1,
    borderColor: "#DDD",
    borderRadius: 8,
    padding: 12,
    backgroundColor: "#FFF",
    fontSize: 16,
    color: "#333",
  },
  botao: {
    backgroundColor: "#FF9430",
    padding: 14,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 20,
    elevation: 2,
  },
  botaoDesabilitado: {
    backgroundColor: "#FFB870",
  },
  textoBotao: {
    fontFamily: typography.fontBody,
    fontWeight: "bold",
    color: "#0F1A25",
    fontSize: 16,
  },
  areaVoltar: {
    marginBottom: 10,
  },
  linkText: {
    fontFamily: typography.fontBody,
    color: "#0F1A25",
    textDecorationLine: "underline",
    fontSize: 15,
    fontWeight: "bold",
  },
  // RFID sem cartão
  rfidSemCartao: {
    alignItems: "center",
    paddingVertical: 10,
  },
  rfidIcone: {
    fontSize: 40,
    marginBottom: 10,
  },
  rfidSemCartaoTitulo: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    fontWeight: "bold",
    color: "#3E2723",
    marginBottom: 8,
  },
  rfidSemCartaoTexto: {
    fontFamily: typography.fontBody,
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    lineHeight: 21,
  },
  // RFID com cartão
  rfidStatusBadge: {
    backgroundColor: "#FFF3E0",
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: "#FF9430",
  },
  rfidStatusTexto: {
    fontFamily: typography.fontBody,
    fontSize: 13,
    fontWeight: "700",
    color: "#C85B00",
  },
  rfidDica: {
    fontFamily: typography.fontBody,
    fontSize: 12,
    color: "#888",
    marginTop: 8,
    textAlign: "center",
    fontStyle: "italic",
  },
  idContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#F8FAFC",
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    marginTop: 8,
  },
  idLabelTexto: {
    fontFamily: typography.fontBody,
    fontSize: 15,
    fontWeight: "bold",
    color: "#334155",
  },
  idValorBadge: {
    backgroundColor: "#FFF3E0",
    borderWidth: 1,
    borderColor: "#FF9430",
    borderRadius: 6,
    paddingVertical: 3,
    paddingHorizontal: 10,
  },
  idValorTexto: {
    fontFamily: typography.fontBody,
    fontSize: 16,
    fontWeight: "900",
    color: "#EA580C",
  },
  idDescricaoTexto: {
    fontFamily: typography.fontBody,
    fontSize: 13,
    color: "#64748B",
    marginTop: 8,
  },
});
