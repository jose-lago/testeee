/**
 * ==========================================================================
 * CANTINA UNESP — DESIGN SYSTEM TOKENS (React Native)
 * Arquivo: src/tokens/colors.js
 *
 * Espelho do :root do design-system.css para uso no React Native.
 * NUNCA use valores hexadecimais literais nas telas. Sempre importe daqui.
 * ==========================================================================
 */

// ---------------------------------------------------------------------------
// 1. CORES — MARCA
// ---------------------------------------------------------------------------
export const colors = {
  // Primária — Laranja. Botões principais, CTAs, destaques.
  brandPrimary:         '#FF9430',
  brandPrimaryHover:    '#FF7A00',
  brandPrimaryLight:    '#FDB368',

  // Secundária — Marrom escuro. Títulos, textos de destaque.
  brandSecondary:       '#3E2723',
  brandSecondaryLight:  '#6D4C41',

  // Terciária — Azul-noturno. Texto de corpo, ícones inativos.
  brandTertiary:        '#0F1A25',

  // ---------------------------------------------------------------------------
  // 2. BACKGROUNDS & SUPERFÍCIES
  // ---------------------------------------------------------------------------
  bgScreen:             '#FFF8F0',   // Fundo principal — creme
  bgCard:               '#FAD6A9',   // Cards de item
  bgCardHover:          'rgba(250, 214, 169, 0.15)',
  bgSurface:            '#FFFFFF',   // Modais, cards admin, inputs

  // ---------------------------------------------------------------------------
  // 3. FEEDBACK SEMÂNTICO
  // ---------------------------------------------------------------------------
  feedbackSuccess:      '#2E7D32',   // Saldo positivo, confirmação
  feedbackSuccessLight: '#4CAF50',
  feedbackError:        '#C62828',   // Cancelamento, remoção
  feedbackErrorLight:   '#D32F2F',
  feedbackWarning:      '#F57F17',   // Em preparo, atenção
  feedbackWarningLight: '#faad14',
  feedbackInfo:         '#1565C0',   // Estorno, crédito, informativo
  feedbackInfoLight:    '#1890ff',

  // ---------------------------------------------------------------------------
  // 4. TEXTO
  // ---------------------------------------------------------------------------
  textPrimary:          '#3E2723',   // Títulos, labels principais
  textBody:             '#0F1A25',   // Parágrafos, dados
  textSecondary:        '#666666',   // Subtítulos
  textMuted:            '#888888',   // Datas, metadados
  textDisabled:         '#AAAAAA',
  textOnDark:           '#FFFFFF',   // Texto sobre botões escuros
  textOnBrand:          '#0F1A25',   // Texto sobre laranja
  textPlaceholder:      '#999999',

  // ---------------------------------------------------------------------------
  // 5. BORDAS
  // ---------------------------------------------------------------------------
  borderDefault:        '#D9D9D9',
  borderSubtle:         '#F5F5F5',

  // ---------------------------------------------------------------------------
  // 6. SOMBRA (shadowColor padrão RN)
  // ---------------------------------------------------------------------------
  shadow:               '#000000',
  shadowBrand:          '#FF9430',
};

// ---------------------------------------------------------------------------
// 7. TIPOGRAFIA
// ---------------------------------------------------------------------------
export const typography = {
  fontHeading:      'Ahkio',             // Para títulos grandes ou informações em destaque
  fontBody:         'HammersmithOne',    // Para textos diversos
  fontFamily:       'HammersmithOne',    // Padrão geral para textos

  // Tamanhos — regra da escala 4px/8px
  fontSizeXs:       11,
  fontSizeSm:       12,
  fontSizeBase:     14,
  fontSizeMd:       16,
  fontSizeLg:       18,
  fontSizeXl:       24,
  fontSize2xl:      28,
  fontSize3xl:      40,
  fontSize4xl:      48,
  fontSizeHero:     52,

  // Pesos
  fontWeightRegular:   '400',
  fontWeightMedium:    '500',
  fontWeightSemibold:  '600',
  fontWeightBold:      '700',
  fontWeightBlack:     '900',
};

// ---------------------------------------------------------------------------
// 8. ESPAÇAMENTO — Múltiplos de 4
// ---------------------------------------------------------------------------
export const spacing = {
  s1:   4,
  s2:   8,
  s3:   12,
  s4:   16,
  s5:   20,
  s6:   24,
  s7:   28,
  s8:   32,
  s10:  40,
  s12:  48,
  s16:  64,

  // Semânticos
  insetSm:      12,    // Padding de chips, badges
  insetMd:      16,    // Padding de cards
  insetLg:      20,    // Padding de seções
  insetXl:      24,    // Padding de containers/modais
  sectionGap:   32,    // Espaço entre seções
  pagePadding:  20,    // Padding horizontal de tela (ex: paddingHorizontal: 25)
};

// ---------------------------------------------------------------------------
// 9. BORDAS E RAIOS
// ---------------------------------------------------------------------------
export const radii = {
  sm:    8,    // Botões e inputs
  md:    12,   // Cards, imagens
  lg:    18,   // Modais, painéis
  full:  9999, // Pills/arredondados
};

// ---------------------------------------------------------------------------
// 10. SOMBRAS (objeto pré-montado para StyleSheet)
// ---------------------------------------------------------------------------
export const shadows = {
  sm: {
    shadowColor:   colors.shadow,
    shadowOffset:  { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius:  6,
    elevation:     2,
  },
  md: {
    shadowColor:   colors.shadow,
    shadowOffset:  { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius:  12,
    elevation:     4,
  },
  lg: {
    shadowColor:   colors.shadow,
    shadowOffset:  { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius:  24,
    elevation:     8,
  },
  brand: {
    shadowColor:   colors.shadowBrand,
    shadowOffset:  { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius:  8,
    elevation:     6,
  },
};

// ---------------------------------------------------------------------------
// EXEMPLO DE USO NAS TELAS
// ---------------------------------------------------------------------------
//
// import { colors, typography, spacing, radii, shadows } from '../tokens/colors';
//
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: colors.bgScreen,
//     paddingHorizontal: spacing.pagePadding,
//   },
//   titulo: {
//     fontSize: typography.fontSizeXl,
//     fontWeight: typography.fontWeightBold,
//     color: colors.textPrimary,
//   },
//   card: {
//     backgroundColor: colors.bgCard,
//     borderRadius: radii.md,
//     padding: spacing.insetMd,
//     ...shadows.sm,
//   },
//   botao: {
//     backgroundColor: colors.brandPrimary,
//     borderRadius: radii.sm,
//     padding: spacing.insetMd,
//     ...shadows.brand,
//   },
// });
