import 'react-native-gesture-handler';
import React, { useState, useEffect } from 'react';
import { Platform } from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

import CadastroScreen from './src/screens/CadastroScreen';
import LoginScreen from './src/screens/LoginScreen';
import RecuperarSenhaScreen from './src/screens/RecuperarSenhaScreen';
import ProdutosScreen from './src/screens/ProdutosScreen';
import AlmocoScreen from './src/screens/AlmocoScreen';
import BebidaScreen from './src/screens/BebidaScreen';
import CarrinhoScreen from './src/screens/CarrinhoScreen';
import PerfilScreen from './src/screens/perfilScreen';
import MovimentacoesScreen from './src/screens/MovimentacoesScreen';
import FilaScreen from './src/screens/FilaScreen';
import ConfigContaScreen from './src/screens/ConfigContaScreen';
import AtivarCreditoScreen from './src/screens/AtivarCreditoScreen';
import HistoricoScreen from './src/screens/HistoricoScreen';
import AjudaScreen from './src/screens/AjudaScreen';

import { NavigationContainer, createNavigationContainerRef } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Notifications from 'expo-notifications';
import { sincronizarPushTokenComBackend, dispararNotificacaoLocal } from './src/services/notificationService';
import api from './src/services/api';
import { useAppFonts } from './src/hooks/useAppFonts';

export const navigationRef = createNavigationContainerRef();

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();
const ProdutosNav = createStackNavigator();
const PerfilNav = createStackNavigator();

function ProdutosStack({ carrinho, setCarrinho }) {
  return (
    <ProdutosNav.Navigator screenOptions={{ headerShown: false }}>
      <ProdutosNav.Screen name="Produtos" component={ProdutosScreen} />
      <ProdutosNav.Screen name="Almoco">
        {props => <AlmocoScreen {...props} carrinho={carrinho} setCarrinho={setCarrinho} />}
      </ProdutosNav.Screen>
      <ProdutosNav.Screen name="Bebidas">
        {props => <BebidaScreen {...props} carrinho={carrinho} setCarrinho={setCarrinho} />}
      </ProdutosNav.Screen>
    </ProdutosNav.Navigator>
  );
}

function PerfilStack() {
  return (
    <PerfilNav.Navigator screenOptions={{ headerShown: false }}>
      <PerfilNav.Screen name="PerfilMenu" component={PerfilScreen} />
      <PerfilNav.Screen name="Movimentacoes" component={MovimentacoesScreen} />
      <PerfilNav.Screen name="HistoricoPedidos" component={HistoricoScreen} />
      <PerfilNav.Screen name="Configuracoes" component={ConfigContaScreen} />
      <PerfilNav.Screen name="AtivarCredito" component={AtivarCreditoScreen} />
      <PerfilNav.Screen name="Ajuda" component={AjudaScreen} />
    </PerfilNav.Navigator>
  );
}

function MainTabs({ carrinho, setCarrinho }) {
  const insets = useSafeAreaInsets();
  const bottomPadding = insets.bottom > 0 ? insets.bottom + 4 : (Platform.OS === 'android' ? 14 : 8);
  const tabHeight = 60 + bottomPadding;

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          // Nome corrigido aqui para evitar conflito
          if (route.name === 'ProdutosTab') {
            iconName = focused ? 'restaurant' : 'restaurant-outline';
          } else if (route.name === 'Carrinho') {
            iconName = focused ? 'cart' : 'cart-outline';
          } else if (route.name === 'Fila') {
            iconName = focused ? 'ticket' : 'ticket-outline';
          } else if (route.name === 'Mais') {
            iconName = focused ? 'ellipsis-horizontal' : 'ellipsis-horizontal-outline';
          }

          return <Ionicons name={iconName} size={22} color={color} />;
        },
        tabBarActiveTintColor: '#3E2723',
        tabBarInactiveTintColor: '#0F1A25',
        tabBarStyle: {
          backgroundColor: '#FDB368',
          borderTopWidth: 0,
          height: tabHeight,
          paddingTop: 6,
          paddingBottom: bottomPadding,
        },
        tabBarItemStyle: {
          justifyContent: 'center',
          alignItems: 'center',
        },
        tabBarLabelStyle: {
          fontFamily: 'HammersmithOne',
          fontWeight: 'bold',
          fontSize: 12,
          marginTop: 2,
        },
      })}
    >
      {/* Rota principal da Tab renomeada para ProdutosTab para não dar conflito com a Screen Produtos */}
      <Tab.Screen 
        name="ProdutosTab" 
        options={{ tabBarLabel: 'Produtos' }}
      >
        {props => <ProdutosStack {...props} carrinho={carrinho} setCarrinho={setCarrinho} />}
      </Tab.Screen>
      <Tab.Screen name="Carrinho">
        {props => <CarrinhoScreen {...props} carrinho={carrinho} setCarrinho={setCarrinho} />}
      </Tab.Screen>
      <Tab.Screen name="Fila" component={FilaScreen} />
      <Tab.Screen name="Mais" component={PerfilStack} />
    </Tab.Navigator>
  );
}

export default function App() {
  const fontsLoaded = useAppFonts();
  const [carrinho, setCarrinho] = useState([]);
  
  useEffect(() => {
    carregarCarrinho();
    
    // Tenta registrar/sincronizar push token caso o usuário já esteja autenticado
    sincronizarPushTokenComBackend();

    // Listener para notificações recebidas com o app em primeiro plano
    const notificationListener = Notifications.addNotificationReceivedListener(notification => {
      console.log('Notificação recebida em primeiro plano:', notification.request.content.title);
    });

    // Listener para quando o usuário toca na notificação (background ou app fechado)
    const responseListener = Notifications.addNotificationResponseReceivedListener(response => {
      try {
        const data = response.notification.request.content.data;
        if (data?.status === 'pronto' || data?.status === 'preparando' || data?.status === 'bebida_entregue') {
          if (navigationRef.isReady()) {
            navigationRef.navigate('MainTabs', { screen: 'Fila' });
          }
        }
      } catch (err) {
        console.log('Erro ao processar toque na notificação:', err);
      }
    });

    return () => {
      notificationListener.remove();
      responseListener.remove();
    };
  }, []);

  useEffect(() => {
    let ultimoStatus = null;
    const interval = setInterval(async () => {
      let tokenUsado = null;
      try {
        tokenUsado = await AsyncStorage.getItem('token');
        if (!tokenUsado) return;

        const dados = await AsyncStorage.getItem('pedidoAtual');
        if (!dados) return;
        const pedidoSalvo = JSON.parse(dados);
        if (!pedidoSalvo?.id) return;

        const res = await api.get(`/pedidos/${pedidoSalvo.id}/status`);
        const novoStatus = res.data?.status;

        if (ultimoStatus && ultimoStatus !== novoStatus) {
          if (novoStatus === 'preparando') {
            dispararNotificacaoLocal('👨‍🍳 Pedido em preparo!', 'Seu pedido começou a ser preparado pela cantina.', { status: 'preparando' });
          } else if (novoStatus === 'pronto') {
            dispararNotificacaoLocal('🎉 Pedido pronto!', `Seu pedido está pronto para retirada! Código: ${res.data?.codigo_retirada || ''}`, { status: 'pronto' });
          } else if (novoStatus === 'entregue') {
            dispararNotificacaoLocal('✅ Pedido entregue!', 'Seu pedido foi entregue. Bom apetite!', { status: 'entregue' });
          }
        }
        ultimoStatus = novoStatus;
      } catch (err) {
        const status = err.response?.status;
        if (status === 401) {
          const tokenAtual = await AsyncStorage.getItem('token');
          if (tokenAtual && tokenAtual === tokenUsado) {
            await AsyncStorage.multiRemove(['token', 'user', 'pedidoAtual']);
            if (navigationRef.isReady()) {
              navigationRef.resetRoot({
                index: 0,
                routes: [{ name: 'Login' }],
              });
            }
          }
        } else if (status === 403 || status === 404) {
          await AsyncStorage.removeItem('pedidoAtual');
        }
      }
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  async function carregarCarrinho(){
    try{
      const dados = await AsyncStorage.getItem('carrinho');
      if(dados){
        setCarrinho(JSON.parse(dados));
      }
    }
    catch (error){
      console.log(error);
    }
  }

  useEffect(() => {
    AsyncStorage.setItem('carrinho', JSON.stringify(carrinho));
  }, [carrinho]);

  return (
    <SafeAreaProvider>
      <NavigationContainer ref={navigationRef}>
        <Stack.Navigator
          initialRouteName="Login"
          screenOptions={{ headerShown: false }}
        >
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Cadastro" component={CadastroScreen} />
          <Stack.Screen name="RecuperarSenha" component={RecuperarSenhaScreen} />

          <Stack.Screen name="MainTabs">
            {props => <MainTabs {...props} carrinho={carrinho} setCarrinho={setCarrinho} />}
          </Stack.Screen>

        </Stack.Navigator>
        
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
