# DOCUMENTO DE DESIGN SYSTEM — PROJETO CANTINA UNESP
**Equipe:** INI3B-EQ5  
**Contexto:** Sistema Integrado de Autoatendimento e Gestão de Cantina (React Native Mobile + Web Admin Refine + Laravel API)

---

## 1. APRESENTAÇÃO DO DESIGN SYSTEM

O Design System da **Cantina UNESP** foi desenvolvido para unificar a experiência visual e de usabilidade entre o **Aplicativo Mobile (React Native)** voltado aos alunos e o **Painel Administrativo/Operacional (Web Refine/Ant Design)** voltado à equipe da cantina.

### 🎯 Princípios Fundamentais:
1. **Semântica Rigorosa:** Eliminação de "valores mágicos" (cores hexadecimais, pixels ou fontes soltas no código). Todo valor responde a um token semântico com propósito claro.
2. **Acolhimento e Apetite:** Paleta baseada em tons quentes (laranja, creme, pêssego e marrom café) que transmitem conforto visual, ambiente gastronômico e identidade institucional.
3. **Multiplataforma Consistente:** Distribuição dos mesmos tokens para CSS (`:root`) na Web e JavaScript Constants (`tokens/colors.js`) no Mobile.

---

## 2. PALETA DE CORES (TOKENS SEMÂNTICOS)

A nomenclatura segue o padrão de papéis semânticos (*Brand, Background, Text, Feedback, Border*), garantindo legibilidade e manutenção do código.

### 2.1 Cores de Marca (Brand Colors)
| Token CSS / React Native | Papel / Uso Semântico | Hexadecimal | Amostra |
| :--- | :--- | :--- | :--- |
| `--color-brand-primary` / `brandPrimary` | Cor primária da marca. Botões principais (CTA), destaque ativo da tab bar e finalização de pedidos. | `#FF9430` | 🟧 Laranja Principal |
| `--color-brand-primary-hover` / `brandPrimaryHover` | Estado de interação (hover/pressed) de botões primários e links em foco. | `#FF7A00` | 🟧 Laranja Intenso |
| `--color-brand-primary-light` / `brandPrimaryLight` | Destaque secundário, abas secundárias e fundos sutis de botões. | `#FDB368` | 🟨 Laranja Claro |
| `--color-brand-secondary` / `brandSecondary` | Cor institucional complementar. Títulos principais (H1/H2) e cabeçalhos de seções. | `#3E2723` | 🟫 Marrom Café |
| `--color-brand-tertiary` / `brandTertiary` | Contraste de alta legibilidade. Texto de corpo, ícones inativos e elementos neutros escuros. | `#0F1A25` | ⬛ Azul Noturno |

### 2.2 Cores de Superfície e Fundo (Background & Surface)
| Token CSS / React Native | Papel / Uso Semântico | Hexadecimal |
| :--- | :--- | :--- |
| `--color-bg-screen` / `bgScreen` | Fundo principal da aplicação (Mobile e Web). Tom quente e confortável aos olhos. | `#FFF8F0` (Creme) |
| `--color-bg-card` / `bgCard` | Fundo de cartões de itens, produtos no catálogo e destaques no mobile. | `#FAD6A9` (Pêssego) |
| `--color-bg-surface` / `bgSurface` | Superfície de cartões administrativos, modais, formulários e inputs. | `#FFFFFF` (Branco Puro) |
| `--color-border-default` / `borderDefault` | Linhas delimitadoras de inputs, modais e tabelas. | `#D9D9D9` (Cinza Neutro) |
| `--color-border-subtle` / `borderSubtle` | Divisórias internas e linhas de separação de itens da tabela. | `#F5F5F5` (Cinza Suave) |

### 2.3 Cores de Feedback e Estado (Semantic Status)
| Token CSS / React Native | Papel / Uso Semântico | Hexadecimal |
| :--- | :--- | :--- |
| `--color-feedback-success` / `feedbackSuccess` | Saldo positivo, recargas confirmadas, pedido finalizado com sucesso. | `#2E7D32` (Verde) |
| `--color-feedback-error` / `feedbackError` | Cancelamentos, falhas de saldo/crédito, exclusão de itens e alertas críticos. | `#C62828` (Vermelho) |
| `--color-feedback-warning` / `feedbackWarning` | Pedido em preparo no Kanban, pendências de pagamento e fiado. | `#F57F17` (Âmbar/Amarelo) |
| `--color-feedback-info` / `feedbackInfo` | Informações de sistema, estornos, navegação e dados complementares. | `#1565C0` (Azul Info) |

---

## 3. TIPOGRAFIA E HIERARQUIA VISUAL

A escala tipográfica adota uma progressão clara baseada em múltiplos de **4px / 8px**, evitando tamanhos aleatórios.

### 3.1 Família Tipográfica
- **Web (Admin):** `'Inter', 'Segoe UI', system-ui, sans-serif`
- **Mobile (App):** `System Native Font (Roboto no Android / San Francisco no iOS)`

### 3.2 Escala Tipográfica Semântica
| Nível / Token | Tamanho | Peso (Weight) | Uso Sugerido |
| :--- | :--- | :--- | :--- |
| **Hero / Senha** (`--font-size-hero`) | `52px` | 900 (Black) | Exibição de Senha de Retirada na tela de Fila. |
| **Título Display** (`--font-size-4xl`) | `48px` | 900 (Black) | Cabeçalho de Perfil e Telas Principais. |
| **Título Grande** (`--font-size-3xl`) | `40px` | 700 (Bold) | Títulos de destaque do App (Ex: "Fila"). |
| **Moeda / Saldo** (`--font-size-2xl`) | `28px` | 700 (Bold) | Exibição em evidência do Saldo e Limite de Crédito. |
| **Título H2** (`--font-size-xl`) | `24px` | 700 (Bold) | Títulos de telas, nomes de seção e modais. |
| **Subtítulo / Label** (`--font-size-lg`) | `18px` | 600 (SemiBold) | Nomes de produtos, títulos de cards e grupos. |
| **Destaque / Botão** (`--font-size-md`) | `16px` | 600 (SemiBold) | Textos de botões primários e links de navegação. |
| **Corpo (Base)** (`--font-size-base`) | `14px` | 400 (Regular) | Textos descritivos, dados de tabelas e inputs. |
| **Legenda / Header** (`--font-size-sm`) | `12px` | 600 (SemiBold) | Rótulos de cabeçalho de tabela e abas inferiores. |
| **Microbadge** (`--font-size-xs`) | `11px` | 500 (Medium) | Tags de status, horários e badges secundários. |

---

## 4. ESPAÇAMENTO E GRID (REGRA DOS 4px / 8px)

Para garantir que os elementos nunca pareçam "jogados" ou desalinhados, todo padding, margin e gap utiliza estritamente a escala proporcional de base 4:

```
4px (s1) → 8px (s2) → 12px (s3) → 16px (s4) → 20px (s5) → 24px (s6) → 32px (s8) → 40px (s10) → 48px (s12) → 64px (s16)
```

### 4.1 Aplicação Semântica de Espaçamento
- **`--space-inset-sm` (12px):** Padding interno de badges, tags e chips.
- **`--space-inset-md` (16px):** Padding padrão de cards e inputs de texto.
- **`--space-inset-lg` (20px):** Espaçamento horizontal de tela (padrão em mobile: `20px`).
- **`--space-inset-xl` (24px):** Padding interno de modais e painéis administrativos.
- **`--space-section-gap` (32px):** Distância vertical entre blocos ou seções diferentes.

---

## 5. COMPONENTES ESSENCIAIS E ESTADOS

### 5.1 Botões (Buttons)
- **Botão Primário (CTA / Ação Principal):**
  - Fundo: `--color-brand-primary` (`#FF9430`)
  - Texto: `--color-text-on-brand` (`#0F1A25` ou `#FFFFFF` em alto contraste)
  - Raio de Borda: `--border-radius-sm` (`8px`)
  - Estados:
    - *Hover / Pressionado:* `--color-brand-primary-hover` (`#FF7A00`) com sombra de realce `--shadow-brand`.
    - *Desabilitado:* Fundo `--color-text-disabled` (`#AAAAAA`) com cursor bloqueado.
- **Botão Secundário / Outline:**
  - Borda: `1px solid --color-brand-primary`
  - Fundo: Transparente
  - *Hover:* Fundo `--color-bg-screen` com texto destacado.

### 5.2 Campos de Entrada (Inputs)
- **Fundo:** `--color-bg-surface` (`#FFFFFF`)
- **Borda Padrão:** `1px solid --color-border-default` (`#D9D9D9`), raio `8px`.
- **Foco:** Borda em `--color-brand-primary` (`#FF9430`) com anel de foco suave.
- **Mensagem de Erro / Validação:** Texto em `--color-feedback-error` (`#C62828`) posicionado diretamente abaixo do campo, com espaçamento de `4px`.

### 5.3 Cartões (Cards) e Superfícies
- **Padrão Mobile:** Fundo `--color-bg-card` (`#FAD6A9`), bordas arredondadas de `12px` (`--border-radius-md`), padding de `16px` e sombra suave.
- **Padrão Web / Admin:** Fundo `--color-bg-surface` (`#FFFFFF`), bordas com raio de `12px` e sombra `--shadow-md` para elevação contra o fundo creme.

---

## 6. BLOCO CSS `:root` PUBLICADO NO PROJETO

O código abaixo reside no arquivo central de estilos do projeto: [`cantina-admin/src/design-system.css`](file:///c:/Users/ra2457003/projs-laravel/INI3B-EQ5/cantina-admin/src/design-system.css):

```css
:root {
  /* 1. CORES - MARCA */
  --color-brand-primary:          #FF9430;
  --color-brand-primary-hover:    #FF7A00;
  --color-brand-primary-light:    #FDB368;
  --color-brand-primary-shadow:   rgba(255, 148, 48, 0.35);
  --color-brand-secondary:        #3E2723;
  --color-brand-secondary-light:  #6D4C41;
  --color-brand-tertiary:         #0F1A25;

  /* 2. CORES - BACKGROUND E SUPERFÍCIE */
  --color-bg-screen:              #FFF8F0;
  --color-bg-card:                #FAD6A9;
  --color-bg-card-light:          rgba(250, 214, 169, 0.15);
  --color-bg-surface:             #FFFFFF;
  --color-border-default:         #D9D9D9;
  --color-border-subtle:          #F5F5F5;

  /* 3. CORES - FEEDBACK SEMÂNTICO */
  --color-feedback-success:       #2E7D32;
  --color-feedback-success-light: #4CAF50;
  --color-feedback-error:         #C62828;
  --color-feedback-error-light:   #D32F2F;
  --color-feedback-warning:       #F57F17;
  --color-feedback-warning-light: #faad14;
  --color-feedback-info:          #1565C0;
  --color-feedback-info-light:    #1890ff;

  /* 4. CORES - TEXTO */
  --color-text-primary:           #3E2723;
  --color-text-body:              #0F1A25;
  --color-text-secondary:         #666666;
  --color-text-muted:             #888888;
  --color-text-disabled:          #AAAAAA;
  --color-text-on-dark:           #FFFFFF;
  --color-text-on-brand:          #0F1A25;
  --color-text-placeholder:       #999999;

  /* 5. TIPOGRAFIA */
  --font-family-base:             'Inter', 'Segoe UI', system-ui, sans-serif;
  --font-size-xs:                 11px;
  --font-size-sm:                 12px;
  --font-size-base:               14px;
  --font-size-md:                 16px;
  --font-size-lg:                 18px;
  --font-size-xl:                 24px;
  --font-size-2xl:                28px;
  --font-size-3xl:                40px;
  --font-size-4xl:                48px;
  --font-size-hero:               52px;

  --font-weight-regular:          400;
  --font-weight-medium:           500;
  --font-weight-semibold:         600;
  --font-weight-bold:             700;
  --font-weight-black:            900;

  /* 6. ESPAÇAMENTO (Base 4px) */
  --space-1:                       4px;
  --space-2:                       8px;
  --space-3:                      12px;
  --space-4:                      16px;
  --space-5:                      20px;
  --space-6:                      24px;
  --space-8:                      32px;
  --space-10:                     40px;
  --space-12:                     48px;
  --space-16:                     64px;

  /* 7. BORDAS E SOMBRAS */
  --border-radius-sm:              8px;
  --border-radius-md:             12px;
  --border-radius-lg:             18px;
  --shadow-sm:                    0 2px 6px rgba(15, 26, 37, 0.06);
  --shadow-md:                    0 4px 12px rgba(15, 26, 37, 0.08);
  --shadow-brand:                 0 4px 12px rgba(255, 148, 48, 0.35);
}
```

---

## 7. COMPROMISSO DE APLICAÇÃO E PREVENÇÃO DE ERROS

A equipe assume formalmente o compromisso de conformidade com o Design System através das seguintes diretrizes:

1. **Zero Valores Mágicos:** Proibido o uso de `#HEX` soltos nos arquivos `.js`, `.tsx` ou `.css`. Todas as cores e espaçamentos devem ser consumidos de:
   - Web: `var(--color-*)`, `var(--space-*)`
   - Mobile: `colors.*`, `spacing.*`, `radii.*` via [`src/tokens/colors.js`](file:///c:/Users/ra2457003/projs-laravel/INI3B-EQ5/React%20Native/src/tokens/colors.js).
2. **Consistência de Raios de Borda:** Botões e inputs usam rigorosamente **8px**; cards e imagens usam **12px**; modais e containers de destaque usam **18px**.
3. **Harmonia Multiplataforma:** As mesmas cores do Figma foram integradas tanto ao App React Native dos alunos quanto ao Kanban e listagens do painel de administração da cantina.
