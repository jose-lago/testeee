# Plano Final — Sistema de Pedidos da Cantina Saviore

---

## 1. Alterações no Banco de Dados

### 1.1 — Tabela `produtos` (Migration de alteração)

Adicionar campo `categoria`:

```php
$table->string('categoria', 20)->default('almoco');
// Valores: 'almoco', 'bebida' (futuro: 'doce', 'salgado')
```

### 1.2 — Tabela `pedidos` (Reescrever migration existente)

```php
Schema::create('pedidos', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
    $table->foreignId('preparador_id')->nullable()->constrained('users')->nullOnDelete();
    $table->decimal('valor_total', 8, 2)->default(0.00)->unsigned();
    $table->integer('senha_diaria')->unsigned();
    $table->enum('status', ['pendente','preparando','pronto','entregue','cancelado'])->default('pendente');
    $table->enum('momento_bebida', ['agora','com_almoco'])->default('agora');
    $table->integer('posicao_fila')->unsigned()->default(0);
    $table->string('codigo_retirada', 4); // 4 dígitos numéricos
    $table->timestamps();
});
```

### 1.3 — Tabela `pedido_produto` (Reescrever migration existente)

```php
Schema::create('pedido_produto', function (Blueprint $table) {
    $table->id();
    $table->foreignId('pedido_id')->constrained('pedidos')->onDelete('cascade');
    $table->foreignId('produto_id')->constrained('produtos')->onDelete('cascade');
    $table->integer('quantidade')->unsigned()->default(1);
    $table->decimal('preco_unitario', 8, 2)->unsigned();
    $table->text('observacao')->nullable();
    $table->boolean('entregue')->default(false); // Rastreamento por item
    $table->timestamps();
});
```

### 1.4 — Novo Middleware `VerificarFuncionario`

Aceita usuários com `tipo = 'funcionario'` OU `tipo = 'admin'`. Registrado como alias `funcionario` em `bootstrap/app.php`.

---

## 2. Funções do PedidoController — 15 Funções

### GRUPO A — CRUD Admin (Refine) — 4 funções

---

#### A1. `index` — `GET /api/pedidos`

**Quem usa:** Painel Refine (Admin).
**O que faz:** Lista todos os pedidos com filtros, ordenação e Eager Loading dos itens.

**Segurança e verificações:**
- Middleware: `auth:sanctum` + `admin`
- Sanitiza parâmetros `_sort` e `_order` contra lista de colunas permitidas
- Retorna array JSON puro (padrão Refine)

---

#### A2. `show` — `GET /api/pedidos/{id}`

**Quem usa:** Painel Refine (Admin).
**O que faz:** Retorna um pedido específico com itens, dados do cliente e preparador.

**Segurança e verificações:**
- Middleware: `auth:sanctum` + `admin`
- Verifica se o pedido existe (`findOrFail`)
- Eager Loading: `itens.produto`, `user`, `preparador`

---

#### A3. `update` — `PUT /api/pedidos/{id}`

**Quem usa:** Painel Refine (Admin).
**O que faz:** Permite o admin alterar campos do pedido.

**Segurança e verificações:**
- Middleware: `auth:sanctum` + `admin`
- Verifica se o pedido existe
- Valida: `status` deve ser um dos valores do enum
- Se `preparador_id` for enviado, verifica se o usuário existe e tem `tipo` = `funcionario` ou `admin`
- Campos permitidos: `status`, `preparador_id`, `momento_bebida`, `posicao_fila`
- Campos NUNCA editáveis pelo update: `user_id`, `valor_total`, `senha_diaria`, `codigo_retirada`

---

#### A4. `destroy` — `DELETE /api/pedidos/{id}`

**Quem usa:** Painel Refine (Admin).
**O que faz:** Deleta pedido. Estorna saldo se aplicável.

**Segurança e verificações:**
- Middleware: `auth:sanctum` + `admin`
- Verifica se o pedido existe
- **Regra de estorno:** Se o status NÃO é `entregue`, estorna `valor_total` ao saldo do aluno, mas SOMENTE o valor dos itens que NÃO foram entregues individualmente
- Usa `DB::transaction` para garantir atomicidade do estorno + deleção
- Os `pedido_produto` são deletados em cascata pela FK

---

### GRUPO B — Ações do Aluno (React Native) — 4 funções

---

#### B1. `criar` — `POST /api/pedidos/criar`

**Quem usa:** React Native (Aluno).
**O que faz:** Cria pedido completo (cabeçalho + itens). Debita saldo. Gera senha e código.

**Body esperado:**
```json
{
  "momento_bebida": "agora",
  "itens": [
    { "produto_id": 1, "quantidade": 1, "observacao": "Sem salada" },
    { "produto_id": 5, "quantidade": 2, "observacao": null }
  ]
}
```

**Segurança e verificações (nesta ordem):**
1. Middleware: `auth:sanctum`
2. O `user_id` é pego do token (`$request->user()->id`). O aluno NUNCA envia `user_id` no body — mesmo se enviar, é ignorado
3. Valida que `itens` é um array não vazio
4. Valida cada item: `produto_id` existe, `quantidade` >= 1
5. Para cada produto: verifica `disponivel = true`. Se algum não estiver disponível, retorna 422 com o nome do produto
6. Calcula `valor_total` = soma de (`preco_atual` × `quantidade`) de cada item
7. Verifica se `saldo` do aluno >= `valor_total`. Se não: retorna 422 "Saldo insuficiente"
8. Tudo dentro de `DB::transaction`:
   - Debita saldo: `$user->decrement('saldo', $valorTotal)`
   - Gera `senha_diaria`: `Pedido::whereDate('created_at', today())->max('senha_diaria') + 1`
   - Gera `codigo_retirada`: `str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT)`
   - Cria o `Pedido` com status `pendente`
   - Para cada item, cria `PedidoProduto` com `preco_unitario` = `preco_atual` do produto naquele momento e `entregue = false`
9. Retorna o pedido criado com senha e código de retirada

---

#### B2. `cancelar` — `POST /api/pedidos/{id}/cancelar`

**Quem usa:** React Native (Aluno).
**O que faz:** Cancela o pedido e estorna o saldo.

**Segurança e verificações (nesta ordem):**
1. Middleware: `auth:sanctum`
2. Verifica se o pedido existe
3. Verifica se `pedido.user_id` == `$request->user()->id` (é o dono). Se não: 403
4. Verifica se `pedido.status` == `pendente`. Se não: 403 "Pedido já está sendo preparado"
5. Verifica se NENHUM item foi entregue: `$pedido->itens()->where('entregue', true)->exists()` deve ser `false`. Se algum item já foi entregue: 403 "Não é possível cancelar, itens já foram entregues"
6. Usa `DB::transaction` com `lockForUpdate()` no pedido:
   - Muda status para `cancelado`
   - Estorna `valor_total` ao saldo do aluno: `$user->increment('saldo', $pedido->valor_total)`
7. Retorna confirmação

---

#### B3. `meusPedidos` — `GET /api/pedidos/meus`

**Quem usa:** React Native (Aluno).
**O que faz:** Lista todos os pedidos do aluno autenticado.

**Segurança e verificações:**
1. Middleware: `auth:sanctum`
2. Filtra automaticamente por `user_id` = usuário do token
3. Ordena por `created_at DESC` (mais recentes primeiro)
4. Inclui Eager Loading: `itens.produto`
5. Retorna array JSON

---

#### B4. `statusPedido` — `GET /api/pedidos/{id}/status`

**Quem usa:** React Native (Aluno).
**O que faz:** Retorna status, senha, código de retirada e posição calculada na fila.

**Segurança e verificações:**
1. Middleware: `auth:sanctum`
2. Verifica se o pedido existe
3. Verifica se `pedido.user_id` == `$request->user()->id`. Se não: 403
4. Calcula posição na fila dinamicamente (contando pedidos à frente):
```php
$posicao = Pedido::whereIn('status', ['pendente', 'preparando'])
    ->where(function ($q) use ($pedido) {
        $q->where('posicao_fila', '<', $pedido->posicao_fila)
          ->orWhere(function ($q2) use ($pedido) {
              $q2->where('posicao_fila', '=', $pedido->posicao_fila)
                 ->where('created_at', '<', $pedido->created_at);
          });
    })->count() + 1;
```
5. Retorna: `{ senha, status, posicao, codigo_retirada, itens }`

---

### GRUPO C — Ações da Funcionária (Kanban) — 7 funções

---

#### C1. `fila` — `GET /api/pedidos/fila`

**Quem usa:** Tela Kanban (PC da cantina).
**O que faz:** Retorna dados organizados em 4 seções para renderização direta.

**Segurança e verificações:**
- Middleware: `auth:sanctum` + `funcionario`

**Retorno:**
```json
{
  "bebidas_agora": [...],
  "pendentes": [...],
  "em_preparo": [...],
  "prontos": [...],
  "total_fila": 5
}
```

**Lógica de cada seção:**
- `bebidas_agora`: Pedidos com `momento_bebida = 'agora'` que possuem itens com `categoria = 'bebida'` e `entregue = false`. Ordenados por `created_at ASC`.
- `pendentes`: Pedidos com `status = 'pendente'`. Ordenados por `posicao_fila ASC`, `created_at ASC`.
- `em_preparo`: Pedidos com `status = 'preparando'`. Inclui dados do preparador. Ordenados por `updated_at ASC`.
- `prontos`: Pedidos com `status = 'pronto'`. Ordenados por `updated_at ASC`.
- `total_fila`: Contagem de pendentes.

---

#### C2. `entregarBebida` — `POST /api/pedidos/{id}/entregar-bebida`

**Quem usa:** Tela Kanban (Fila Rápida).
**O que faz:** Marca itens de bebida como entregues.

**Segurança e verificações:**
1. Middleware: `auth:sanctum` + `funcionario`
2. Verifica se o pedido existe
3. Verifica se o pedido tem itens de `categoria = 'bebida'` não entregues
4. Marca SOMENTE os itens com `categoria = 'bebida'` como `entregue = true`
5. NÃO muda o status do pedido (o almoço continua na fila)
6. Retorna o pedido atualizado

---

#### C3. `preparar` — `POST /api/pedidos/{id}/preparar`

**Quem usa:** Tela Kanban (coluna Pendentes).
**O que faz:** Funcionária pega o pedido para preparar.

**Body esperado:**
```json
{ "preparador_id": 3 }
```

**Segurança e verificações:**
1. Middleware: `auth:sanctum` + `funcionario`
2. Verifica se o pedido existe
3. Verifica se `status == 'pendente'`. Se não: 422 "Pedido não está pendente"
4. Valida que `preparador_id` existe na tabela `users`
5. Valida que o preparador tem `tipo` = `funcionario` ou `admin`. Se não: 403
6. Usa `DB::transaction` com `lockForUpdate()`:
   - Seta `preparador_id`
   - Muda `status` para `preparando`
7. Retorna o pedido com itens

---

#### C4. `pronto` — `POST /api/pedidos/{id}/pronto`

**Quem usa:** Tela Kanban (coluna Em Preparo).
**O que faz:** Marca pedido como pronto para retirada.

**Segurança e verificações:**
1. Middleware: `auth:sanctum` + `funcionario`
2. Verifica se o pedido existe
3. Verifica se `status == 'preparando'`. Se não: 422
4. Muda `status` para `pronto`
5. Retorna o pedido (futuro: aqui será disparada a notificação push)

---

#### C5. `entregar` — `POST /api/pedidos/{id}/entregar`

**Quem usa:** Tela Kanban (barra Prontos).
**O que faz:** Confirma entrega ao aluno via comparação visual do código.

**Body esperado:**
```json
{ "codigo_confirmado": true }
```

**Segurança e verificações:**
1. Middleware: `auth:sanctum` + `funcionario`
2. Verifica se o pedido existe
3. Verifica se `status == 'pronto'`. Se não: 422
4. Verifica se `codigo_confirmado == true` (a funcionária clicou "Confere" após comparar visualmente)
5. Muda `status` para `entregue`
6. Marca TODOS os itens restantes como `entregue = true`
7. Retorna confirmação

**Fluxo na tela:**
- Funcionária clica "Entregar" → PC mostra o `codigo_retirada` em fonte grande
- Aluno mostra o código no celular
- Funcionária compara visualmente → clica "✅ Confere" ou "❌ Não Confere"
- Zero digitação

---

#### C6. `entregarProximo` — `POST /api/pedidos/{id}/entregar-proximo`

**Quem usa:** Tela Kanban (barra Prontos).
**O que faz:** Entrega o pedido atual E já pega o próximo para preparar.

**Body esperado:**
```json
{ "codigo_confirmado": true, "preparador_id": 3 }
```

**Segurança e verificações:**
1. Todas as verificações do `entregar` (seção C5)
2. Usa `DB::transaction`:
   - Entrega o pedido atual (status → `entregue`, itens → `entregue = true`)
   - Busca o próximo pedido `pendente` (ordenado por `posicao_fila ASC`, `created_at ASC`)
   - Se existir: seta `preparador_id` e muda status para `preparando`
   - Se não existir: retorna `proximo: null`
3. Retorna: `{ entregue: {...}, proximo: {...} | null }`

---

#### C7. `desfazer` — `POST /api/pedidos/{id}/desfazer`

**Quem usa:** Tela Kanban.
**O que faz:** Reverte a última ação no pedido (volta um passo no status).

**Segurança e verificações:**
1. Middleware: `auth:sanctum` + `funcionario`
2. Verifica se o pedido existe
3. Aplica a reversão conforme o status atual:

| Status Atual | Reverte para | Ações extras |
|:--|:--|:--|
| `preparando` | `pendente` | Limpa `preparador_id` para `null` |
| `pronto` | `preparando` | Mantém `preparador_id` |
| `entregue` | `pronto` | Marca todos itens como `entregue = false` |
| `pendente` / `cancelado` | — | Retorna 422 "Nada para desfazer" |

4. Retorna o pedido atualizado

---

## 3. Middleware `VerificarFuncionario`

```php
class VerificarFuncionario
{
    public function handle(Request $request, Closure $next): Response
    {
        if (Auth::check() && in_array(Auth::user()->tipo, ['funcionario', 'admin'])) {
            return $next($request);
        }
        return response()->json([
            'sucesso' => false,
            'mensagem' => 'Acesso restrito a funcionários da cantina.'
        ], 403);
    }
}
```

Registrado em `bootstrap/app.php` como `'funcionario' => VerificarFuncionario::class`.

---

## 4. Validações nos Models (Camada de segurança extra)

### Model `Pedido` — Evento `saving`:
- Bloqueia `valor_total` < 0
- Se `preparador_id` não for null, verifica se o user tem tipo `funcionario` ou `admin`
- Valida `status` contra lista de valores permitidos

### Model `PedidoProduto` — Evento `saving`:
- Bloqueia `quantidade` <= 0
- Bloqueia `preco_unitario` < 0

---

## 5. Estrutura de Rotas (`api.php`)

```php
// ALUNO
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/pedidos/criar',                  [PedidoController::class, 'criar']);
    Route::get('/pedidos/meus',                    [PedidoController::class, 'meusPedidos']);
    Route::get('/pedidos/{id}/status',             [PedidoController::class, 'statusPedido']);
    Route::post('/pedidos/{id}/cancelar',          [PedidoController::class, 'cancelar']);
});

// FUNCIONÁRIO + ADMIN
Route::middleware(['auth:sanctum', 'funcionario'])->group(function () {
    Route::get('/pedidos/fila',                    [PedidoController::class, 'fila']);
    Route::post('/pedidos/{id}/entregar-bebida',   [PedidoController::class, 'entregarBebida']);
    Route::post('/pedidos/{id}/preparar',          [PedidoController::class, 'preparar']);
    Route::post('/pedidos/{id}/pronto',            [PedidoController::class, 'pronto']);
    Route::post('/pedidos/{id}/entregar',          [PedidoController::class, 'entregar']);
    Route::post('/pedidos/{id}/entregar-proximo',  [PedidoController::class, 'entregarProximo']);
    Route::post('/pedidos/{id}/desfazer',          [PedidoController::class, 'desfazer']);
});

// ADMIN (CRUD Refine)
Route::middleware(['auth:sanctum', 'admin'])->group(function () {
    Route::get('/pedidos',                         [PedidoController::class, 'index']);
    Route::get('/pedidos/{id}',                    [PedidoController::class, 'show']);
    Route::put('/pedidos/{id}',                    [PedidoController::class, 'update']);
    Route::delete('/pedidos/{id}',                 [PedidoController::class, 'destroy']);
});
```

> [!IMPORTANT]
> Rotas com nomes fixos (`/pedidos/criar`, `/pedidos/meus`, `/pedidos/fila`) devem vir ANTES das rotas com `{id}` no mesmo grupo de middleware. Caso contrário, o Laravel interpreta "criar", "meus" ou "fila" como um `{id}`.

---

## 6. Layout do Kanban

```
┌──────────────────────────────────────────────────────────────────┐
│ 🥤 BEBIDAS AGORA       │ 📋 PENDENTES (5)     │ 🍳 EM PREPARO    │
│                        │                      │                  │
│ ┌────────────────────┐ │ ┌──────────────────┐ │ ┌──────────────┐ │
│ │ Senha 012          │ │ │ 1º│ Senha 008     │ │ │ 🔴 Maria     │ │
│ │ 2x Coca-Cola       │ │ │ Almoço 1 Prot.   │ │ │ Senha 005    │ │
│ │ [✅ ENTREGUE]      │ │ │ "Sem salada"     │ │ │ Almoço 2P    │ │
│ └────────────────────┘ │ │ [🍳 PREPARAR]    │ │ │ [✅ PRONTO]  │ │
│                        │ └──────────────────┘ │ └──────────────┘ │
├──────────────────────────────────────────────────────────────────┤
│ 📢 PRONTOS                                                      │
│ Senha 003 [🟢 ENTREGAR] [🟢 ENTREGAR+PRÓXIMO] [↩ DESFAZER]     │
└──────────────────────────────────────────────────────────────────┘
```
