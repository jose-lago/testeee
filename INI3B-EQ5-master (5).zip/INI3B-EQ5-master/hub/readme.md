# SAVIORE

> **Do pedido ao pagamento em segundos.**

---

## 📌 Sobre o Projeto
- **Problema identificado:** Lentidão dos processos de venda e administração das cantinas que utilizam trabalho totalmente manual
- **Solução proposta:** Como o sistema resolve esse problema?
- **Público-alvo:** Funcionários de cantinas escolasres

---

## 🚀 Tecnologias e Arquitetura
- **Linguagem / Framework Backend:** PHP / Laravel
- **Banco de Dados:** PostgreSQL
- **Frontend / Estilização:** React Native
- **Hospedagem / Infra:** Docker / Nginx
